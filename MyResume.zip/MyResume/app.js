const express = require('express');
const session = require('express-session');
const path = require('path');
const { createDatabase } = require('./database');
const { logActivity, getLogs, getLogStats, getLogsAdvanced, exportLogsCSV } = require('./logs');
const { sendAccountCredentials, generateRandomPassword } = require('./email');

// Inicializar a base de dados
const db = createDatabase();

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configuração do EJS como view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configuração da sessão
app.use(session({
  secret: 'camigap-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 3600000 } // 1 hora
}));

// Middleware para verificar se o usuário está logado como admin
const isAdmin = (req, res, next) => {
  if (!req.session.adminLoggedIn) {
    return res.redirect('/login');
  }
  next();
};

// Middleware para verificar se o usuário é financeiro
const isFinanceiro = (req, res, next) => {
  if (!req.session.userId || req.session.profileType !== 'financeiro') {
    return res.redirect('/login');
  }
  next();
};

// Middleware para verificar se o usuário está logado (qualquer tipo)
const isLoggedIn = (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  next();
};

// Middleware para verificar se o usuário é um profissional (árbitro, mediador ou conciliador)
const isProfissional = async (req, res, next) => {
  if (!req.session.userId) {
    console.log('isProfissional: Usuário não está logado');
    return res.redirect('/login');
  }
  
  try {
    console.log(`isProfissional: Verificando profissional para userId=${req.session.userId}`);
    
    // Verificar se o usuário é um profissional
    const [profissionais] = await db.query(
      'SELECT * FROM profissionais WHERE user_id = ?',
      [req.session.userId]
    );
    
    console.log(`isProfissional: Encontrados ${profissionais.length} registros`);
    
    if (profissionais.length === 0) {
      console.log('isProfissional: Usuário não é um profissional, redirecionando para dashboard');
      return res.redirect('/dashboard');
    }
    
    // Adicionar informações do profissional à sessão
    req.session.profissional = profissionais[0];
    console.log(`isProfissional: Profissional encontrado, tipo=${profissionais[0].tipo}`);
    next();
  } catch (error) {
    console.error('Erro ao verificar se o usuário é profissional:', error);
    console.error(error.stack);
    res.redirect('/dashboard');
  }
};

// Middleware para verificar se o usuário é um secretário (geral ou de processo)
const isSecretario = async (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  
  try {
    // Verificar se o usuário é um secretário
    if (req.session.profileType !== 'secretario_geral' && req.session.profileType !== 'secretario_processo') {
      req.session.mensagem = 'Acesso restrito a secretários.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/dashboard');
    }
    
    console.log(`isSecretario: Usuário ${req.session.username} é um ${req.session.profileType}`);
    next();
  } catch (error) {
    console.error('Erro ao verificar se o usuário é secretário:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao verificar permissões: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
};

// Rotas
app.get('/', (req, res) => {
  console.log('=== ACESSO À PÁGINA INICIAL ===');
  console.log('IP do cliente:', req.ip);
  res.render('index-simple');
});

// Rotas para serviços
app.get('/servico/arbitragem', (req, res) => {
  res.render('arbitragem-form', {
    mensagem: req.session.mensagem || null,
    tipoMensagem: req.session.tipoMensagem || 'info'
  });
  delete req.session.mensagem;
  delete req.session.tipoMensagem;
});

app.get('/servico/mediacao', (req, res) => {
  res.render('mediacao-form', {
    mensagem: req.session.mensagem || null,
    tipoMensagem: req.session.tipoMensagem || 'info'
  });
  delete req.session.mensagem;
  delete req.session.tipoMensagem;
});

app.get('/servico/conciliacao', (req, res) => {
  res.render('conciliacao-form', {
    mensagem: req.session.mensagem || null,
    tipoMensagem: req.session.tipoMensagem || 'info'
  });
  delete req.session.mensagem;
  delete req.session.tipoMensagem;
});

// Configuração do multer para upload de arquivos
const multer = require('multer');
const fs = require('fs');

// Criar diretório para uploads se não existir
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configuração do armazenamento para multer 2.0.0
const storage = multer.diskStorage({
  destination: async function (req, file, cb) {
    // Determinar o tipo de serviço a partir da URL ou do corpo da requisição
    let tipoServico;
    
    // Verificar se o tipo está nos parâmetros da URL
    if (req.params.tipo) {
      tipoServico = req.params.tipo;
    } 
    // Caso contrário, extrair do caminho da URL
    else {
      const urlPath = req.originalUrl;
      if (urlPath.includes('/arbitragem/')) {
        tipoServico = 'arbitragem';
      } else if (urlPath.includes('/mediacao/')) {
        tipoServico = 'mediacao';
      } else if (urlPath.includes('/conciliacao/')) {
        tipoServico = 'conciliacao';
      } else {
        tipoServico = 'geral'; // Pasta padrão
      }
    }
    
    // Criar pasta específica para cada tipo de serviço
    const servicoDir = path.join(uploadDir, tipoServico);
    if (!fs.existsSync(servicoDir)) {
      fs.mkdirSync(servicoDir, { recursive: true });
    }
    
    console.log(`Salvando arquivo em: ${servicoDir}`);
    cb(null, servicoDir);
  },
  filename: async function (req, file, cb) {
    // Gerar nome de arquivo único
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + extension);
  }
});

// Filtro para permitir apenas arquivos PDF e ZIP
const fileFilter = (req, file, cb) => {
  // Verificar o tipo MIME do arquivo
  if (
    file.mimetype === 'application/pdf' || 
    file.mimetype === 'application/zip' || 
    file.mimetype === 'application/x-zip-compressed'
  ) {
    // Aceitar o arquivo
    cb(null, true);
  } else {
    // Rejeitar o arquivo
    cb(new Error('Apenas arquivos PDF e ZIP são permitidos'), false);
  }
};

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // limite de 10MB
  },
  fileFilter: fileFilter
});

// Rota para processar o formulário de arbitragem
app.post('/servico/arbitragem/enviar', async (req, res) => {
  console.log('\n🔥🔥🔥 INÍCIO PROCESSAMENTO ARBITRAGEM 🔥🔥🔥');
  console.log('Timestamp:', new Date().toISOString());
  console.log('Headers:', req.headers);
  console.log('Method:', req.method);
  console.log('URL:', req.originalUrl);
  
  try {
    console.log('📤 ETAPA 1: Configurando middleware de upload...');
    
    // Usar o middleware de upload para processar os arquivos
    const uploadMiddleware = upload.fields([
      { name: 'comprovativoPagamento', maxCount: 1 },
      { name: 'convencaoArbitragem', maxCount: 1 },
      { name: 'procuracao', maxCount: 1 },
      { name: 'comprovativoPoderes', maxCount: 1 },
      { name: 'documentosComplementares', maxCount: 5 }
    ]);
    
    console.log('📤 ETAPA 2: Executando middleware de upload...');
    
    // Executar o middleware manualmente
    await new Promise((resolve, reject) => {
      uploadMiddleware(req, res, (err) => {
        if (err) {
          console.error('❌ ERRO NO MIDDLEWARE DE UPLOAD:');
          console.error('  Tipo:', err.constructor.name);
          console.error('  Mensagem:', err.message);
          console.error('  Code:', err.code);
          console.error('  Stack:', err.stack);
          reject(err);
        } else {
          console.log('✅ Middleware de upload executado com sucesso');
          resolve();
        }
      });
    });
    
    console.log('📤 ETAPA 3: Processando dados do formulário...');
    console.log('req.body:', JSON.stringify(req.body, null, 2));
    console.log('req.files:', req.files ? Object.keys(req.files) : 'Nenhum arquivo');
    
    // Processar arquivos enviados
    let arquivosInfo = {};
    if (req.files) {
      console.log('📤 ETAPA 4: Processando arquivos...');
      Object.keys(req.files).forEach(key => {
        arquivosInfo[key] = req.files[key].map(f => ({
          filename: f.filename,
          originalname: f.originalname,
          path: f.path
        }));
      });
      
      console.log('Arquivos processados:', Object.keys(req.files).map(key => ({
        campo: key,
        arquivos: req.files[key].map(f => f.filename)
      })));
    } else {
      console.log('📤 ETAPA 4: Nenhum arquivo para processar');
    }
    
    console.log('📤 ETAPA 5: Preparando dados para banco...');
    
    // Salvar os dados no banco de dados
    const dadosFormulario = JSON.stringify(req.body);
    const arquivosJSON = JSON.stringify(arquivosInfo);
    const valorPretensao = req.body.valorPretensao ? parseFloat(req.body.valorPretensao) : 0;
    
    console.log('Dados preparados:');
    console.log('- tipo_servico: arbitragem');
    console.log('- natureza_litigio:', req.body.naturezaLitigio);
    console.log('- valor_pretensao:', valorPretensao);
    console.log('- dados_formulario length:', dadosFormulario.length);
    console.log('- arquivos length:', arquivosJSON.length);
    
    console.log('📤 ETAPA 6: Executando INSERT na base de dados...');
    
    const [result] = await db.query(
      'INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos) VALUES (?, ?, ?, ?, ?)',
      ['arbitragem', req.body.naturezaLitigio, valorPretensao, dadosFormulario, arquivosJSON]
    );
    
    console.log('✅ INSERT bem-sucedido!');
    console.log('🎉 Processo de arbitragem #' + result.insertId + ' criado com sucesso!');
    
    console.log('📤 ETAPA 7: Configurando sessão e redirecionamento...');
    
    // Redirecionar de volta para a página do serviço com uma mensagem de sucesso
    req.session.mensagem = 'Seu requerimento de arbitragem foi enviado com sucesso! Entraremos em contato em breve.';
    req.session.tipoMensagem = 'success';
    
    console.log('✅ Redirecionando para /servico/arbitragem');
    res.redirect('/servico/arbitragem');
    
  } catch (error) {
    console.error('\n💥💥💥 ERRO CAPTURADO NO PROCESSAMENTO 💥💥💥');
    console.error('Tipo do erro:', error.constructor.name);
    console.error('Mensagem:', error.message);
    if (error.code) console.error('Código do erro:', error.code);
    if (error.field) console.error('Campo do erro:', error.field);
    if (error.storageErrors) console.error('Erros de armazenamento:', error.storageErrors);
    console.error('Stack completo:');
    console.error(error.stack);
    console.error('💥💥💥 FIM DO ERRO 💥💥💥\n');
    
    req.session.mensagem = `Erro ao processar: ${error.message}`;
    req.session.tipoMensagem = 'danger';
    res.redirect('/servico/arbitragem');
  }
});

// Rota para processar o formulário de mediação
app.post('/servico/mediacao/enviar', async (req, res) => {
  try {
    // Usar o middleware de upload para processar os arquivos
    const uploadMiddleware = upload.fields([
      { name: 'comprovativoPagamento', maxCount: 1 },
      { name: 'procuracao', maxCount: 1 },
      { name: 'comprovativoPoderes', maxCount: 1 },
      { name: 'documentosComplementares', maxCount: 5 }
    ]);
    
    // Executar o middleware manualmente
    await new Promise((resolve, reject) => {
      uploadMiddleware(req, res, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
    
    // Processar dados do formulário
    console.log('Novo requerimento de mediação recebido:', req.body);
    
    // Processar arquivos enviados
    let arquivosInfo = {};
    if (req.files) {
      Object.keys(req.files).forEach(key => {
        arquivosInfo[key] = req.files[key].map(f => ({
          filename: f.filename,
          originalname: f.originalname,
          path: f.path
        }));
      });
      
      console.log('Arquivos recebidos:', Object.keys(req.files).map(key => ({
        campo: key,
        arquivos: req.files[key].map(f => f.filename)
      })));
    }
    
    // Salvar os dados no banco de dados
    const dadosFormulario = JSON.stringify(req.body);
    const arquivosJSON = JSON.stringify(arquivosInfo);
    const valorPretensao = req.body.valorPretensao ? parseFloat(req.body.valorPretensao) : 0;
    
    const [result] = await db.query(
      'INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos) VALUES (?, ?, ?, ?, ?)',
      ['mediacao', req.body.naturezaLitigio, valorPretensao, dadosFormulario, arquivosJSON]
    );
    
    console.log(`Processo de mediação #${result.insertId} criado com sucesso!`);
    
    // Redirecionar de volta para a página do serviço com uma mensagem de sucesso
    req.session.mensagem = 'Seu requerimento de mediação foi enviado com sucesso! Entraremos em contato em breve.';
    req.session.tipoMensagem = 'success';
    
    res.redirect('/servico/mediacao');
  } catch (error) {
    console.error('Erro ao processar requerimento de mediação:', error);
    req.session.mensagem = 'Ocorreu um erro ao processar seu requerimento. Por favor, tente novamente.';
    req.session.tipoMensagem = 'danger';
    res.redirect('/servico/mediacao');
  }
});

// Rota para processar o formulário de conciliação
app.post('/servico/conciliacao/enviar', async (req, res) => {
  try {
    // Usar o middleware de upload para processar os arquivos
    const uploadMiddleware = upload.fields([
      { name: 'comprovativoPagamento', maxCount: 1 },
      { name: 'procuracao', maxCount: 1 },
      { name: 'comprovativoPoderes', maxCount: 1 },
      { name: 'documentosComplementares', maxCount: 5 }
    ]);
    
    // Executar o middleware manualmente
    await new Promise((resolve, reject) => {
      uploadMiddleware(req, res, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
    
    // Processar dados do formulário
    console.log('Novo requerimento de conciliação recebido:', req.body);
    
    // Processar arquivos enviados
    let arquivosInfo = {};
    if (req.files) {
      Object.keys(req.files).forEach(key => {
        arquivosInfo[key] = req.files[key].map(f => ({
          filename: f.filename,
          originalname: f.originalname,
          path: f.path
        }));
      });
      
      console.log('Arquivos recebidos:', Object.keys(req.files).map(key => ({
        campo: key,
        arquivos: req.files[key].map(f => f.filename)
      })));
    }
    
    // Salvar os dados no banco de dados
    const dadosFormulario = JSON.stringify(req.body);
    const arquivosJSON = JSON.stringify(arquivosInfo);
    const valorPretensao = req.body.valorPretensao ? parseFloat(req.body.valorPretensao) : 0;
    
    const [result] = await db.query(
      'INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos) VALUES (?, ?, ?, ?, ?)',
      ['conciliacao', req.body.naturezaLitigio, valorPretensao, dadosFormulario, arquivosJSON]
    );
    
    console.log(`Processo de conciliação #${result.insertId} criado com sucesso!`);
    
    // Redirecionar de volta para a página do serviço com uma mensagem de sucesso
    req.session.mensagem = 'Seu requerimento de conciliação foi enviado com sucesso! Entraremos em contato em breve.';
    req.session.tipoMensagem = 'success';
    
    res.redirect('/servico/conciliacao');
  } catch (error) {
    console.error('Erro ao processar requerimento de conciliação:', error);
    req.session.mensagem = 'Ocorreu um erro ao processar seu requerimento. Por favor, tente novamente.';
    req.session.tipoMensagem = 'danger';
    res.redirect('/servico/conciliacao');
  }
});

// Importar o módulo de e-mail (comentado por enquanto para evitar erros)
// const emailModule = require('./email');

app.get('/login', (req, res) => {
  console.log('=== ACESSO À PÁGINA DE LOGIN ===');
  console.log('IP do cliente:', req.ip);
  console.log('User-Agent:', req.headers['user-agent']);
  res.render('login', { error: req.session.loginError });
  delete req.session.loginError;
});

// Página de teste de login
app.get('/teste-login', (req, res) => {
  console.log('🧪 Página de teste de login acessada');
  res.render('teste-login', { error: req.session.loginError });
  delete req.session.loginError;
});

// Rota de teste de autenticação
app.post('/teste-auth', async (req, res) => {
  console.log('\n🧪🧪🧪 TESTE DE AUTENTICAÇÃO 🧪🧪🧪');
  console.log('==========================================');
  console.log('⏰ Timestamp:', new Date().toLocaleString());
  console.log('📡 Método:', req.method);
  console.log('🌐 URL:', req.originalUrl);
  console.log('📋 Headers:', JSON.stringify(req.headers, null, 2));
  console.log('📦 Body completo:', JSON.stringify(req.body, null, 2));
  
  const { email, password } = req.body;
  console.log('✉️ Email extraído:', email);
  console.log('🔑 Senha extraída:', password ? `[${password.length} caracteres]` : 'VAZIA');
  
  try {
    console.log('🔍 Buscando usuário na base de dados...');
    const [users] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, email]);
    console.log('📊 Resultado da busca:', users.length, 'usuários encontrados');
    
    if (users.length > 0) {
      const user = users[0];
      console.log('👤 Usuário encontrado:', user.username);
      console.log('🏷️ Tipo:', user.profile_type);
      
      console.log('🔐 Verificando senha...');
      const bcrypt = require('bcryptjs');
      const senhaCorreta = await bcrypt.compare(password, user.password);
      console.log('✅ Resultado verificação:', senhaCorreta);
      
      if (senhaCorreta) {
        console.log('🎉 SUCESSO! Configurando sessão...');
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.profileType = user.profile_type;
        req.session.adminLoggedIn = true;
        
        console.log('📝 Sessão configurada:');
        console.log('   - userId:', req.session.userId);
        console.log('   - username:', req.session.username);
        console.log('   - profileType:', req.session.profileType);
        console.log('   - adminLoggedIn:', req.session.adminLoggedIn);
        
        console.log('🔄 Redirecionando para dashboard...');
        console.log('==========================================\n');
        return res.redirect('/dashboard');
      } else {
        console.log('❌ Senha incorreta!');
        req.session.loginError = 'Senha incorreta!';
      }
    } else {
      console.log('❌ Usuário não encontrado!');
      req.session.loginError = 'Usuário não encontrado!';
    }
  } catch (error) {
    console.log('💥 ERRO CAPTURADO:');
    console.log('Tipo:', error.constructor.name);
    console.log('Mensagem:', error.message);
    console.log('Stack:', error.stack);
    req.session.loginError = 'Erro interno: ' + error.message;
  }
  
  console.log('🔄 Redirecionando para teste-login com erro...');
  console.log('==========================================\n');
  res.redirect('/teste-login');
});

app.post('/auth', async (req, res) => {
  console.log('=== POST /AUTH RECEBIDO ===');
  console.log('req.body completo:', req.body);
  console.log('req.headers:', req.headers);
  console.log('req.method:', req.method);
  
  const { email, password } = req.body;
  
  console.log('=== TENTATIVA DE LOGIN ===');
  console.log('Email/Username extraído:', email);
  console.log('Senha extraída:', password ? '*'.repeat(password.length) : 'vazia');
  console.log('Tipo de email:', typeof email);
  console.log('Tipo de password:', typeof password);
  
  try {
    // Buscar usuário pelo e-mail ou username (para admin)
    const [users] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, email]);
    const user = users[0];
    
    console.log('Usuário encontrado:', user ? `${user.username} (${user.profile_type})` : 'nenhum');
    
    if (user) {
      console.log('Usuário encontrado, verificando senha...');
      
      // Usar bcrypt diretamente para evitar problemas
      const bcrypt = require('bcryptjs');
      const senhaCorreta = await bcrypt.compare(password, user.password);
      console.log('Resultado da verificação de senha:', senhaCorreta);
      
      if (senhaCorreta) {
        console.log('Senha validada com sucesso!');
        
        // Registrar log de login bem-sucedido
        logActivity('LOGIN', user.username, 'Login realizado com sucesso', `Tipo: ${user.profile_type}`, req.ip);
        
        // Se for admin, fazer login direto sem verificação em duas etapas
        if (user.profile_type === 'admin') {
          console.log('Usuário é admin, configurando sessão...');
          
          req.session.userId = user.id;
          req.session.username = user.username;
          req.session.profileType = user.profile_type;
          req.session.adminLoggedIn = true;
          
          console.log('Sessão configurada com sucesso!');
          console.log('Auth: Usuário é admin, redirecionando para dashboard de admin');
          return res.redirect('/dashboard');
        }
        
        // Para outros usuários (não admin), fazer login direto por enquanto
        console.log('Usuário não é admin, fazendo login direto...');
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.profileType = user.profile_type;
        
        console.log('Login de usuário não-admin aprovado, redirecionando...');
        return res.redirect('/dashboard');
        
        /* CÓDIGO DE 2FA COMENTADO POR ENQUANTO
        // Para outros usuários, gerar código de verificação
        const verificationCode = emailModule.generateVerificationCode();
        const expiresAt = new Date();
        expiresAt.setMinutes(expiresAt.getMinutes() + 10); // Código válido por 10 minutos
        
        // Salvar código e data de expiração no banco de dados
        await db.query(
          'UPDATE users SET two_factor_code = ?, two_factor_expires = ? WHERE id = ?',
          [verificationCode, expiresAt, user.id]
        );
        
        // Enviar e-mail com o código
        const emailSent = await emailModule.sendVerificationCode(user.email, verificationCode);
        
        if (emailSent) {
          // Armazenar informações temporárias na sessão para a verificação
          req.session.tempUserId = user.id;
          req.session.tempEmail = user.email;
        
        // Redirecionar para a página de verificação
        return res.redirect('/verificacao');
      } else {
        req.session.loginError = 'Não foi possível enviar o código de verificação. Tente novamente.';
        return res.redirect('/login');
      }
        */
      } else {
        console.log('❌ Senha incorreta!');
        req.session.loginError = 'E-mail ou senha inválidos!';
        return res.redirect('/login');
      }
    } else {
      console.log('❌ Usuário não encontrado!');
      req.session.loginError = 'E-mail ou senha inválidos!';
      return res.redirect('/login');
    }
  } catch (error) {
    console.log('\n==========================================');
    console.log('❌ ERRO DE AUTENTICAÇÃO CAPTURADO:');
    console.log('==========================================');
    console.log('Tipo do erro:', error.constructor.name);
    console.log('Mensagem:', error.message);
    console.log('Stack:', error.stack);
    console.log('==========================================\n');
    
    req.session.loginError = 'Erro no servidor. Tente novamente.';
    return res.redirect('/login');
  }
});

// Rota para a página de verificação
app.get('/verificacao', (req, res) => {
  // Verificar se há um usuário temporário na sessão
  if (!req.session.tempUserId || !req.session.tempEmail) {
    return res.redirect('/login');
  }
  
  res.render('verificacao', { 
    email: req.session.tempEmail,
    error: req.session.verificationError,
    message: req.session.verificationMessage
  });
  
  delete req.session.verificationError;
  delete req.session.verificationMessage;
});

// Rota para verificar o código
app.post('/verify', async (req, res) => {
  const { code } = req.body;
  
  try {
    // Verificar se há um usuário temporário na sessão
    if (!req.session.tempUserId) {
      req.session.loginError = 'Sessão expirada. Por favor, faça login novamente.';
      return res.redirect('/login');
    }
    
    // Buscar usuário pelo ID
    const [users] = await db.query('SELECT * FROM users WHERE id = ?', [req.session.tempUserId]);
    const user = users[0];
    
    if (!user) {
      req.session.loginError = 'Usuário não encontrado. Por favor, faça login novamente.';
      return res.redirect('/login');
    }
    
    // Verificar se o código é válido e não expirou
    const now = new Date();
    const expiresAt = new Date(user.two_factor_expires);
    
    if (user.two_factor_code !== code) {
      req.session.verificationError = 'Código de verificação inválido. Tente novamente.';
      return res.redirect('/verificacao');
    }
    
    if (now > expiresAt) {
      req.session.verificationError = 'Código de verificação expirado. Por favor, solicite um novo código.';
      return res.redirect('/verificacao');
    }
    
    // Limpar o código de verificação
    await db.query(
      'UPDATE users SET two_factor_code = NULL, two_factor_expires = NULL WHERE id = ?',
      [user.id]
    );
    
    // Autenticar o usuário
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.profileType = user.profile_type;
    req.session.adminLoggedIn = false;
    
    // Limpar dados temporários
    delete req.session.tempUserId;
    delete req.session.tempEmail;
    
    // Verificar se o usuário é um profissional
    const [profissionais] = await db.query(
      'SELECT * FROM profissionais WHERE user_id = ?',
      [user.id]
    );
    
    if (profissionais.length > 0) {
      // Se for um profissional, redirecionar para a dashboard específica
      req.session.profissional = profissionais[0];
      console.log(`Verify: Profissional encontrado, tipo=${profissionais[0].tipo}, redirecionando para dashboard de profissional`);
      return res.redirect('/profissional/dashboard');
    } else {
      // Para outros tipos de usuário, redirecionar para a dashboard padrão
      console.log(`Verify: Usuário com perfil ${user.profile_type}, redirecionando para dashboard padrão`);
      return res.redirect('/dashboard');
    }
  } catch (error) {
    console.error('Erro na verificação:', error);
    req.session.verificationError = 'Erro no servidor. Tente novamente.';
    return res.redirect('/verificacao');
  }
});

// Rota para reenviar o código
app.get('/resend-code', async (req, res) => {
  try {
    // Verificar se há um usuário temporário na sessão
    if (!req.session.tempUserId) {
      req.session.loginError = 'Sessão expirada. Por favor, faça login novamente.';
      return res.redirect('/login');
    }
    
    // Buscar usuário pelo ID
    const [users] = await db.query('SELECT * FROM users WHERE id = ?', [req.session.tempUserId]);
    const user = users[0];
    
    if (!user) {
      req.session.loginError = 'Usuário não encontrado. Por favor, faça login novamente.';
      return res.redirect('/login');
    }
    
    // Gerar novo código de verificação
    const verificationCode = emailModule.generateVerificationCode();
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 10); // Código válido por 10 minutos
    
    // Salvar código e data de expiração no banco de dados
    await db.query(
      'UPDATE users SET two_factor_code = ?, two_factor_expires = ? WHERE id = ?',
      [verificationCode, expiresAt, user.id]
    );
    
    // Enviar e-mail com o código
    const emailSent = await emailModule.sendVerificationCode(user.email, verificationCode);
    
    if (emailSent) {
      req.session.verificationMessage = 'Um novo código de verificação foi enviado para o seu e-mail.';
    } else {
      req.session.verificationError = 'Não foi possível enviar o código de verificação. Tente novamente.';
    }
    
    return res.redirect('/verificacao');
  } catch (error) {
    console.error('Erro ao reenviar código:', error);
    req.session.verificationError = 'Erro no servidor. Tente novamente.';
    return res.redirect('/verificacao');
  }
});

app.get('/dashboard', isLoggedIn, async (req, res) => {
  console.log('=== ACESSO AO DASHBOARD ===');
  console.log('Usuário:', req.session.username);
  console.log('Tipo de perfil:', req.session.profileType);
  
  try {
    // Se for admin, mostrar usuários
    if (req.session.profileType === 'admin') {
      console.log('Renderizando dashboard do admin...');
      
      const [users] = await db.query(
        'SELECT id, username, profile_type FROM users ORDER BY id'
      );
      
      console.log('Usuários encontrados:', users.length);
      
      // Stats simplificadas (sem processos por enquanto)
      const stats = {
        processosPendentes: 0,
        processosAndamento: 0,
        processosEncerrados: 0,
        pagamentosPendentes: 0
      };
      
      // Obter estatísticas dos logs para a dashboard
      let logStats = {
        total: 0,
        errors: 0,
        warnings: 0,
        info: 0,
        today: 0,
        lastWeek: 0
      };
      
      let recentLogs = [];
      
      // Tentar obter dados dos logs
      try {
        // Obter estatísticas dos logs
        logStats = await getLogStats();
        
        // Obter logs recentes (últimos 10)
        const logsResult = await getLogsAdvanced({
          limit: 10,
          sortBy: 'timestamp',
          sortOrder: 'DESC'
        });
        
        recentLogs = logsResult.logs || [];
        
        console.log('Estatísticas dos logs carregadas:', logStats);
        console.log('Logs recentes carregados:', recentLogs.length);
      } catch (error) {
        console.error('Erro ao carregar dados dos logs para dashboard:', error);
        // Manter valores padrão em caso de erro
      }
      
      console.log('Renderizando página dashboard...');
      res.render('dashboard', {
        username: req.session.username,
        profileType: req.session.profileType,
        users,
        stats: stats,
        logStats: logStats,
        recentLogs: recentLogs,
        createSuccess: req.session.createSuccess,
        createError: req.session.createError
      });
    } 
    // Se for financeiro, redirecionar para pagamentos
    else if (req.session.profileType === 'financeiro') {
      res.redirect('/pagamentos');
    }
    // Se for uma parte (demandante, demandado, etc.)
    else if (req.session.profileType.includes('consultor') || req.session.profileType.includes('analista')) {
      // Obter o processo associado ao usuário
      const [users] = await db.query('SELECT processo_id FROM users WHERE username = ?', [req.session.username]);
      
      if (users.length === 0 || !users[0].processo_id) {
        return res.render('dashboard-parte', {
          username: req.session.username,
          profileType: req.session.profileType,
          mensagem: 'Não há processo associado à sua conta.',
          tipoMensagem: 'warning',
          processo: null,
          dadosFormulario: null,
          demandantes: [],
          demandados: [],
          mandatarios: [],
          representantes: [],
          contraInteressados: [],
          arquivos: {},
          canEdit: false
        });
      }
      
      const processoId = users[0].processo_id;
      
      // Obter dados do processo
      const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
      
      if (processos.length === 0) {
        return res.render('dashboard-parte', {
          username: req.session.username,
          profileType: req.session.profileType,
          mensagem: 'Processo não encontrado.',
          tipoMensagem: 'danger',
          processo: null,
          dadosFormulario: null,
          demandantes: [],
          demandados: [],
          mandatarios: [],
          representantes: [],
          contraInteressados: [],
          arquivos: {},
          canEdit: false
        });
      }
      
      const processo = processos[0];
      processo.valor_pretensao = parseFloat(processo.valor_pretensao) || 0;
      
      // Parsear os dados do formulário
      const dadosFormulario = JSON.parse(processo.dados_formulario);
      
      // Extrair as partes do processo
      const demandantes = dadosFormulario.demandantes || [];
      const demandados = dadosFormulario.demandados || [];
      const mandatarios = dadosFormulario.mandatarios || [];
      const representantes = dadosFormulario.representantes || [];
      const contraInteressados = dadosFormulario.contraInteressados || [];
      
      // Parsear os arquivos
      const arquivos = processo.arquivos ? JSON.parse(processo.arquivos) : {};
      
      // Verificar se o usuário pode editar o processo (apenas consultores podem editar)
      const canEdit = req.session.profileType.includes('consultor');
      
      res.render('dashboard-parte', {
        username: req.session.username,
        profileType: req.session.profileType,
        mensagem: req.session.mensagem || null,
        tipoMensagem: req.session.tipoMensagem || 'info',
        processo,
        dadosFormulario,
        demandantes,
        demandados,
        mandatarios,
        representantes,
        contraInteressados,
        arquivos,
        canEdit
      });
      
      delete req.session.mensagem;
      delete req.session.tipoMensagem;
    }
    // Outros tipos de usuário
    else {
      res.render('dashboard', {
        username: req.session.username,
        profileType: req.session.profileType,
        users: [], // Adicionar array vazio para evitar erro
        stats: {
          processosPendentes: 0,
          processosAndamento: 0,
          processosEncerrados: 0,
          pagamentosPendentes: 0
        },
        createSuccess: req.session.createSuccess,
        createError: req.session.createError
      });
    }
    
    delete req.session.createSuccess;
    delete req.session.createError;
  } catch (error) {
    console.error('Erro ao carregar dashboard:', error);
    req.session.createError = 'Erro ao carregar dados: ' + error.message;
    res.render('dashboard', {
      username: req.session.username,
      profileType: req.session.profileType,
      users: [],
      createSuccess: null,
      createError: req.session.createError
    });
    delete req.session.createError;
  }
});

// Rota para criar usuário
app.post('/users', isAdmin, async (req, res) => {
  const { user: username, profile_type: profileType, password, email } = req.body;
  
  // Validar se o email foi fornecido
  if (!email || !email.includes('@')) {
    req.session.createError = 'Email válido é obrigatório!';
    return res.redirect('/dashboard');
  }
  
  // Definir os tipos de perfis válidos
  const validProfileTypes = [
    'arbitro', 'mediador', 'secretario', 'financeiro', 'consultor', 
    'analista', 'auditor', 'coordenador', 'assistente', 'supervisor',
    'secretario_geral', 'secretario_processo'
  ];
  
  if (!validProfileTypes.includes(profileType)) {
    req.session.createError = 'Tipo de perfil inválido!';
    return res.redirect('/dashboard');
  }
  
  // Senha para novos usuários
  const userPassword = password || 'user123'; // Senha padrão se nenhuma for fornecida
  
  try {
    // Verificar se o email já existe
    const [existingUsers] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUsers.length > 0) {
      req.session.createError = 'Este email já está sendo usado por outro usuário!';
      return res.redirect('/dashboard');
    }
    
    // Verificar se o username já existe
    const [existingUsernames] = await db.query('SELECT id FROM users WHERE username = ?', [username]);
    if (existingUsernames.length > 0) {
      req.session.createError = 'Este nome de usuário já existe!';
      return res.redirect('/dashboard');
    }
    
    const hashedPassword = await db.hashPassword(userPassword);
    await db.query(
      'INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)',
      [username, hashedPassword, profileType, email]
    );
    
    // Enviar email com as credenciais
    try {
      await sendAccountCredentials(email, username, userPassword);
      req.session.createSuccess = `Perfil criado com sucesso! Tipo: ${profileType}. Email enviado para: ${email}`;
    } catch (emailError) {
      console.error('Erro ao enviar email:', emailError);
      req.session.createSuccess = `Perfil criado com sucesso! Tipo: ${profileType}. Erro ao enviar email: ${emailError.message}`;
    }
  } catch (error) {
    req.session.createError = `Erro ao criar perfil: ${error.message}`;
  }
  
  res.redirect('/dashboard');
});

// Rota para redefinir senha
app.get('/users/reset-password/:id', isAdmin, async (req, res) => {
  const userId = req.params.id;
  
  try {
    // Verificar se não é o admin
    const [users] = await db.query('SELECT username FROM users WHERE id = ?', [userId]);
    const user = users[0];
    
    if (user && user.username !== 'admin') {
      // Redefinir para a senha padrão
      const defaultPassword = 'user123';
      const hashedPassword = await db.hashPassword(defaultPassword);
      
      await db.query('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, userId]);
      
      req.session.createSuccess = `Senha redefinida com sucesso para o usuário: ${user.username}`;
    } else {
      req.session.createError = 'Usuário não encontrado ou não pode ser modificado.';
    }
  } catch (error) {
    req.session.createError = `Erro ao redefinir senha: ${error.message}`;
  }
  
  res.redirect('/dashboard');
});

// Rota para excluir usuário
app.get('/users/delete/:id', isAdmin, async (req, res) => {
  const userId = req.params.id;
  
  try {
    // Verificar se não é o admin
    const [users] = await db.query('SELECT username FROM users WHERE id = ?', [userId]);
    const user = users[0];
    
    if (user && user.username !== 'admin') {
      await db.query('DELETE FROM users WHERE id = ?', [userId]);
      
      req.session.createSuccess = `Usuário excluído com sucesso: ${user.username}`;
    } else {
      req.session.createError = 'Usuário não encontrado ou não pode ser excluído.';
    }
  } catch (error) {
    req.session.createError = `Erro ao excluir usuário: ${error.message}`;
  }
  
  res.redirect('/dashboard');
});

// Rota para a página de usuários (admin)
app.get('/usuarios', isAdmin, async (req, res) => {
  try {
    const [users] = await db.query(
      'SELECT id, username, profile_type, created_at FROM users ORDER BY created_at DESC'
    );
    
    res.render('dashboard', {
      username: req.session.username,
      profileType: req.session.profileType,
      users,
      createSuccess: req.session.createSuccess,
      createError: req.session.createError
    });
    
    delete req.session.createSuccess;
    delete req.session.createError;
  } catch (error) {
    console.error('Erro ao carregar usuários:', error);
    req.session.createError = 'Erro ao carregar usuários: ' + error.message;
    res.render('dashboard', {
      username: req.session.username,
      profileType: req.session.profileType,
      users: [],
      createSuccess: null,
      createError: req.session.createError
    });
    delete req.session.createError;
  }
});

// Rota para listar processos (admin)
app.get('/processos', isAdmin, async (req, res) => {
  try {
    const pagina = parseInt(req.query.pagina) || 1;
    const itensPorPagina = 9;
    const offset = (pagina - 1) * itensPorPagina;
    
    // Filtros
    const filtros = {
      tipo: req.query.tipo || '',
      status: req.query.status || '',
      pagamento: req.query.pagamento || ''
    };
    
    // Construir a consulta SQL com filtros
    let whereClause = [];
    let params = [];
    
    if (filtros.tipo) {
      whereClause.push('tipo_servico = ?');
      params.push(filtros.tipo);
    }
    
    if (filtros.status) {
      whereClause.push('status = ?');
      params.push(filtros.status);
    }
    
    if (filtros.pagamento !== '') {
      whereClause.push('pagamento_verificado = ?');
      params.push(parseInt(filtros.pagamento));
    }
    
    const whereSQL = whereClause.length > 0 ? 'WHERE ' + whereClause.join(' AND ') : '';
    
    // Consulta para obter processos com paginação
    const [processos] = await db.query(
      `SELECT * FROM processos ${whereSQL} ORDER BY data_criacao DESC LIMIT ? OFFSET ?`,
      [...params, itensPorPagina, offset]
    );
    
    // Converter valores numéricos
    processos.forEach(processo => {
      processo.valor_pretensao = parseFloat(processo.valor_pretensao) || 0;
    });
    
    // Consulta para obter o total de processos (para paginação)
    const [totalResult] = await db.query(
      `SELECT COUNT(*) as total FROM processos ${whereSQL}`,
      params
    );
    
    const totalProcessos = totalResult[0].total;
    const totalPaginas = Math.ceil(totalProcessos / itensPorPagina);
    
    res.render('processos', {
      username: req.session.username,
      processos,
      paginaAtual: pagina,
      totalPaginas,
      filtros,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao listar processos:', error);
    req.session.mensagem = 'Erro ao carregar processos: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
});

// Rota para visualizar detalhes de um processo (admin)
app.get('/processos/:id', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/processos');
    }
    
    const processo = processos[0];
    
    // Parsear os dados do formulário e arquivos
    const dadosFormulario = JSON.parse(processo.dados_formulario);
    const arquivos = processo.arquivos ? JSON.parse(processo.arquivos) : {};
    
    // Obter documentos submetidos pelas partes
    const [documentos] = await db.query(`
      SELECT d.*, 
        CASE 
          WHEN d.tipo = 'comprovativoPagamento' THEN 'Comprovativo de Pagamento'
          WHEN d.tipo = 'peticaoInicial' THEN 'Petição Inicial'
          WHEN d.tipo = 'contestacao' THEN 'Contestação'
          WHEN d.tipo = 'replica' THEN 'Réplica'
          WHEN d.tipo = 'documentoIdentificacao' THEN 'Documento de Identificação'
          WHEN d.tipo = 'procuracao' THEN 'Procuração'
          WHEN d.tipo = 'contratoArbitragem' THEN 'Contrato de Arbitragem'
          WHEN d.tipo = 'parecerTecnico' THEN 'Parecer Técnico'
          WHEN d.tipo = 'provaDocumental' THEN 'Prova Documental'
          ELSE d.tipo
        END as tipo_formatado
      FROM documentos d
      WHERE d.processo_id = ?
      ORDER BY d.data_envio DESC
    `, [processoId]);
    
    // Agrupar documentos por tipo
    const documentosPorTipo = {};
    documentos.forEach(doc => {
      if (!documentosPorTipo[doc.tipo]) {
        documentosPorTipo[doc.tipo] = [];
      }
      documentosPorTipo[doc.tipo].push(doc);
    });
    
    // Obter informações do profissional responsável, se houver
    let responsavel = null;
    if (processo.responsavel_id) {
      const [usuarios] = await db.query(`
        SELECT u.*, p.tipo as tipo_profissional, p.especialidade, p.biografia
        FROM users u
        LEFT JOIN profissionais p ON u.id = p.user_id
        WHERE u.id = ?
      `, [processo.responsavel_id]);
      
      if (usuarios.length > 0) {
        responsavel = usuarios[0];
      }
    }
    
    res.render('processo-detalhes', {
      username: req.session.username,
      processo,
      dadosFormulario,
      arquivos,
      documentos,
      documentosPorTipo,
      responsavel,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao visualizar processo:', error);
    req.session.mensagem = 'Erro ao carregar detalhes do processo: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/processos');
  }
});

// Rota para o admin solicitar documentos às partes
app.get('/documentos/pedidos/admin/:processoId', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.processoId;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/processos');
    }
    
    const processo = processos[0];
    
    // Obter lista de usuários associados ao processo
    const [usuarios] = await db.query(`
      SELECT u.id, u.username, u.nome_completo, u.profile_type,
        CASE 
          WHEN u.profile_type LIKE '%consultor%' THEN 'Consultor'
          WHEN u.profile_type LIKE '%analista%' THEN 'Analista'
          ELSE u.profile_type
        END as tipo_formatado
      FROM users u
      WHERE u.processo_id = ?
    `, [processoId]);
    
    res.render('admin-solicitar-documentos', {
      username: req.session.username,
      processo,
      usuarios,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de solicitação de documentos:', error);
    req.session.mensagem = 'Erro ao carregar página: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/processos/' + req.params.processoId);
  }
});

// Rota para processar a solicitação de documentos pelo admin
app.post('/documentos/pedidos/admin/:processoId', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.processoId;
    const { destinatario, tipoDocumento, outroTipo, descricaoPedido, prazoLimite } = req.body;
    
    // Determinar o tipo final do documento
    const tipoFinal = tipoDocumento === 'Outro' ? outroTipo : tipoDocumento;
    
    // Inserir o pedido no banco de dados
    await db.query(
      'INSERT INTO pedidos_documentos (processo_id, solicitante, destinatario, tipo_documento, descricao, prazo_limite) VALUES (?, ?, ?, ?, ?, ?)',
      [processoId, req.session.username, destinatario, tipoFinal, descricaoPedido, prazoLimite || null]
    );
    
    req.session.mensagem = 'Pedido de documento enviado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/processos/' + processoId);
  } catch (error) {
    console.error('Erro ao criar pedido de documento:', error);
    req.session.mensagem = 'Erro ao criar pedido: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/pedidos/admin/' + req.params.processoId);
  }
});

// Rota para iniciar um processo (admin)
app.get('/processos/:id/iniciar', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Atualizar status do processo
    await db.query(
      'UPDATE processos SET status = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
      ['em_andamento', processoId]
    );
    
    req.session.mensagem = 'Processo iniciado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect(`/processos/${processoId}`);
  } catch (error) {
    console.error('Erro ao iniciar processo:', error);
    req.session.mensagem = 'Erro ao iniciar processo: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect(`/processos/${req.params.id}`);
  }
});

// Rota para encerrar um processo (admin)
app.get('/processos/:id/encerrar', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Atualizar status do processo
    await db.query(
      'UPDATE processos SET status = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
      ['encerrado', processoId]
    );
    
    req.session.mensagem = 'Processo encerrado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect(`/processos/${processoId}`);
  } catch (error) {
    console.error('Erro ao encerrar processo:', error);
    req.session.mensagem = 'Erro ao encerrar processo: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect(`/processos/${req.params.id}`);
  }
});

// Rota para verificar pagamento (admin)
app.get('/processos/:id/verificar-pagamento', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Atualizar status de pagamento
    await db.query(
      'UPDATE processos SET pagamento_verificado = 1, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
      [processoId]
    );
    
    req.session.mensagem = 'Pagamento verificado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect(`/processos/${processoId}`);
  } catch (error) {
    console.error('Erro ao verificar pagamento:', error);
    req.session.mensagem = 'Erro ao verificar pagamento: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect(`/processos/${req.params.id}`);
  }
});

// Rota para a página de criar contas para as partes (admin)
app.get('/processos/:id/criar-contas', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/processos');
    }
    
    const processo = processos[0];
    processo.valor_pretensao = parseFloat(processo.valor_pretensao) || 0;
    
    // Parsear os dados do formulário
    const dadosFormulario = JSON.parse(processo.dados_formulario);
    
    // Extrair as partes do processo
    const demandantes = dadosFormulario.demandantes || [];
    const demandados = dadosFormulario.demandados || [];
    const mandatarios = dadosFormulario.mandatarios || [];
    const representantes = dadosFormulario.representantes || [];
    const contraInteressados = dadosFormulario.contraInteressados || [];
    
    // Obter todas as contas existentes para verificar se já existem contas para as partes
    const [contas] = await db.query('SELECT id, username, email, profile_type FROM users');
    
    res.render('criar-contas-partes', {
      username: req.session.username,
      processo,
      demandantes,
      demandados,
      mandatarios,
      representantes,
      contraInteressados,
      contas,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de criar contas:', error);
    req.session.mensagem = 'Erro ao carregar página: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect(`/processos/${req.params.id}`);
  }
});

// Rota para criar conta para uma parte (admin)
app.post('/processos/:id/criar-conta', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    const { email, nome, tipo, username, password, permissao } = req.body;
    
    // Verificar se já existe uma conta com este email
    const [usuariosExistentes] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    
    if (usuariosExistentes.length > 0) {
      req.session.mensagem = `Já existe uma conta com o email ${email}.`;
      req.session.tipoMensagem = 'warning';
      return res.redirect(`/processos/${processoId}/criar-contas`);
    }
    
    // Verificar se já existe um usuário com este username
    const [usernamesExistentes] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    
    if (usernamesExistentes.length > 0) {
      req.session.mensagem = `Já existe um usuário com o nome ${username}.`;
      req.session.tipoMensagem = 'warning';
      return res.redirect(`/processos/${processoId}/criar-contas`);
    }
    
    // Determinar o tipo de perfil com base no tipo da parte e permissão
    // Usar apenas os tipos de perfil permitidos pelo CHECK constraint
    let profileType;
    if (permissao === 'editar') {
      profileType = 'consultor'; // Perfil que pode editar
    } else {
      profileType = 'analista'; // Perfil que pode apenas visualizar
    }
    
    // Criar a conta
    const hashedPassword = await db.hashPassword(password || '123456'); // Senha padrão se não for fornecida
    
    await db.query(
      'INSERT INTO users (username, password, email, nome_completo, profile_type, processo_id) VALUES (?, ?, ?, ?, ?, ?)',
      [username, hashedPassword, email, nome, profileType, processoId]
    );
    
    req.session.mensagem = `Conta criada com sucesso para ${nome}.`;
    req.session.tipoMensagem = 'success';
    res.redirect(`/processos/${processoId}/criar-contas`);
  } catch (error) {
    console.error('Erro ao criar conta:', error);
    req.session.mensagem = 'Erro ao criar conta: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect(`/processos/${req.params.id}/criar-contas`);
  }
});

// Rota para listar pagamentos (financeiro)
app.get('/pagamentos', isFinanceiro, async (req, res) => {
  try {
    const pagina = parseInt(req.query.pagina) || 1;
    const itensPorPagina = 9;
    const offset = (pagina - 1) * itensPorPagina;
    
    // Filtros
    const filtros = {
      tipo: req.query.tipo || '',
      status: req.query.status || ''
    };
    
    // Construir a consulta SQL com filtros
    let whereClause = [];
    let params = [];
    
    if (filtros.tipo) {
      whereClause.push('tipo_servico = ?');
      params.push(filtros.tipo);
    }
    
    if (filtros.status !== '') {
      whereClause.push('pagamento_verificado = ?');
      params.push(parseInt(filtros.status));
    }
    
    const whereSQL = whereClause.length > 0 ? 'WHERE ' + whereClause.join(' AND ') : '';
    
    // Consulta para obter processos com paginação
    const [processos] = await db.query(
      `SELECT * FROM processos ${whereSQL} ORDER BY data_criacao DESC LIMIT ? OFFSET ?`,
      [...params, itensPorPagina, offset]
    );
    
    // Consulta para obter o total de processos (para paginação)
    const [totalResult] = await db.query(
      `SELECT COUNT(*) as total FROM processos ${whereSQL}`,
      params
    );
    
    // Processar os dados para mostrar apenas os comprovantes de pagamento
    const pagamentos = processos.map(processo => {
      const arquivos = processo.arquivos ? JSON.parse(processo.arquivos) : {};
      return {
        ...processo,
        valor_pretensao: parseFloat(processo.valor_pretensao) || 0,
        comprovativo: arquivos.comprovativoPagamento || []
      };
    });
    
    const totalProcessos = totalResult[0].total;
    const totalPaginas = Math.ceil(totalProcessos / itensPorPagina);
    
    res.render('pagamentos', {
      username: req.session.username,
      pagamentos,
      paginaAtual: pagina,
      totalPaginas,
      filtros,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao listar pagamentos:', error);
    req.session.mensagem = 'Erro ao carregar pagamentos: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
});

// Rota para verificar pagamento (financeiro)
app.get('/pagamentos/:id/verificar', isFinanceiro, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Atualizar status de pagamento
    await db.query(
      'UPDATE processos SET pagamento_verificado = 1, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
      [processoId]
    );
    
    req.session.mensagem = 'Pagamento verificado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/pagamentos');
  } catch (error) {
    console.error('Erro ao verificar pagamento:', error);
    req.session.mensagem = 'Erro ao verificar pagamento: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/pagamentos');
  }
});

// Rota para servir arquivos de upload
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Rota para logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Rota para a página de submeter documentos
app.get('/documentos/submeter', isLoggedIn, async (req, res) => {
  try {
    // Verificar se o usuário é um profissional
    const [profissionais] = await db.query('SELECT * FROM profissionais WHERE user_id = ?', [req.session.userId]);
    
    if (profissionais.length > 0) {
      // Se for um profissional, redirecionar para a dashboard de profissional
      req.session.mensagem = 'Como profissional, você deve acessar os documentos através da página de detalhes do processo.';
      req.session.tipoMensagem = 'info';
      return res.redirect('/profissional/dashboard');
    }
    
    // Obter o processo associado ao usuário
    const [users] = await db.query('SELECT processo_id FROM users WHERE username = ?', [req.session.username]);
    
    if (users.length === 0 || !users[0].processo_id) {
      return res.render('submeter-documentos', {
        username: req.session.username,
        profileType: req.session.profileType,
        mensagem: 'Não há processo associado à sua conta.',
        tipoMensagem: 'warning',
        processo: null,
        documentos: [],
        isAdmin: req.session.profileType === 'admin'
      });
    }
    
    const processoId = users[0].processo_id;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
    
    if (processos.length === 0) {
      return res.render('submeter-documentos', {
        username: req.session.username,
        profileType: req.session.profileType,
        mensagem: 'Processo não encontrado.',
        tipoMensagem: 'danger',
        processo: null,
        documentos: [],
        isAdmin: req.session.profileType === 'admin'
      });
    }
    
    const processo = processos[0];
    
    // Verificar se a petição inicial já foi submetida
    const [peticaoInicial] = await db.query(`
      SELECT * FROM documentos 
      WHERE processo_id = ? AND tipo = 'peticaoInicial'
      ORDER BY data_envio DESC
      LIMIT 1
    `, [processoId]);
    
    // Calcular prazo para submissão da petição inicial (30 dias a partir da criação do processo)
    const dataCriacao = new Date(processo.data_criacao);
    const hoje = new Date();
    const diasDecorridos = Math.floor((hoje - dataCriacao) / (1000 * 60 * 60 * 24));
    const diasRestantes = 30 - diasDecorridos;
    
    // Adicionar informações ao objeto do processo
    processo.temPeticaoInicial = peticaoInicial.length > 0;
    processo.diasRestantesPeticao = diasRestantes;
    processo.diasDecorridos = diasDecorridos;
    
    // Obter documentos recentes do processo
    const [documentos] = await db.query(`
      SELECT d.*, 
        CASE 
          WHEN d.tipo = 'comprovativoPagamento' THEN 'Comprovativo de Pagamento'
          WHEN d.tipo = 'peticaoInicial' THEN 'Petição Inicial'
          WHEN d.tipo = 'contestacao' THEN 'Contestação'
          WHEN d.tipo = 'replica' THEN 'Réplica'
          WHEN d.tipo = 'documentoIdentificacao' THEN 'Documento de Identificação'
          WHEN d.tipo = 'procuracao' THEN 'Procuração'
          WHEN d.tipo = 'contratoArbitragem' THEN 'Contrato de Arbitragem'
          WHEN d.tipo = 'parecerTecnico' THEN 'Parecer Técnico'
          WHEN d.tipo = 'provaDocumental' THEN 'Prova Documental'
          ELSE d.tipo
        END as tipo_formatado
      FROM documentos d
      JOIN processos p ON d.processo_id = p.id
      WHERE p.responsavel_id = ?
      ORDER BY d.data_envio DESC
      LIMIT 20
    `, [req.session.userId]);
    
    res.render('submeter-documentos', {
      username: req.session.username,
      profileType: req.session.profileType,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info',
      processo,
      documentos,
      isAdmin: req.session.profileType === 'admin'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de submeter documentos:', error);
    console.error(error.stack);
    res.render('submeter-documentos', {
      username: req.session.username,
      profileType: req.session.profileType,
      mensagem: 'Erro ao carregar dados: ' + error.message,
      tipoMensagem: 'danger',
      processo: null,
      documentos: [],
      isAdmin: req.session.profileType === 'admin'
    });
  }
});

// Middleware para tratar erros do multer
const uploadMiddleware = (req, res, next) => {
  upload.single('arquivoDocumento')(req, res, function(err) {
    if (err) {
      if (err instanceof multer.MulterError) {
        // Erro do Multer (tamanho do arquivo, etc.)
        if (err.code === 'LIMIT_FILE_SIZE') {
          req.session.mensagem = 'O arquivo excede o tamanho máximo permitido de 10MB.';
        } else {
          req.session.mensagem = 'Erro ao fazer upload do arquivo: ' + err.message;
        }
      } else {
        // Erro personalizado (tipo de arquivo inválido, etc.)
        req.session.mensagem = err.message;
      }
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/submeter');
    }
    next();
  });
};

// Rota para processar o envio de documentos
app.post('/documentos/submeter', isLoggedIn, uploadMiddleware, async (req, res) => {
  try {
    // Verificar se o usuário é um profissional
    const [profissionais] = await db.query('SELECT * FROM profissionais WHERE user_id = ?', [req.session.userId]);
    
    if (profissionais.length > 0) {
      // Se for um profissional, redirecionar para a dashboard de profissional
      req.session.mensagem = 'Como profissional, você deve acessar os documentos através da página de detalhes do processo.';
      req.session.tipoMensagem = 'info';
      return res.redirect('/profissional/dashboard');
    }
    
    const { processoId, tipoDocumento, outroTipo, descricaoDocumento } = req.body;
    const arquivo = req.file;
    
    if (!arquivo) {
      req.session.mensagem = 'Nenhum arquivo foi enviado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/submeter');
    }
    
    // Determinar o tipo final do documento
    const tipoFinal = tipoDocumento === 'outro' ? outroTipo : tipoDocumento;
    
    // Inserir o documento no banco de dados
    await db.query(
      'INSERT INTO documentos (processo_id, tipo, descricao, caminho_arquivo, enviado_por) VALUES (?, ?, ?, ?, ?)',
      [processoId, tipoFinal, descricaoDocumento, arquivo.path, req.session.username]
    );
    
    // Se for uma petição inicial, registrar a data de submissão
    if (tipoFinal === 'peticaoInicial') {
      await db.query(
        'UPDATE processos SET data_peticao_inicial = CURRENT_TIMESTAMP WHERE id = ?',
        [processoId]
      );
      
      req.session.mensagem = 'Petição inicial enviada com sucesso! O processo seguirá para análise.';
    } else {
      req.session.mensagem = 'Documento enviado com sucesso!';
    }
    
    req.session.tipoMensagem = 'success';
    res.redirect('/documentos/submeter');
  } catch (error) {
    console.error('Erro ao enviar documento:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao enviar documento: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/submeter');
  }
});

// Rota para visualizar um documento
app.get('/documentos/visualizar/:id', (req, res) => {
  // Permitir acesso para admin, financeiro e parte
  if (!['admin', 'financeiro', 'parte'].includes(req.session.profileType)) {
    return res.status(403).send('Acesso negado.');
  }
  // ...lógica de visualização...
});

// Rota para excluir um documento
app.get('/documentos/excluir/:id', isLoggedIn, async (req, res) => {
  try {
    const documentoId = req.params.id;
    
    // Obter informações do documento
    const [documentos] = await db.query('SELECT * FROM documentos WHERE id = ?', [documentoId]);
    
    if (documentos.length === 0) {
      req.session.mensagem = 'Documento não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/submeter');
    }
    
    const documento = documentos[0];
    
    // Verificar se o usuário é o proprietário do documento ou admin
    const isAdmin = req.session.profileType === 'admin';
    
    if (!isAdmin && documento.enviado_por !== req.session.username) {
      req.session.mensagem = 'Você não tem permissão para excluir este documento.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/submeter');
    }
    
    // Excluir o arquivo físico
    if (fs.existsSync(documento.caminho_arquivo)) {
      fs.unlinkSync(documento.caminho_arquivo);
    }
    
    // Excluir o registro do banco de dados
    await db.query('DELETE FROM documentos WHERE id = ?', [documentoId]);
    
    req.session.mensagem = 'Documento excluído com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/documentos/submeter');
  } catch (error) {
    console.error('Erro ao excluir documento:', error);
    req.session.mensagem = 'Erro ao excluir documento: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/submeter');
  }
});

// Rota para a página de pedidos de documentos
app.get('/documentos/pedidos', isLoggedIn, async (req, res) => {
  try {
    // Obter o processo associado ao usuário
    const [users] = await db.query('SELECT processo_id FROM users WHERE username = ?', [req.session.username]);
    
    if (users.length === 0 || !users[0].processo_id) {
      return res.render('pedidos-documentos', {
        username: req.session.username,
        profileType: req.session.profileType,
        mensagem: 'Não há processo associado à sua conta.',
        tipoMensagem: 'warning',
        processo: null,
        meusPedidos: [],
        pedidosRecebidos: [],
        pedidosRecebidosPendentes: 0,
        partes: [],
        isAdmin: req.session.profileType === 'admin'
      });
    }
    
    const processoId = users[0].processo_id;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
    
    if (processos.length === 0) {
      return res.render('pedidos-documentos', {
        username: req.session.username,
        profileType: req.session.profileType,
        mensagem: 'Processo não encontrado.',
        tipoMensagem: 'danger',
        processo: null,
        meusPedidos: [],
        pedidosRecebidos: [],
        pedidosRecebidosPendentes: 0,
        partes: [],
        isAdmin: req.session.profileType === 'admin'
      });
    }
    
    const processo = processos[0];
    
    // Obter pedidos feitos pelo usuário
    const [meusPedidos] = await db.query(`
      SELECT p.*, d.id as documento_id
      FROM pedidos_documentos p
      LEFT JOIN documentos d ON p.documento_id = d.id
      WHERE p.processo_id = ? AND p.solicitante = ?
      ORDER BY p.data_pedido DESC
    `, [processoId, req.session.username]);
    
    // Obter pedidos recebidos pelo usuário
    const [pedidosRecebidos] = await db.query(`
      SELECT p.*, d.id as documento_id
      FROM pedidos_documentos p
      LEFT JOIN documentos d ON p.documento_id = d.id
      WHERE p.processo_id = ? AND p.destinatario = ?
      ORDER BY p.data_pedido DESC
    `, [processoId, req.session.username]);
    
    // Contar pedidos pendentes
    const pedidosRecebidosPendentes = pedidosRecebidos.filter(p => p.status === 'pendente').length;
    
    // Obter lista de partes envolvidas no processo para o formulário de novo pedido
    const [partes] = await db.query(`
      SELECT u.username, u.nome_completo, u.profile_type,
        CASE 
          WHEN u.profile_type LIKE '%consultor%' THEN 'Consultor'
          WHEN u.profile_type LIKE '%analista%' THEN 'Analista'
          ELSE u.profile_type
        END as tipo_formatado
      FROM users u
      WHERE u.processo_id = ? AND u.username != ?
    `, [processoId, req.session.username]);
    
    res.render('pedidos-documentos', {
      username: req.session.username,
      profileType: req.session.profileType,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info',
      processo,
      meusPedidos,
      pedidosRecebidos,
      pedidosRecebidosPendentes,
      partes,
      isAdmin: req.session.profileType === 'admin'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de pedidos de documentos:', error);
    res.render('pedidos-documentos', {
      username: req.session.username,
      profileType: req.session.profileType,
      mensagem: 'Erro ao carregar dados: ' + error.message,
      tipoMensagem: 'danger',
      processo: null,
      meusPedidos: [],
      pedidosRecebidos: [],
      pedidosRecebidosPendentes: 0,
      partes: [],
      isAdmin: req.session.profileType === 'admin'
    });
  }
});

// Rota para criar um novo pedido de documento
app.post('/documentos/pedidos/novo', isLoggedIn, async (req, res) => {
  try {
    const { processoId, destinatario, tipoDocumento, outroTipo, descricaoPedido, prazoLimite } = req.body;
    
    // Determinar o tipo final do documento
    const tipoFinal = tipoDocumento === 'Outro' ? outroTipo : tipoDocumento;
    
    // Inserir o pedido no banco de dados
    await db.query(
      'INSERT INTO pedidos_documentos (processo_id, solicitante, destinatario, tipo_documento, descricao, prazo_limite) VALUES (?, ?, ?, ?, ?, ?)',
      [processoId, req.session.username, destinatario, tipoFinal, descricaoPedido, prazoLimite || null]
    );
    
    req.session.mensagem = 'Pedido de documento enviado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/documentos/pedidos');
  } catch (error) {
    console.error('Erro ao criar pedido de documento:', error);
    req.session.mensagem = 'Erro ao criar pedido: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/pedidos');
  }
});

// Rota para atender um pedido de documento
app.post('/documentos/pedidos/atender/:id', isLoggedIn, upload.single('documentoResposta'), async (req, res) => {
  try {
    const pedidoId = req.params.id;
    const { comentarioResposta } = req.body;
    const arquivo = req.file;
    
    if (!arquivo) {
      req.session.mensagem = 'Nenhum arquivo foi enviado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    // Obter informações do pedido
    const [pedidos] = await db.query('SELECT * FROM pedidos_documentos WHERE id = ?', [pedidoId]);
    
    if (pedidos.length === 0) {
      req.session.mensagem = 'Pedido não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    const pedido = pedidos[0];
    
    // Verificar se o usuário é o destinatário do pedido
    if (pedido.destinatario !== req.session.username) {
      req.session.mensagem = 'Você não tem permissão para atender este pedido.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    // Inserir o documento no banco de dados
    const [resultado] = await db.query(
      'INSERT INTO documentos (processo_id, tipo, descricao, caminho_arquivo, enviado_por) VALUES (?, ?, ?, ?, ?)',
      [pedido.processo_id, pedido.tipo_documento, comentarioResposta || `Resposta ao pedido #${pedidoId}`, arquivo.path, req.session.username]
    );
    
    const documentoId = resultado.insertId;
    
    // Atualizar o status do pedido
    await db.query(
      'UPDATE pedidos_documentos SET status = ?, documento_id = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
      ['atendido', documentoId, pedidoId]
    );
    
    req.session.mensagem = 'Pedido atendido com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/documentos/pedidos');
  } catch (error) {
    console.error('Erro ao atender pedido:', error);
    req.session.mensagem = 'Erro ao atender pedido: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/pedidos');
  }
});

// Rota para recusar um pedido de documento
app.post('/documentos/pedidos/recusar/:id', isLoggedIn, async (req, res) => {
  try {
    const pedidoId = req.params.id;
    const { motivoRecusa } = req.body;
    
    // Obter informações do pedido
    const [pedidos] = await db.query('SELECT * FROM pedidos_documentos WHERE id = ?', [pedidoId]);
    
    if (pedidos.length === 0) {
      req.session.mensagem = 'Pedido não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    const pedido = pedidos[0];
    
    // Verificar se o usuário é o destinatário do pedido
    if (pedido.destinatario !== req.session.username) {
      req.session.mensagem = 'Você não tem permissão para recusar este pedido.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    // Atualizar o status do pedido
    await db.query(
      'UPDATE pedidos_documentos SET status = ?, motivo_recusa = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
      ['recusado', motivoRecusa, pedidoId]
    );
    
    req.session.mensagem = 'Pedido recusado com sucesso.';
    req.session.tipoMensagem = 'success';
    res.redirect('/documentos/pedidos');
  } catch (error) {
    console.error('Erro ao recusar pedido:', error);
    req.session.mensagem = 'Erro ao recusar pedido: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/pedidos');
  }
});

// Rota para cancelar um pedido de documento
app.get('/documentos/pedidos/cancelar/:id', isLoggedIn, async (req, res) => {
  try {
    const pedidoId = req.params.id;
    
    // Obter informações do pedido
    const [pedidos] = await db.query('SELECT * FROM pedidos_documentos WHERE id = ?', [pedidoId]);
    
    if (pedidos.length === 0) {
      req.session.mensagem = 'Pedido não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    const pedido = pedidos[0];
    
    // Verificar se o usuário é o solicitante do pedido
    if (pedido.solicitante !== req.session.username) {
      req.session.mensagem = 'Você não tem permissão para cancelar este pedido.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/documentos/pedidos');
    }
    
    // Excluir o pedido
    await db.query('DELETE FROM pedidos_documentos WHERE id = ?', [pedidoId]);
    
    req.session.mensagem = 'Pedido cancelado com sucesso.';
    req.session.tipoMensagem = 'success';
    res.redirect('/documentos/pedidos');
  } catch (error) {
    console.error('Erro ao cancelar pedido:', error);
    req.session.mensagem = 'Erro ao cancelar pedido: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/documentos/pedidos');
  }
});

// Rotas para gerenciar profissionais (árbitros, mediadores, conciliadores)

// Rota para listar profissionais
app.get('/profissionais', isAdmin, async (req, res) => {
  try {
    // Obter todos os profissionais com informações do usuário
    const [profissionais] = await db.query(`
      SELECT p.*, u.nome_completo, u.email, u.username
      FROM profissionais p
      JOIN users u ON p.user_id = u.id
      ORDER BY p.tipo, u.nome_completo
    `);
    
    // Contar quantos processos cada profissional está gerenciando
    for (const profissional of profissionais) {
      const [processos] = await db.query(
        'SELECT COUNT(*) as total FROM processos WHERE responsavel_id = ?',
        [profissional.user_id]
      );
      profissional.processos_ativos = processos[0].total;
    }
    
    // Agrupar profissionais por tipo
    const arbitros = profissionais.filter(p => p.tipo === 'arbitro');
    const mediadores = profissionais.filter(p => p.tipo === 'mediador');
    const conciliadores = profissionais.filter(p => p.tipo === 'conciliador');
    
    res.render('profissionais', {
      username: req.session.username,
      arbitros,
      mediadores,
      conciliadores,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao listar profissionais:', error);
    req.session.mensagem = 'Erro ao carregar profissionais: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
});

// Rota para cadastrar novo profissional
app.get('/profissionais/novo', isAdmin, async (req, res) => {
  try {
    // Obter usuários que não são profissionais
    const [usuarios] = await db.query(`
      SELECT u.* 
      FROM users u
      LEFT JOIN profissionais p ON u.id = p.user_id
      WHERE p.id IS NULL AND u.profile_type != 'admin'
      ORDER BY u.nome_completo
    `);
    
    res.render('profissional-cadastro', {
      username: req.session.username,
      usuarios,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de cadastro de profissional:', error);
    req.session.mensagem = 'Erro ao carregar página: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissionais');
  }
});

// Rota para processar o cadastro de novo profissional
app.post('/profissionais/novo', isAdmin, async (req, res) => {
  try {
    const { userId, tipo, especialidade, biografia } = req.body;
    
    // Verificar se o usuário já é um profissional
    const [profissionalExistente] = await db.query(
      'SELECT * FROM profissionais WHERE user_id = ?',
      [userId]
    );
    
    if (profissionalExistente.length > 0) {
      req.session.mensagem = 'Este usuário já está cadastrado como profissional.';
      req.session.tipoMensagem = 'warning';
      return res.redirect('/profissionais/novo');
    }
    
    // Inserir novo profissional
    await db.query(
      'INSERT INTO profissionais (user_id, tipo, especialidade, biografia) VALUES (?, ?, ?, ?)',
      [userId, tipo, especialidade, biografia]
    );
    
    req.session.mensagem = 'Profissional cadastrado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/profissionais');
  } catch (error) {
    console.error('Erro ao cadastrar profissional:', error);
    req.session.mensagem = 'Erro ao cadastrar profissional: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissionais/novo');
  }
});

// Rota para associar um profissional a um processo
app.get('/processos/:id/associar-profissional', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ?', [processoId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/processos');
    }
    
    const processo = processos[0];
    
    // Obter profissionais do tipo adequado para o processo
    let tipoProfissional = '';
    if (processo.tipo_servico === 'arbitragem') {
      tipoProfissional = 'arbitro';
    } else if (processo.tipo_servico === 'mediacao') {
      tipoProfissional = 'mediador';
    } else if (processo.tipo_servico === 'conciliacao') {
      tipoProfissional = 'conciliador';
    }
    
    const [profissionais] = await db.query(`
      SELECT p.*, u.nome_completo, u.email, u.username
      FROM profissionais p
      JOIN users u ON p.user_id = u.id
      WHERE p.tipo = ? AND p.disponivel = 1
      ORDER BY u.nome_completo
    `, [tipoProfissional]);
    
    // Obter o profissional atual, se houver
    let profissionalAtual = null;
    if (processo.responsavel_id) {
      const [responsavel] = await db.query(`
        SELECT p.*, u.nome_completo, u.email, u.username
        FROM profissionais p
        JOIN users u ON p.user_id = u.id
        WHERE u.id = ?
      `, [processo.responsavel_id]);
      
      if (responsavel.length > 0) {
        profissionalAtual = responsavel[0];
      }
    }
    
    res.render('associar-profissional', {
      username: req.session.username,
      processo,
      profissionais,
      profissionalAtual,
      tipoProfissional,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de associação de profissional:', error);
    req.session.mensagem = 'Erro ao carregar página: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/processos/' + req.params.id);
  }
});

// Rota para processar a associação de profissional
app.post('/processos/:id/associar-profissional', isAdmin, async (req, res) => {
  try {
    const processoId = req.params.id;
    const { profissionalId } = req.body;
    
    // Atualizar o processo com o novo responsável
    await db.query(
      'UPDATE processos SET responsavel_id = ? WHERE id = ?',
      [profissionalId, processoId]
    );
    
    req.session.mensagem = 'Profissional associado ao processo com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/processos/' + processoId);
  } catch (error) {
    console.error('Erro ao associar profissional:', error);
    req.session.mensagem = 'Erro ao associar profissional: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/processos/' + req.params.id + '/associar-profissional');
  }
});

// Rota para alterar a disponibilidade de um profissional
app.post('/profissionais/:id/disponibilidade', isAdmin, async (req, res) => {
  try {
    const profissionalId = req.params.id;
    const disponivel = req.body.disponivel === '1';
    
    // Atualizar a disponibilidade do profissional
    await db.query(
      'UPDATE profissionais SET disponivel = ? WHERE id = ?',
      [disponivel ? 1 : 0, profissionalId]
    );
    
    req.session.mensagem = `Profissional marcado como ${disponivel ? 'disponível' : 'indisponível'} com sucesso!`;
    req.session.tipoMensagem = 'success';
    res.redirect('/profissionais');
  } catch (error) {
    console.error('Erro ao alterar disponibilidade do profissional:', error);
    req.session.mensagem = 'Erro ao alterar disponibilidade: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissionais');
  }
});

// ===== ROTAS PARA SECRETÁRIOS =====

// Dashboard do secretário
app.get('/secretario/dashboard', isSecretario, async (req, res) => {
  try {
    // Obter vereditos pendentes
    const [vereditos] = await db.query(`
      SELECT vp.*, p.tipo_servico, p.natureza_litigio, u.username as profissional_nome
      FROM vereditos_pendentes vp
      JOIN processos p ON vp.processo_id = p.id
      JOIN users u ON vp.profissional_id = u.id
      WHERE vp.status = 'pendente'
      ORDER BY vp.data_submissao DESC
    `);
    
    // Obter processos ativos
    const [processos] = await db.query(`
      SELECT p.*, 
        CASE 
          WHEN p.tipo_servico = 'arbitragem' THEN 'Arbitragem'
          WHEN p.tipo_servico = 'mediacao' THEN 'Mediação'
          ELSE 'Conciliação'
        END as tipo_formatado,
        CASE 
          WHEN p.status = 'pendente' THEN 'Pendente'
          WHEN p.status = 'em_andamento' THEN 'Em Andamento'
          WHEN p.status = 'veredito_pendente' THEN 'Veredito Pendente'
          ELSE 'Encerrado'
        END as status_formatado
      FROM processos p
      WHERE p.status IN ('em_andamento', 'veredito_pendente')
      ORDER BY p.data_atualizacao DESC
      LIMIT 10
    `);
    
    // Obter notificações não lidas
    const [notificacoes] = await db.query(`
      SELECT * FROM notificacoes
      WHERE usuario_id = ? AND lida = 0
      ORDER BY data_criacao DESC
    `, [req.session.userId]);
    
    res.render('secretario-dashboard', {
      username: req.session.username,
      profileType: req.session.profileType,
      vereditos,
      processos,
      notificacoes,
      mensagem: req.session.mensagem,
      tipoMensagem: req.session.tipoMensagem
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar dashboard do secretário:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao carregar dashboard: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
});

// Listar vereditos pendentes
app.get('/secretario/vereditos/pendentes', isSecretario, async (req, res) => {
  try {
    // Obter vereditos pendentes
    const [vereditos] = await db.query(`
      SELECT vp.*, p.tipo_servico, p.natureza_litigio, u.username as profissional_nome
      FROM vereditos_pendentes vp
      JOIN processos p ON vp.processo_id = p.id
      JOIN users u ON vp.profissional_id = u.id
      WHERE vp.status = 'pendente'
      ORDER BY vp.data_submissao DESC
    `);
    
    res.render('secretario-vereditos-pendentes', {
      username: req.session.username,
      profileType: req.session.profileType,
      vereditos,
      mensagem: req.session.mensagem,
      tipoMensagem: req.session.tipoMensagem
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao listar vereditos pendentes:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao listar vereditos pendentes: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/secretario/dashboard');
  }
});

// Visualizar detalhes de um veredito pendente
app.get('/secretario/vereditos/pendentes/:id', isSecretario, async (req, res) => {
  try {
    const veredito_id = req.params.id;
    
    // Obter detalhes do veredito
    const [vereditos] = await db.query(`
      SELECT vp.*, p.tipo_servico, p.natureza_litigio, p.status as processo_status, 
             u.username as profissional_nome, d.caminho_arquivo
      FROM vereditos_pendentes vp
      JOIN processos p ON vp.processo_id = p.id
      JOIN users u ON vp.profissional_id = u.id
      LEFT JOIN documentos d ON vp.documento_id = d.id
      WHERE vp.id = ?
    `, [veredito_id]);
    
    if (vereditos.length === 0) {
      req.session.mensagem = 'Veredito não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/secretario/vereditos/pendentes');
    }
    
    const veredito = vereditos[0];
    
    // Obter partes envolvidas no processo
    const [partes] = await db.query(`
      SELECT u.id, u.username, u.nome_completo, u.email
      FROM users u
      WHERE u.processo_id = ?
    `, [veredito.processo_id]);
    
    res.render('secretario-veredito-detalhes', {
      username: req.session.username,
      profileType: req.session.profileType,
      veredito,
      partes,
      mensagem: req.session.mensagem,
      tipoMensagem: req.session.tipoMensagem
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao visualizar detalhes do veredito:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao visualizar detalhes do veredito: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/secretario/vereditos/pendentes');
  }
});

// Aprovar veredito
app.post('/secretario/vereditos/:id/aprovar', isSecretario, async (req, res) => {
  try {
    const veredito_id = req.params.id;
    const { observacoes } = req.body;
    
    // Obter detalhes do veredito
    const [vereditos] = await db.query('SELECT * FROM vereditos_pendentes WHERE id = ?', [veredito_id]);
    
    if (vereditos.length === 0) {
      req.session.mensagem = 'Veredito não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/secretario/vereditos/pendentes');
    }
    
    const veredito = vereditos[0];
    
    // Iniciar uma transação
    const conn = await db.getConnection();
    await conn.beginTransaction();
    
    try {
      // Atualizar o status do veredito para aprovado
      await conn.query(
        'UPDATE vereditos_pendentes SET status = ?, data_validacao = CURRENT_TIMESTAMP, validado_por = ?, observacoes = CONCAT(observacoes, "\\n\\nObservações do secretário: ", ?) WHERE id = ?',
        ['aprovado', req.session.userId, observacoes || 'Veredito aprovado', veredito_id]
      );
      
      // Atualizar o status do processo para encerrado
      await conn.query(
        'UPDATE processos SET status = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
        ['encerrado', veredito.processo_id]
      );
      
      // Registrar a aprovação do veredito no histórico
      await conn.query(
        'INSERT INTO historico_processo (processo_id, tipo_evento, descricao, usuario, observacoes) VALUES (?, ?, ?, ?, ?)',
        [veredito.processo_id, 'veredito_aprovado', 'Veredito aprovado pelo secretário', req.session.username, observacoes || 'Veredito aprovado']
      );
      
      // Obter partes envolvidas no processo
      const [partes] = await conn.query('SELECT id FROM users WHERE processo_id = ?', [veredito.processo_id]);
      
      // Notificar as partes sobre o veredito
      if (partes.length > 0) {
        const notificacoes = partes.map(parte => {
          return [
            parte.id,
            `Veredito emitido para o processo #${veredito.processo_id}`,
            `O veredito para o seu processo foi aprovado e está disponível para visualização.`,
            `/documentos`,
            'alta'
          ];
        });
        
        // Inserir notificações em lote
        if (notificacoes.length > 0) {
          await conn.query(
            'INSERT INTO notificacoes (usuario_id, titulo, mensagem, link, prioridade) VALUES ?',
            [notificacoes]
          );
        }
      }
      
      // Notificar o profissional sobre a aprovação do veredito
      await conn.query(
        'INSERT INTO notificacoes (usuario_id, titulo, mensagem, link, prioridade) VALUES (?, ?, ?, ?, ?)',
        [
          veredito.profissional_id,
          `Veredito aprovado para o processo #${veredito.processo_id}`,
          `O veredito que você submeteu para o processo #${veredito.processo_id} foi aprovado pelo secretário ${req.session.username}.`,
          `/profissional/processos/${veredito.processo_id}`,
          'alta'
        ]
      );
      
      await conn.commit();
      
      req.session.mensagem = 'Veredito aprovado com sucesso! O processo foi encerrado e as partes foram notificadas.';
      req.session.tipoMensagem = 'success';
      res.redirect('/secretario/vereditos/pendentes');
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error('Erro ao aprovar veredito:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao aprovar veredito: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/secretario/vereditos/pendentes');
  }
});

// Rejeitar veredito
app.post('/secretario/vereditos/:id/rejeitar', isSecretario, async (req, res) => {
  try {
    const veredito_id = req.params.id;
    const { motivo_rejeicao } = req.body;
    
    if (!motivo_rejeicao) {
      req.session.mensagem = 'É necessário fornecer um motivo para a rejeição do veredito.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/secretario/vereditos/pendentes/' + veredito_id);
    }
    
    // Obter detalhes do veredito
    const [vereditos] = await db.query('SELECT * FROM vereditos_pendentes WHERE id = ?', [veredito_id]);
    
    if (vereditos.length === 0) {
      req.session.mensagem = 'Veredito não encontrado.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/secretario/vereditos/pendentes');
    }
    
    const veredito = vereditos[0];
    
    // Iniciar uma transação
    const conn = await db.getConnection();
    await conn.beginTransaction();
    
    try {
      // Atualizar o status do veredito para rejeitado
      await conn.query(
        'UPDATE vereditos_pendentes SET status = ?, data_validacao = CURRENT_TIMESTAMP, validado_por = ?, motivo_rejeicao = ? WHERE id = ?',
        ['rejeitado', req.session.userId, motivo_rejeicao, veredito_id]
      );
      
      // Atualizar o status do processo para em andamento novamente
      await conn.query(
        'UPDATE processos SET status = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
        ['em_andamento', veredito.processo_id]
      );
      
      // Registrar a rejeição do veredito no histórico
      await conn.query(
        'INSERT INTO historico_processo (processo_id, tipo_evento, descricao, usuario, observacoes) VALUES (?, ?, ?, ?, ?)',
        [veredito.processo_id, 'veredito_rejeitado', 'Veredito rejeitado pelo secretário', req.session.username, motivo_rejeicao]
      );
      
      // Notificar o profissional sobre a rejeição do veredito
      await conn.query(
        'INSERT INTO notificacoes (usuario_id, titulo, mensagem, link, prioridade) VALUES (?, ?, ?, ?, ?)',
        [
          veredito.profissional_id,
          `Veredito rejeitado para o processo #${veredito.processo_id}`,
          `O veredito que você submeteu para o processo #${veredito.processo_id} foi rejeitado pelo secretário ${req.session.username}. Motivo: ${motivo_rejeicao}`,
          `/profissional/processos/${veredito.processo_id}`,
          'alta'
        ]
      );
      
      await conn.commit();
      
      req.session.mensagem = 'Veredito rejeitado com sucesso! O processo voltou para o status "Em Andamento".';
      req.session.tipoMensagem = 'success';
      res.redirect('/secretario/vereditos/pendentes');
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error('Erro ao rejeitar veredito:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao rejeitar veredito: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/secretario/vereditos/pendentes');
  }
});

// ===== ROTAS PARA PROFISSIONAIS (ÁRBITROS, MEDIADORES, CONCILIADORES) =====

// Dashboard do profissional
app.get('/profissional/dashboard', isProfissional, async (req, res) => {
  try {
    console.log(`Dashboard: Carregando dashboard para profissional userId=${req.session.userId}`);
    console.log(`Dashboard: Informações do profissional: ${JSON.stringify(req.session.profissional)}`);
    
    // Obter processos associados ao profissional
    const [processos] = await db.query(`
      SELECT p.*, 
        CASE 
          WHEN p.tipo_servico = 'arbitragem' THEN 'Arbitragem'
          WHEN p.tipo_servico = 'mediacao' THEN 'Mediação'
          ELSE 'Conciliação'
        END as tipo_formatado,
        CASE 
          WHEN p.status = 'pendente' THEN 'Pendente'
          WHEN p.status = 'em_andamento' THEN 'Em Andamento'
          ELSE 'Encerrado'
        END as status_formatado
      FROM processos p
      WHERE p.responsavel_id = ?
      ORDER BY 
        CASE 
          WHEN p.status = 'em_andamento' THEN 1
          WHEN p.status = 'pendente' THEN 2
          ELSE 3
        END,
        p.data_atualizacao DESC
    `, [req.session.userId]);
    
    console.log(`Dashboard: Query SQL executada com responsavel_id=${req.session.userId}`);
    
    console.log(`Dashboard: Encontrados ${processos.length} processos para o profissional`);
    
    // Obter estatísticas
    const processosAtivos = processos.filter(p => p.status === 'em_andamento').length;
    const processosPendentes = processos.filter(p => p.status === 'pendente').length;
    const processosEncerrados = processos.filter(p => p.status === 'encerrado').length;
    
    console.log(`Dashboard: Estatísticas - Ativos: ${processosAtivos}, Pendentes: ${processosPendentes}, Encerrados: ${processosEncerrados}`);
    
    // Obter pedidos de documentos pendentes
    const [pedidosPendentes] = await db.query(`
      SELECT pd.*, p.id as processo_id, p.tipo_servico
      FROM pedidos_documentos pd
      JOIN processos p ON pd.processo_id = p.id
      WHERE pd.status = 'pendente' AND p.responsavel_id = ?
      ORDER BY pd.data_pedido DESC
    `, [req.session.userId]);
    
    console.log(`Dashboard: Encontrados ${pedidosPendentes.length} pedidos de documentos pendentes`);
    
    // Obter últimos documentos submetidos nos processos do profissional
    const [ultimosDocumentos] = await db.query(`
      SELECT d.*, p.id as processo_id, p.tipo_servico,
        CASE 
          WHEN d.tipo = 'comprovativoPagamento' THEN 'Comprovativo de Pagamento'
          WHEN d.tipo = 'peticaoInicial' THEN 'Petição Inicial'
          WHEN d.tipo = 'contestacao' THEN 'Contestação'
          WHEN d.tipo = 'replica' THEN 'Réplica'
          WHEN d.tipo = 'documentoIdentificacao' THEN 'Documento de Identificação'
          WHEN d.tipo = 'procuracao' THEN 'Procuração'
          WHEN d.tipo = 'contratoArbitragem' THEN 'Contrato de Arbitragem'
          WHEN d.tipo = 'parecerTecnico' THEN 'Parecer Técnico'
          WHEN d.tipo = 'provaDocumental' THEN 'Prova Documental'
          ELSE d.tipo
        END as tipo_formatado
      FROM documentos d
      JOIN processos p ON d.processo_id = p.id
      WHERE p.responsavel_id = ?
      ORDER BY d.data_envio DESC
      LIMIT 5
    `, [req.session.userId]);
    
    console.log(`Dashboard: Encontrados ${ultimosDocumentos.length} documentos recentes`);
    
    console.log(`Dashboard: Encontrados ${ultimosDocumentos.length} documentos recentes`);
    
    console.log('Dashboard: Renderizando página profissional-dashboard');
    
    res.render('profissional-dashboard', {
      username: req.session.username,
      profissional: req.session.profissional,
      processos,
      processosAtivos,
      processosPendentes,
      processosEncerrados,
      pedidosPendentes,
      ultimosDocumentos,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar dashboard do profissional:', error);
    console.error(error.stack);
    req.session.mensagem = 'Erro ao carregar dashboard: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
});

// Listar processos do profissional
app.get('/profissional/processos', isProfissional, async (req, res) => {
  try {
    // Obter processos associados ao profissional
    const [processos] = await db.query(`
      SELECT p.*, 
        CASE 
          WHEN p.tipo_servico = 'arbitragem' THEN 'Arbitragem'
          WHEN p.tipo_servico = 'mediacao' THEN 'Mediação'
          ELSE 'Conciliação'
        END as tipo_formatado,
        CASE 
          WHEN p.status = 'pendente' THEN 'Pendente'
          WHEN p.status = 'em_andamento' THEN 'Em Andamento'
          ELSE 'Encerrado'
        END as status_formatado
      FROM processos p
      WHERE p.responsavel_id = ?
      ORDER BY 
        CASE 
          WHEN p.status = 'em_andamento' THEN 1
          WHEN p.status = 'pendente' THEN 2
          ELSE 3
        END,
        p.data_atualizacao DESC
    `, [req.session.userId]);
    
    res.render('profissional-processos', {
      username: req.session.username,
      profissional: req.session.profissional,
      processos,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao listar processos do profissional:', error);
    req.session.mensagem = 'Erro ao listar processos: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissional/dashboard');
  }
});

// Detalhes do processo para o profissional
app.get('/profissional/processos/:id', isProfissional, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Obter dados do processo
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ? AND responsavel_id = ?', [processoId, req.session.userId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado ou você não tem permissão para acessá-lo.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/profissional/processos');
    }
    
    const processo = processos[0];
    
    // Parsear os dados do formulário e arquivos
    const dadosFormulario = JSON.parse(processo.dados_formulario);
    const arquivos = processo.arquivos ? JSON.parse(processo.arquivos) : {};
    
    // Obter documentos submetidos pelas partes
    const [documentos] = await db.query(`
      SELECT d.*, 
        CASE 
          WHEN d.tipo = 'comprovativoPagamento' THEN 'Comprovativo de Pagamento'
          WHEN d.tipo = 'peticaoInicial' THEN 'Petição Inicial'
          WHEN d.tipo = 'contestacao' THEN 'Contestação'
          WHEN d.tipo = 'replica' THEN 'Réplica'
          WHEN d.tipo = 'documentoIdentificacao' THEN 'Documento de Identificação'
          WHEN d.tipo = 'procuracao' THEN 'Procuração'
          WHEN d.tipo = 'contratoArbitragem' THEN 'Contrato de Arbitragem'
          WHEN d.tipo = 'parecerTecnico' THEN 'Parecer Técnico'
          WHEN d.tipo = 'provaDocumental' THEN 'Prova Documental'
          ELSE d.tipo
        END as tipo_formatado
      FROM documentos d
      WHERE d.processo_id = ?
      ORDER BY d.data_envio DESC
    `, [processoId]);
    
    // Agrupar documentos por tipo
    const documentosPorTipo = {};
    documentos.forEach(doc => {
      if (!documentosPorTipo[doc.tipo]) {
        documentosPorTipo[doc.tipo] = [];
      }
      documentosPorTipo[doc.tipo].push(doc);
    });
    
    // Obter pedidos de documentos
    const [pedidosDocumentos] = await db.query(`
      SELECT pd.*, u.nome_completo as destinatario_nome
      FROM pedidos_documentos pd
      LEFT JOIN users u ON pd.destinatario = u.username
      WHERE pd.processo_id = ?
      ORDER BY pd.data_pedido DESC
    `, [processoId]);
    
    // Obter usuários associados ao processo para solicitar documentos
    const [usuariosProcesso] = await db.query(`
      SELECT u.id, u.username, u.nome_completo, u.profile_type
      FROM users u
      WHERE u.processo_id = ?
    `, [processoId]);
    
    res.render('profissional-processo-detalhes', {
      username: req.session.username,
      profissional: req.session.profissional,
      processo,
      dadosFormulario,
      arquivos,
      documentos,
      documentosPorTipo,
      pedidosDocumentos,
      usuariosProcesso,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar detalhes do processo:', error);
    req.session.mensagem = 'Erro ao carregar detalhes do processo: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissional/processos');
  }
});

// Rota para o profissional solicitar documentos
app.get('/profissional/processos/:id/solicitar-documento', isProfissional, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Verificar se o processo pertence ao profissional
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ? AND responsavel_id = ?', [processoId, req.session.userId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado ou você não tem permissão para acessá-lo.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/profissional/processos');
    }
    
    const processo = processos[0];
    
    // Obter usuários associados ao processo
    const [usuarios] = await db.query(`
      SELECT u.id, u.username, u.nome_completo, u.profile_type,
        CASE 
          WHEN u.profile_type LIKE '%consultor%' THEN 'Consultor'
          WHEN u.profile_type LIKE '%analista%' THEN 'Analista'
          ELSE u.profile_type
        END as tipo_formatado
      FROM users u
      WHERE u.processo_id = ?
    `, [processoId]);
    
    res.render('profissional-solicitar-documento', {
      username: req.session.username,
      profissional: req.session.profissional,
      processo,
      usuarios,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de solicitação de documentos:', error);
    req.session.mensagem = 'Erro ao carregar página: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissional/processos/' + req.params.id);
  }
});

// Rota para processar a solicitação de documentos pelo profissional
app.post('/profissional/processos/:id/solicitar-documento', isProfissional, async (req, res) => {
  try {
    const processoId = req.params.id;
    const { destinatario, tipoDocumento, outroTipo, descricaoPedido, prazoLimite } = req.body;
    
    // Verificar se o processo pertence ao profissional
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ? AND responsavel_id = ?', [processoId, req.session.userId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado ou você não tem permissão para acessá-lo.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/profissional/processos');
    }
    
    // Determinar o tipo final do documento
    const tipoFinal = tipoDocumento === 'Outro' ? outroTipo : tipoDocumento;
    
    // Inserir o pedido no banco de dados
    await db.query(
      'INSERT INTO pedidos_documentos (processo_id, solicitante, destinatario, tipo_documento, descricao, prazo_limite) VALUES (?, ?, ?, ?, ?, ?)',
      [processoId, req.session.username, destinatario, tipoFinal, descricaoPedido, prazoLimite || null]
    );
    
    req.session.mensagem = 'Pedido de documento enviado com sucesso!';
    req.session.tipoMensagem = 'success';
    res.redirect('/profissional/processos/' + processoId);
  } catch (error) {
    console.error('Erro ao criar pedido de documento:', error);
    req.session.mensagem = 'Erro ao criar pedido: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissional/processos/' + req.params.id + '/solicitar-documento');
  }
});

// Rota para o profissional emitir um veredito/decisão
app.get('/profissional/processos/:id/veredito', isProfissional, async (req, res) => {
  try {
    const processoId = req.params.id;
    
    // Verificar se o processo pertence ao profissional
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ? AND responsavel_id = ?', [processoId, req.session.userId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado ou você não tem permissão para acessá-lo.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/profissional/processos');
    }
    
    const processo = processos[0];
    
    // Verificar se o processo está em andamento
    if (processo.status !== 'em_andamento') {
      req.session.mensagem = 'Apenas processos em andamento podem receber um veredito.';
      req.session.tipoMensagem = 'warning';
      return res.redirect('/profissional/processos/' + processoId);
    }
    
    res.render('profissional-veredito', {
      username: req.session.username,
      profissional: req.session.profissional,
      processo,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar página de veredito:', error);
    req.session.mensagem = 'Erro ao carregar página: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissional/processos/' + req.params.id);
  }
});

// Rota para processar o veredito/decisão
app.post('/profissional/processos/:id/veredito', isProfissional, upload.single('documentoVeredito'), async (req, res) => {
  try {
    const processoId = req.params.id;
    const { tipoVeredito, descricaoVeredito, observacoes } = req.body;
    
    // Verificar se o processo pertence ao profissional
    const [processos] = await db.query('SELECT * FROM processos WHERE id = ? AND responsavel_id = ?', [processoId, req.session.userId]);
    
    if (processos.length === 0) {
      req.session.mensagem = 'Processo não encontrado ou você não tem permissão para acessá-lo.';
      req.session.tipoMensagem = 'danger';
      return res.redirect('/profissional/processos');
    }
    
    const processo = processos[0];
    
    // Verificar se o processo está em andamento
    if (processo.status !== 'em_andamento') {
      req.session.mensagem = 'Apenas processos em andamento podem receber um veredito.';
      req.session.tipoMensagem = 'warning';
      return res.redirect('/profissional/processos/' + processoId);
    }
    
    // Iniciar uma transação
    const conn = await db.getConnection();
    await conn.beginTransaction();
    
    try {
      let documentoId = null;
      
      // Salvar o documento do veredito, se fornecido
      if (req.file) {
        const tipoDocumento = processo.tipo_servico === 'arbitragem' ? 'sentencaArbitral' : 
                             processo.tipo_servico === 'mediacao' ? 'acordoMediacao' : 'acordoConciliacao';
        
        const [resultDoc] = await conn.query(
          'INSERT INTO documentos (processo_id, tipo, descricao, caminho_arquivo, enviado_por) VALUES (?, ?, ?, ?, ?)',
          [processoId, tipoDocumento, descricaoVeredito, req.file.path, req.session.username]
        );
        
        documentoId = resultDoc.insertId;
      }
      
      // Registrar o veredito como pendente de validação
      await conn.query(
        'INSERT INTO vereditos_pendentes (processo_id, profissional_id, tipo_veredito, descricao, observacoes, documento_id) VALUES (?, ?, ?, ?, ?, ?)',
        [processoId, req.session.userId, tipoVeredito, descricaoVeredito, observacoes, documentoId]
      );
      
      // Atualizar o status do processo para indicar que há um veredito pendente
      await conn.query(
        'UPDATE processos SET status = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE id = ?',
        ['veredito_pendente', processoId]
      );
      
      // Registrar a submissão do veredito no histórico
      await conn.query(
        'INSERT INTO historico_processo (processo_id, tipo_evento, descricao, usuario, observacoes) VALUES (?, ?, ?, ?, ?)',
        [processoId, 'veredito_submetido', tipoVeredito, req.session.username, 'Veredito submetido para validação']
      );
      
      // Notificar os secretários sobre o veredito pendente
      // Buscar secretários (secretario_geral e secretario_processo)
      const [secretarios] = await conn.query(
        'SELECT id, username, email FROM users WHERE profile_type IN (?, ?)',
        ['secretario_geral', 'secretario_processo']
      );
      
      // Registrar notificações para os secretários
      if (secretarios.length > 0) {
        const notificacoes = secretarios.map(secretario => {
          return [
            secretario.id,
            `Novo veredito pendente de validação para o processo #${processoId}`,
            `O profissional ${req.session.username} submeteu um veredito para o processo #${processoId} que requer sua validação.`,
            `/secretario/vereditos/pendentes/${processoId}`,
            'alta'
          ];
        });
        
        // Inserir notificações em lote
        await conn.query(
          'INSERT INTO notificacoes (usuario_id, titulo, mensagem, link, prioridade) VALUES ?',
          [notificacoes]
        );
      }
      
      await conn.commit();
      
      req.session.mensagem = 'Veredito submetido com sucesso! Aguardando validação pelos secretários.';
      req.session.tipoMensagem = 'success';
      res.redirect('/profissional/processos/' + processoId);
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error('Erro ao registrar veredito:', error);
    req.session.mensagem = 'Erro ao registrar veredito: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/profissional/processos/' + req.params.id + '/veredito');
  }
});

// ===== ROTAS DO SISTEMA DE LOGS (APENAS ADMIN) =====

// Rota principal dos logs do sistema
app.get('/admin/logs', isAdmin, async (req, res) => {
  try {
    const pagina = parseInt(req.query.pagina) || 1;
    const limite = parseInt(req.query.limite) || 50;
    
    // Obter filtros da query string
    const filtros = {
      tipo: req.query.tipo || '',
      usuario: req.query.usuario || '',
      acao: req.query.acao || '',
      ip: req.query.ip || '',
      dataInicio: req.query.dataInicio || '',
      dataFim: req.query.dataFim || ''
    };
    
    // Obter logs com paginação
    const { logs, total, totalPaginas } = getLogsAdvanced(filtros, pagina, limite);
    
    // Obter estatísticas
    const stats = getLogStats();
    
    // Registrar acesso aos logs
    logActivity('VIEW', req.session.username, 'Visualização de logs do sistema', 
               `Página ${pagina}, ${logs.length} logs exibidos`, req.ip, req.headers['user-agent']);
    
    res.render('admin-logs', {
      title: 'Sistema de Logs - Admin',
      username: req.session.username,
      logs,
      filtros,
      pagina,
      totalPaginas,
      total,
      limite,
      stats,
      mensagem: req.session.mensagem || null,
      tipoMensagem: req.session.tipoMensagem || 'info'
    });
    
    delete req.session.mensagem;
    delete req.session.tipoMensagem;
  } catch (error) {
    console.error('Erro ao carregar logs:', error);
    req.session.mensagem = 'Erro ao carregar logs: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/dashboard');
  }
});

// Rota para exportar logs como CSV
app.get('/admin/logs/export', isAdmin, async (req, res) => {
  try {
    const filtros = {
      tipo: req.query.tipo || '',
      usuario: req.query.usuario || '',
      acao: req.query.acao || '',
      ip: req.query.ip || '',
      dataInicio: req.query.dataInicio || '',
      dataFim: req.query.dataFim || ''
    };
    
    const csv = exportLogsCSV(filtros);
    
    // Registrar exportação
    logActivity('EXPORT', req.session.username, 'Exportação de logs', 
               'Logs exportados em formato CSV', req.ip, req.headers['user-agent']);
    
    // Definir headers para download
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `logs-sistema-${timestamp}.csv`;
    
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', Buffer.byteLength(csv, 'utf8'));
    
    res.send(csv);
  } catch (error) {
    console.error('Erro ao exportar logs:', error);
    req.session.mensagem = 'Erro ao exportar logs: ' + error.message;
    req.session.tipoMensagem = 'danger';
    res.redirect('/admin/logs');
  }
});

// Rota para limpar logs antigos
app.post('/admin/logs/cleanup', isAdmin, async (req, res) => {
  try {
    const { cleanOldLogs } = require('./logs');
    
    // Executar limpeza
    cleanOldLogs();
    
    // Registrar ação
    logActivity('MAINTENANCE', req.session.username, 'Limpeza de logs antigos', 
               'Logs com mais de 30 dias foram removidos', req.ip, req.headers['user-agent']);
    
    req.session.mensagem = 'Limpeza de logs realizada com sucesso!';
    req.session.tipoMensagem = 'success';
  } catch (error) {
    console.error('Erro ao limpar logs:', error);
    req.session.mensagem = 'Erro ao limpar logs: ' + error.message;
    req.session.tipoMensagem = 'danger';
  }
  
  res.redirect('/admin/logs');
});

// Rota API para obter estatísticas de logs (AJAX)
app.get('/api/admin/logs/stats', isAdmin, async (req, res) => {
  try {
    const stats = getLogStats();
    res.json(stats);
  } catch (error) {
    console.error('Erro ao obter estatísticas de logs:', error);
    res.status(500).json({ error: 'Erro ao obter estatísticas' });
  }
});

// Middleware para registrar todos os acessos e ações importantes
function logAllActivities(req, res, next) {
  // Apenas registrar ações importantes, não todas as requisições
  const importantPaths = [
    '/auth', '/logout', '/users', '/processos', '/documentos', 
    '/profissionais', '/admin', '/pagamentos'
  ];
  
  const shouldLog = importantPaths.some(path => req.originalUrl.includes(path));
  
  if (shouldLog && req.session.username) {
    const action = `${req.method} ${req.originalUrl}`;
    logActivity('ACCESS', req.session.username, action, null, req.ip, req.headers['user-agent']);
  }
  
  next();
}

// Aplicar o middleware de logging (opcional - descomente se quiser log de todos os acessos)
// app.use(logAllActivities);

// Iniciar o servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📊 Sistema de logs ativo e funcionando`);
  console.log(`Acesse o site através de:`);
  console.log(`- Local: http://localhost:${PORT}`);
  
  // Obter endereço IP da máquina na rede local
  const { networkInterfaces } = require('os');
  const nets = networkInterfaces();
  
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      // Pular endereços não IPv4 e internos
      if (net.family === 'IPv4' && !net.internal) {
        console.log(`- Rede: http://${net.address}:${PORT}`);
      }
    }
  }
  
  // Registrar inicialização do servidor
  logActivity('SYSTEM', 'SYSTEM', 'Servidor iniciado', `Porta: ${PORT}`);
});
