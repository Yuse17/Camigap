const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

console.log('=== CRIAÇÃO DE TABELAS E PERFIS ===');

try {
    const db = new Database('./users.db');
    
    // Verificar tabelas existentes
    const tabelasExistentes = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('Tabelas existentes:', tabelasExistentes.map(t => t.name));
    
    // Criar tabelas específicas de perfis se necessário
    const tabelasPerfis = {
        financeiros: `
            CREATE TABLE IF NOT EXISTS financeiros (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                departamento TEXT,
                nivel_acesso TEXT DEFAULT 'basico',
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `,
        secretarios: `
            CREATE TABLE IF NOT EXISTS secretarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                tipo TEXT CHECK(tipo IN ('geral', 'processo')),
                processos_atribuidos TEXT, -- JSON com lista de IDs
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `,
        auditores: `
            CREATE TABLE IF NOT EXISTS auditores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                especialidade TEXT,
                certificacoes TEXT,
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `,
        coordenadores: `
            CREATE TABLE IF NOT EXISTS coordenadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                area_responsabilidade TEXT,
                equipe_size INTEGER DEFAULT 0,
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `,
        assistentes: `
            CREATE TABLE IF NOT EXISTS assistentes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                coordenador_id INTEGER,
                funcoes TEXT,
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (coordenador_id) REFERENCES coordenadores(id)
            )
        `,
        supervisores: `
            CREATE TABLE IF NOT EXISTS supervisores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                areas_supervisionadas TEXT,
                nivel_autoridade TEXT DEFAULT 'medio',
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `
    };
    
    // Criar cada tabela
    for (const [nomeTabela, sql] of Object.entries(tabelasPerfis)) {
        console.log(`\nCriando/verificando tabela ${nomeTabela}...`);
        
        try {
            db.exec(sql);
            console.log(`✅ Tabela ${nomeTabela} criada/verificada com sucesso`);
        } catch (error) {
            console.error(`❌ Erro ao criar tabela ${nomeTabela}:`, error.message);
        }
    }
    
    // Verificar se existe usuário financeiro, se não, criar um
    console.log('\n=== CRIANDO USUÁRIOS DE TESTE ===');
    
    const usuarios = {
        financeiro: {
            username: 'financeiro',
            password: 'financeiro123',
            profile_type: 'financeiro',
            email: 'financeiro@camigap.com',
            nome_completo: 'João Financeiro'
        },
        secretario: {
            username: 'secretario',
            password: 'secretario123', 
            profile_type: 'secretario',
            email: 'secretario@camigap.com',
            nome_completo: 'Maria Secretária'
        },
        auditor: {
            username: 'auditor',
            password: 'auditor123',
            profile_type: 'auditor', 
            email: 'auditor@camigap.com',
            nome_completo: 'Carlos Auditor'
        }
    };
    
    for (const [tipo, dados] of Object.entries(usuarios)) {
        const userExists = db.prepare('SELECT COUNT(*) as count FROM users WHERE username = ?').get(dados.username);
        
        if (userExists.count === 0) {
            console.log(`Criando usuário ${tipo}...`);
            
            const hashedPassword = bcrypt.hashSync(dados.password, 10);
            
            const result = db.prepare(`
                INSERT INTO users (username, password, profile_type, email, nome_completo) 
                VALUES (?, ?, ?, ?, ?)
            `).run(
                dados.username,
                hashedPassword,
                dados.profile_type,
                dados.email,
                dados.nome_completo
            );
            
            const userId = result.lastInsertRowid;
            
            // Inserir na tabela específica do perfil
            if (tipo === 'financeiro') {
                db.prepare(`
                    INSERT INTO financeiros (user_id, departamento, nivel_acesso) 
                    VALUES (?, ?, ?)
                `).run(userId, 'Financeiro', 'avancado');
            } else if (tipo === 'secretario') {
                db.prepare(`
                    INSERT INTO secretarios (user_id, tipo) 
                    VALUES (?, ?)
                `).run(userId, 'geral');
            } else if (tipo === 'auditor') {
                db.prepare(`
                    INSERT INTO auditores (user_id, especialidade) 
                    VALUES (?, ?)
                `).run(userId, 'Auditoria Financeira');
            }
            
            console.log(`✅ Usuário ${tipo} criado com ID ${userId}`);
            console.log(`   Username: ${dados.username}`);
            console.log(`   Senha: ${dados.password}`);
            console.log(`   Email: ${dados.email}`);
        } else {
            console.log(`✅ Usuário ${tipo} já existe`);
        }
    }
    
    // Verificar usuários finais
    console.log('\n=== USUÁRIOS FINAIS ===');
    const todosUsuarios = db.prepare('SELECT id, username, email, profile_type FROM users').all();
    todosUsuarios.forEach(user => {
        console.log(`- ID: ${user.id}, Username: ${user.username}, Email: ${user.email}, Perfil: ${user.profile_type}`);
    });
    
    // Verificar tabelas finais
    const tabelasFinais = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('\n=== TABELAS FINAIS ===');
    console.log('Tabelas disponíveis:', tabelasFinais.map(t => t.name));
    
    db.close();
    console.log('\n✅ Configuração de perfis concluída!');
    
} catch (error) {
    console.error('❌ Erro geral:', error.message);
    console.error(error.stack);
}