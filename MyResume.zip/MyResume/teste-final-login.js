const http = require('http');
const querystring = require('querystring');

async function testarLogin(path, email, password, descricao) {
    return new Promise((resolve, reject) => {
        console.log(`\n=== ${descricao} ===`);
        console.log(`Rota: ${path}`);
        console.log(`Username: ${email}`);
        console.log(`Senha: ${password}`);
        
        const postData = querystring.stringify({
            email: email,
            password: password
        });

        const options = {
            hostname: 'localhost',
            port: 3000,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                if (res.statusCode === 302 && res.headers.location === '/dashboard') {
                    console.log('✅ SUCESSO! Login redirecionado para dashboard');
                } else if (res.statusCode === 302) {
                    console.log(`❌ FALHA! Redirecionado para: ${res.headers.location}`);
                } else {
                    console.log(`❌ FALHA! Status: ${res.statusCode}`);
                }
                resolve(res);
            });
        });

        req.on('error', (e) => {
            console.error(`❌ ERRO: ${e.message}`);
            reject(e);
        });

        req.write(postData);
        req.end();
    });
}

async function executarTodosTestes() {
    console.log('🧪 TESTE COMPLETO DO SISTEMA DE LOGIN');
    console.log('=====================================');
    
    try {
        // Teste 1: Login com username "admin" na rota principal
        await testarLogin('/auth', 'admin', 'admin123', 'TESTE 1: Login principal com username');
        
        // Teste 2: Login com email na rota principal
        await testarLogin('/auth', 'admin@camigap.com', 'admin123', 'TESTE 2: Login principal com email');
        
        // Teste 3: Login na rota de teste
        await testarLogin('/teste-auth', 'admin', 'admin123', 'TESTE 3: Login de teste');
        
        // Teste 4: Senha incorreta
        await testarLogin('/auth', 'admin', 'senha_errada', 'TESTE 4: Senha incorreta (deve falhar)');
        
        console.log('\n🎉 TESTES CONCLUÍDOS!');
        console.log('\n📋 RESUMO PARA O USUÁRIO:');
        console.log('✅ Username para admin: "admin"');
        console.log('✅ Senha para admin: "admin123"');
        console.log('✅ Pode usar tanto username quanto email');
        console.log('✅ Acesse: http://localhost:3000/login');
        
    } catch (error) {
        console.error('Erro durante os testes:', error);
    }
}

executarTodosTestes();