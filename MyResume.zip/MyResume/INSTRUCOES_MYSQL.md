# Instruções para Configuração do MySQL

## 1. Instalar o MySQL

### Para Windows:
1. Baixe o MySQL Installer do site oficial: https://dev.mysql.com/downloads/installer/
2. Execute o instalador e escolha a opção "Developer Default" ou "Server only"
3. Siga as instruções do instalador
4. Defina uma senha para o usuário root (anote esta senha)
5. Complete a instalação

## 2. Configurar o Banco de Dados

### Opção 1: Usando o MySQL Workbench
1. Abra o MySQL Workbench
2. Conecte-se ao servidor local usando o usuário root
3. Crie um novo schema (banco de dados) chamado "camigap"
4. Execute o script SQL contido no arquivo `setup_database.sql`

### Opção 2: Usando a Linha de Comando
1. Abra o Prompt de Comando ou PowerShell
2. Navegue até o diretório do MySQL (geralmente em `C:\Program Files\MySQL\MySQL Server 8.0\bin`)
3. Execute o comando:
   ```
   mysql -u root -p < C:\Users\hugof\Desktop\MyResume\setup_database.sql
   ```
4. Digite a senha do root quando solicitado

## 3. Configurar o Arquivo database.js

Se você definiu uma senha para o usuário root do MySQL, você precisa atualizar o arquivo `database.js`:

1. Abra o arquivo `database.js`
2. Localize a seção de configuração do banco de dados
3. Altere o valor da propriedade `password` para a senha que você definiu:
   ```javascript
   const dbConfig = {
     host: 'localhost',
     user: 'root',
     password: 'SUA_SENHA_AQUI', // Substitua pela sua senha
     database: 'camigap',
     waitForConnections: true,
     connectionLimit: 10,
     queueLimit: 0
   };
   ```
4. Salve o arquivo

## 4. Iniciar o Aplicativo

Depois de configurar o MySQL e o banco de dados, você pode iniciar o aplicativo:

```
npm start
```

O servidor será iniciado na porta 3000. Acesse http://localhost:3000/login no seu navegador.

## Credenciais Padrão
- Usuário: admin
- Senha: admin123