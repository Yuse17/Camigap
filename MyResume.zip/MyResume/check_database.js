const Database = require('better-sqlite3');
const path = require('path');

async function checkAndUpdateDatabase() {
  console.log('=== VERIFICANDO ESTRUTURA DO BANCO ===');
  
  const dbPath = path.join(__dirname, 'users.db');
  const db = new Database(dbPath);
  
  try {
    // Verificar estrutura da tabela processos
    const columns = db.prepare("PRAGMA table_info(processos)").all();
    console.log('\n📋 COLUNAS DA TABELA PROCESSOS:');
    columns.forEach(col => {
      console.log(`- ${col.name} (${col.type}) ${col.pk ? '[PK]' : ''} ${col.notnull ? '[NOT NULL]' : ''}`);
    });
    
    // Verificar se a coluna pagamento_verificado existe
    const hasPaymentColumn = columns.some(col => col.name === 'pagamento_verificado');
    
    if (!hasPaymentColumn) {
      console.log('\n⚠️  Coluna pagamento_verificado não encontrada! Adicionando...');
      
      // Adicionar a coluna
      db.exec('ALTER TABLE processos ADD COLUMN pagamento_verificado INTEGER DEFAULT 0');
      console.log('✅ Coluna pagamento_verificado adicionada com sucesso!');
    } else {
      console.log('\n✅ Coluna pagamento_verificado já existe!');
    }
    
    // Mostrar alguns processos existentes
    const processos = db.prepare('SELECT id, tipo_servico, pagamento_verificado FROM processos LIMIT 5').all();
    console.log('\n📊 PROCESSOS EXISTENTES:');
    processos.forEach(p => {
      console.log(`- ID: ${p.id}, Tipo: ${p.tipo_servico}, Pagamento: ${p.pagamento_verificado ? 'Verificado' : 'Pendente'}`);
    });
    
  } catch (error) {
    console.error('❌ Erro ao verificar banco:', error);
  } finally {
    db.close();
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  checkAndUpdateDatabase();
}

module.exports = { checkAndUpdateDatabase };
