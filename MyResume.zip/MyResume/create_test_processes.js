const { createDatabase } = require('./database');

async function createTestProcesses() {
  console.log('=== CRIANDO PROCESSOS DE TESTE ===');
  
  const db = createDatabase();
  
  try {
    // Verificar quantos processos já existem
    const [existingProcesses] = await db.query('SELECT COUNT(*) as count FROM processos');
    console.log(`Processos existentes: ${existingProcesses[0].count}`);
    
    // Criar alguns processos de teste se não existirem
    if (existingProcesses[0].count < 3) {
      
      // Processo 1 - Arbitragem com pagamento pendente
      const dadosFormulario1 = JSON.stringify({
        demandantes: [{nome: 'Empresa ABC Lda', email: 'abc@empresa.com'}],
        demandados: [{nome: 'Empresa XYZ Lda', email: 'xyz@empresa.com'}],
        valorPretensao: '50000'
      });
      
      const arquivos1 = JSON.stringify({
        comprovativoPagamento: [{
          filename: 'comprovativo-001.pdf',
          originalname: 'Comprovativo_Pagamento_ABC.pdf',
          path: '/uploads/arbitragem/comprovativo-001.pdf'
        }]
      });
      
      await db.query(`
        INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos, pagamento_verificado) 
        VALUES (?, ?, ?, ?, ?, ?)
      `, ['arbitragem', 'Contrato de Prestação de Serviços', 50000.00, dadosFormulario1, arquivos1, 0]);
      
      // Processo 2 - Mediação com pagamento verificado
      const dadosFormulario2 = JSON.stringify({
        demandantes: [{nome: 'João Silva', email: 'joao@email.com'}],
        demandados: [{nome: 'Maria Santos', email: 'maria@email.com'}],
        valorPretensao: '25000'
      });
      
      const arquivos2 = JSON.stringify({
        comprovativoPagamento: [{
          filename: 'comprovativo-002.pdf',
          originalname: 'Comprovativo_Pagamento_Joao.pdf',
          path: '/uploads/mediacao/comprovativo-002.pdf'
        }]
      });
      
      await db.query(`
        INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos, pagamento_verificado) 
        VALUES (?, ?, ?, ?, ?, ?)
      `, ['mediacao', 'Conflito Vizinhança', 25000.00, dadosFormulario2, arquivos2, 1]);
      
      // Processo 3 - Conciliação com pagamento pendente
      const dadosFormulario3 = JSON.stringify({
        demandantes: [{nome: 'Construtora LMN SA', email: 'lmn@construtora.com'}],
        demandados: [{nome: 'Câmara Municipal', email: 'cm@municipio.pt'}],
        valorPretensao: '100000'
      });
      
      const arquivos3 = JSON.stringify({
        comprovativoPagamento: [{
          filename: 'comprovativo-003.pdf',
          originalname: 'Comprovativo_Pagamento_LMN.pdf',
          path: '/uploads/conciliacao/comprovativo-003.pdf'
        }]
      });
      
      await db.query(`
        INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos, pagamento_verificado) 
        VALUES (?, ?, ?, ?, ?, ?)
      `, ['conciliacao', 'Licenciamento Urbanístico', 100000.00, dadosFormulario3, arquivos3, 0]);
      
      console.log('✅ Processos de teste criados com sucesso!');
      console.log('- 1 processo de arbitragem (pagamento pendente)');
      console.log('- 1 processo de mediação (pagamento verificado)');
      console.log('- 1 processo de conciliação (pagamento pendente)');
    } else {
      console.log('✅ Processos de teste já existem!');
    }
    
    // Mostrar estatísticas
    const [stats] = await db.query(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN pagamento_verificado = 0 THEN 1 ELSE 0 END) as pendentes,
        SUM(CASE WHEN pagamento_verificado = 1 THEN 1 ELSE 0 END) as verificados
      FROM processos
    `);
    
    console.log('\n📊 ESTATÍSTICAS:');
    console.log(`Total de processos: ${stats[0].total}`);
    console.log(`Pagamentos pendentes: ${stats[0].pendentes}`);
    console.log(`Pagamentos verificados: ${stats[0].verificados}`);
    
  } catch (error) {
    console.error('❌ Erro ao criar processos de teste:', error);
  } finally {
    db.close();
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  createTestProcesses();
}

module.exports = { createTestProcesses };
