const nodemailer = require('nodemailer');

// Função para enviar email com credenciais de nova conta
async function sendAccountCredentials(email, username, password) {
  // Configure o transporter
  const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', // Substitua pelo seu servidor SMTP
    port: 587,
    secure: false, // true para 465, false para outras portas
    auth: {
      user: 'seu-email@gmail.com', // Substitua pelo seu e-mail
      pass: 'sua-senha-ou-app-password' // Substitua pela sua senha ou senha de aplicativo
    }
  });

  await transporter.sendMail({
    from: '"CAMIGAP" <no-reply@camigap.com>',
    to: email,
    subject: 'Sua conta foi criada',
    text: `Olá ${username}, sua conta foi criada. Sua senha é: ${password}`,
  });
}

module.exports = { sendAccountCredentials };