const http = require('http');
const querystring = require('querystring');

function testarLoginHTTP(email, password) {
    return new Promise((resolve, reject) => {
        const postData = querystring.stringify({
            email: email,
            password: password
        });

        const options = {
            hostname: 'localhost',
            port: 3000,
            path: '/auth',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData),
                'Cookie': 'connect.sid=test' // Simular sessão
            }
        };

        const req = http.request(options, (res) => {
            console.log(`Status: ${res.statusCode}`);
            console.log(`Headers: ${JSON.stringify(res.headers)}`);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                console.log('Resposta:', data);
                resolve({
                    status: res.statusCode,
                    headers: res.headers,
                    body: data
                });
            });
        });

        req.on('error', (e) => {
            console.error(`Erro na requisição: ${e.message}`);
            reject(e);
        });

        req.write(postData);
        req.end();
    });
}

async function executarTeste() {
    console.log('=== TESTE DE LOGIN HTTP ===');
    console.log('Testando login como admin...');
    console.log();

    try {
        await testarLoginHTTP('admin', 'admin123');
    } catch (error) {
        console.error('Erro:', error.message);
    }
}

executarTeste();