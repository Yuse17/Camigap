const http = require('http');
const querystring = require('querystring');

async function testarFluxoCompleto() {
    console.log('=== TESTE COMPLETO DO FINANCEIRO ===');
    
    console.log('🔐 ETAPA 1: Fazendo login...');
    
    const loginData = querystring.stringify({
        email: 'financeiro',
        password: 'financeiro123'
    });
    
    const loginOptions = {
        hostname: 'localhost',
        port: 3000,
        path: '/auth',
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(loginData)
        }
    };
    
    try {
        // Fazer login
        const loginResult = await new Promise((resolve, reject) => {
            const req = http.request(loginOptions, (res) => {
                let data = '';
                res.on('data', (chunk) => data += chunk);
                res.on('end', () => {
                    resolve({
                        status: res.statusCode,
                        location: res.headers.location,
                        cookies: res.headers['set-cookie'],
                        data: data
                    });
                });
            });
            
            req.on('error', reject);
            req.write(loginData);
            req.end();
        });
        
        console.log(`✅ Login: Status ${loginResult.status}, Location: ${loginResult.location}`);
        
        if (loginResult.status !== 302 || loginResult.location !== '/dashboard') {
            console.log('❌ Login falhou ou redirecionamento incorreto');
            return;
        }
        
        // Extrair cookie de sessão
        const sessionCookie = loginResult.cookies ? loginResult.cookies[0] : null;
        if (!sessionCookie) {
            console.log('❌ Nenhum cookie de sessão recebido');
            return;
        }
        
        console.log('🍪 Cookie de sessão obtido');
        
        console.log('\n📊 ETAPA 2: Acessando dashboard...');
        
        // Acessar dashboard
        const dashboardOptions = {
            hostname: 'localhost',
            port: 3000,
            path: '/dashboard',
            method: 'GET',
            headers: {
                'Cookie': sessionCookie
            }
        };
        
        const dashboardResult = await new Promise((resolve, reject) => {
            const req = http.request(dashboardOptions, (res) => {
                let data = '';
                res.on('data', (chunk) => data += chunk);
                res.on('end', () => {
                    resolve({
                        status: res.statusCode,
                        location: res.headers.location,
                        data: data
                    });
                });
            });
            
            req.on('error', reject);
            req.end();
        });
        
        console.log(`📊 Dashboard: Status ${dashboardResult.status}`);
        
        if (dashboardResult.status === 302) {
            console.log(`🔄 Redirecionamento para: ${dashboardResult.location}`);
            
            if (dashboardResult.location === '/pagamentos') {
                console.log('✅ SUCESSO! Financeiro foi redirecionado para pagamentos como esperado!');
                
                // Testar acesso à página de pagamentos
                console.log('\n💰 ETAPA 3: Acessando página de pagamentos...');
                
                const pagamentosOptions = {
                    hostname: 'localhost',
                    port: 3000,
                    path: '/pagamentos',
                    method: 'GET',
                    headers: {
                        'Cookie': sessionCookie
                    }
                };
                
                const pagamentosResult = await new Promise((resolve, reject) => {
                    const req = http.request(pagamentosOptions, (res) => {
                        let data = '';
                        res.on('data', (chunk) => data += chunk);
                        res.on('end', () => {
                            resolve({
                                status: res.statusCode,
                                data: data.length
                            });
                        });
                    });
                    
                    req.on('error', reject);
                    req.end();
                });
                
                if (pagamentosResult.status === 200) {
                    console.log('✅ Página de pagamentos carregada com sucesso!');
                    console.log(`📄 Tamanho da resposta: ${pagamentosResult.data} bytes`);
                } else {
                    console.log(`❌ Erro ao carregar pagamentos: Status ${pagamentosResult.status}`);
                }
                
            } else {
                console.log(`⚠️ Redirecionamento inesperado para: ${dashboardResult.location}`);
            }
        } else if (dashboardResult.status === 200) {
            console.log('⚠️ Dashboard carregou diretamente sem redirecionamento');
            
            // Verificar se contém informações de financeiro
            if (dashboardResult.data.includes('pagamentos') || dashboardResult.data.includes('financeiro')) {
                console.log('✅ Dashboard parece conter conteúdo relacionado a financeiro');
            } else {
                console.log('❌ Dashboard não parece estar configurado para financeiro');
            }
        } else {
            console.log(`❌ Erro no dashboard: Status ${dashboardResult.status}`);
        }
        
    } catch (error) {
        console.error('❌ Erro durante o teste:', error.message);
    }
}

testarFluxoCompleto();