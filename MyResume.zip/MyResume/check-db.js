const Database = require('better-sqlite3');
const db = new Database('database.sqlite');

// Verificar tabelas
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
console.log('Tabelas no banco de dados:');
console.log(tables);

// Verificar processos
try {
  const processos = db.prepare('SELECT * FROM processos').all();
  console.log('\nProcessos:');
  console.log(processos);
} catch (err) {
  console.error('Erro ao consultar processos:', err);
}

// Verificar usuários
try {
  const users = db.prepare('SELECT id, username, profile_type FROM users').all();
  console.log('\nUsuários:');
  console.log(users);
} catch (err) {
  console.error('Erro ao consultar usuários:', err);
}