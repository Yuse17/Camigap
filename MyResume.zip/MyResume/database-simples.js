const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

// Configurar o caminho da base de dados
const dbPath = path.join(__dirname, 'users.db');
let db;

// Função para hash da senha
function hashPasswordSync(password) {
  return bcrypt.hashSync(password, 10);
}

// Função para comparar senhas
async function comparePassword(inputPassword, hashedPassword) {
  return bcrypt.compare(inputPassword, hashedPassword);
}

// Função para inicializar a base de dados (versão simples)
function initializeDatabase() {
  try {
    console.log('Inicializando banco de dados SQLite...');
    
    // Criar conexão com a base de dados
    db = new Database(dbPath);
    
    // Verificar se a tabela users existe, se não, criar apenas ela
    const tableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();
    
    if (!tableExists) {
      console.log('Criando tabela users...');
      db.exec(`
        CREATE TABLE users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          profile_type TEXT NOT NULL CHECK(profile_type IN ('admin', 'secretario', 'profissional', 'parte')),
          email TEXT UNIQUE,
          nome_completo TEXT,
          processo_id INTEGER,
          two_factor_code TEXT,
          two_factor_expires TIMESTAMP
        )
      `);
    }
    
    // Verificar se o admin existe
    const adminExists = db.prepare('SELECT COUNT(*) as count FROM users WHERE username = ?').get('admin');
    
    if (adminExists.count === 0) {
      console.log('Criando usuário admin...');
      const hashedPassword = hashPasswordSync('admin123');
      db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
        .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
      console.log('Usuário admin criado com sucesso!');
    }
    
    console.log('Banco de dados inicializado com sucesso!');
  } catch (error) {
    console.error('Erro ao inicializar o banco de dados:', error);
    process.exit(1);
  }
}

// Função para criar a base de dados MySQL (adaptada para retornar o wrapper do SQLite)
function createDatabase() {
  if (!db) {
    initializeDatabase();
  }
  
  return {
    // Wrapper para simular o comportamento do MySQL
    query: async (sql, params = []) => {
      try {
        if (sql.trim().toUpperCase().startsWith('SELECT')) {
          const stmt = db.prepare(sql);
          const results = stmt.all(...params);
          return [results]; // MySQL retorna array de arrays
        } else {
          const stmt = db.prepare(sql);
          const result = stmt.run(...params);
          return [result];
        }
      } catch (error) {
        console.error('Erro na query:', error);
        throw error;
      }
    },
    
    // Funções auxiliares
    comparePassword: comparePassword,
    hashPassword: async (password) => {
      return bcrypt.hash(password, 10);
    },
    
    // Fechar conexão
    close: () => {
      if (db) {
        db.close();
      }
    }
  };
}

module.exports = {
  createDatabase,
  initializeDatabase,
  comparePassword
};