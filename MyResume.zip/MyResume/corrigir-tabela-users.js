const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

console.log('=== CORREÇÃO DA TABELA USERS ===');

try {
    const db = new Database('./users.db');
    
    // Fazer backup dos dados existentes
    console.log('📦 Fazendo backup dos usuários existentes...');
    const usuariosExistentes = db.prepare('SELECT * FROM users').all();
    console.log(`Usuários encontrados: ${usuariosExistentes.length}`);
    
    usuariosExistentes.forEach(user => {
        console.log(`- ${user.username} (${user.profile_type})`);
    });
    
    // Renomear tabela atual
    console.log('\n🔄 Renomeando tabela atual...');
    db.exec('ALTER TABLE users RENAME TO users_backup');
    
    // Criar nova tabela sem constraints restritivos
    console.log('🏗️ Criando nova tabela users...');
    db.exec(`
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            profile_type TEXT NOT NULL,
            email TEXT UNIQUE,
            nome_completo TEXT,
            processo_id INTEGER,
            two_factor_code TEXT,
            two_factor_expires TIMESTAMP
        )
    `);
    
    // Restaurar dados
    console.log('📋 Restaurando dados dos usuários...');
    const insertStmt = db.prepare(`
        INSERT INTO users (id, username, password, profile_type, email, nome_completo, processo_id, two_factor_code, two_factor_expires)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    usuariosExistentes.forEach(user => {
        insertStmt.run(
            user.id,
            user.username,
            user.password,
            user.profile_type,
            user.email,
            user.nome_completo,
            user.processo_id,
            user.two_factor_code,
            user.two_factor_expires
        );
        console.log(`✅ Restaurado: ${user.username}`);
    });
    
    // Remover tabela de backup
    console.log('\n🗑️ Removendo backup...');
    db.exec('DROP TABLE users_backup');
    
    // Agora criar os novos usuários
    console.log('\n👥 Criando novos usuários de perfis...');
    
    const novosUsuarios = {
        financeiro: {
            username: 'financeiro',
            password: 'financeiro123',
            profile_type: 'financeiro',
            email: 'financeiro@camigap.com',
            nome_completo: 'João Financeiro'
        },
        secretario_geral: {
            username: 'secretario',
            password: 'secretario123', 
            profile_type: 'secretario_geral',
            email: 'secretario@camigap.com',
            nome_completo: 'Maria Secretária'
        },
        auditor: {
            username: 'auditor',
            password: 'auditor123',
            profile_type: 'auditor', 
            email: 'auditor@camigap.com',
            nome_completo: 'Carlos Auditor'
        },
        coordenador: {
            username: 'coordenador',
            password: 'coordenador123',
            profile_type: 'coordenador',
            email: 'coordenador@camigap.com',
            nome_completo: 'Ana Coordenadora'
        }
    };
    
    for (const [tipo, dados] of Object.entries(novosUsuarios)) {
        const userExists = db.prepare('SELECT COUNT(*) as count FROM users WHERE username = ?').get(dados.username);
        
        if (userExists.count === 0) {
            console.log(`Criando usuário ${tipo}...`);
            
            const hashedPassword = bcrypt.hashSync(dados.password, 10);
            
            const result = db.prepare(`
                INSERT INTO users (username, password, profile_type, email, nome_completo) 
                VALUES (?, ?, ?, ?, ?)
            `).run(
                dados.username,
                hashedPassword,
                dados.profile_type,
                dados.email,
                dados.nome_completo
            );
            
            console.log(`✅ Usuário ${tipo} criado com ID ${result.lastInsertRowid}`);
            console.log(`   Username: ${dados.username}`);
            console.log(`   Senha: ${dados.password}`);
            console.log(`   Email: ${dados.email}`);
        } else {
            console.log(`✅ Usuário ${tipo} já existe`);
        }
    }
    
    // Verificar usuários finais
    console.log('\n=== USUÁRIOS FINAIS ===');
    const todosUsuarios = db.prepare('SELECT id, username, email, profile_type FROM users ORDER BY id').all();
    todosUsuarios.forEach(user => {
        console.log(`- ID: ${user.id}, Username: ${user.username}, Email: ${user.email}, Perfil: ${user.profile_type}`);
    });
    
    db.close();
    console.log('\n✅ Correção da tabela users concluída!');
    console.log('\n📋 CREDENCIAIS DOS NOVOS PERFIS:');
    console.log('👤 Admin: admin / admin123');
    console.log('💰 Financeiro: financeiro / financeiro123');
    console.log('📝 Secretário: secretario / secretario123');
    console.log('🔍 Auditor: auditor / auditor123');
    console.log('👑 Coordenador: coordenador / coordenador123');
    
} catch (error) {
    console.error('❌ Erro geral:', error.message);
    console.error(error.stack);
}