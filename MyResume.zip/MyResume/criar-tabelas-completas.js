const Database = require('better-sqlite3');
const path = require('path');

console.log('=== CRIAÇÃO DE TABELAS COMPLETAS ===');

try {
    const dbPath = path.join(__dirname, 'users.db');
    const db = new Database(dbPath);
    
    // Verificar tabelas existentes
    const tabelasExistentes = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('Tabelas existentes antes:', tabelasExistentes.map(t => t.name));
    
    // Definir todas as tabelas necessárias
    const tabelas = {
        processos: `
            CREATE TABLE IF NOT EXISTS processos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo_servico TEXT NOT NULL,
                natureza_litigio TEXT,
                valor_pretensao DECIMAL(10,2),
                dados_formulario TEXT,
                arquivos TEXT,
                status TEXT DEFAULT 'pendente',
                responsavel_id INTEGER,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `,
        profissionais: `
            CREATE TABLE IF NOT EXISTS profissionais (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                tipo TEXT NOT NULL CHECK(tipo IN ('arbitro', 'mediador', 'conciliador')),
                especialidade TEXT,
                registro_profissional TEXT,
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `,
        documentos: `
            CREATE TABLE IF NOT EXISTS documentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                processo_id INTEGER,
                tipo TEXT NOT NULL,
                nome_arquivo TEXT,
                caminho_arquivo TEXT,
                enviado_por TEXT,
                data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                tamanho_arquivo INTEGER,
                FOREIGN KEY (processo_id) REFERENCES processos(id)
            )
        `,
        pedidos_documentos: `
            CREATE TABLE IF NOT EXISTS pedidos_documentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                processo_id INTEGER,
                solicitante TEXT,
                destinatario TEXT,
                tipo_documento TEXT,
                descricao TEXT,
                prazo_limite DATE,
                status TEXT DEFAULT 'pendente',
                data_solicitacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                data_envio TIMESTAMP,
                FOREIGN KEY (processo_id) REFERENCES processos(id)
            )
        `,
        pagamentos: `
            CREATE TABLE IF NOT EXISTS pagamentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                processo_id INTEGER,
                valor DECIMAL(10,2),
                tipo_pagamento TEXT,
                status TEXT DEFAULT 'pendente',
                data_pagamento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                comprovativo TEXT,
                FOREIGN KEY (processo_id) REFERENCES processos(id)
            )
        `,
        vereditos: `
            CREATE TABLE IF NOT EXISTS vereditos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                processo_id INTEGER,
                profissional_id INTEGER,
                decisao TEXT,
                justificativa TEXT,
                data_veredito TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'pendente',
                FOREIGN KEY (processo_id) REFERENCES processos(id),
                FOREIGN KEY (profissional_id) REFERENCES profissionais(id)
            )
        `
    };
    
    // Criar cada tabela
    for (const [nomeTabela, sql] of Object.entries(tabelas)) {
        console.log(`\nCriando/verificando tabela ${nomeTabela}...`);
        
        try {
            db.exec(sql);
            console.log(`✅ Tabela ${nomeTabela} criada/verificada com sucesso`);
            
            // Mostrar estrutura da tabela
            const estrutura = db.prepare(`PRAGMA table_info(${nomeTabela})`).all();
            console.log(`   Colunas: ${estrutura.map(col => `${col.name}(${col.type})`).join(', ')}`);
            
        } catch (error) {
            console.error(`❌ Erro ao criar tabela ${nomeTabela}:`, error.message);
        }
    }
    
    // Verificar tabelas finais
    const tabelasFinais = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('\n=== RESUMO FINAL ===');
    console.log('Tabelas disponíveis:', tabelasFinais.map(t => t.name));
    
    db.close();
    console.log('\n✅ Processo concluído!');
    
} catch (error) {
    console.error('❌ Erro geral:', error.message);
}