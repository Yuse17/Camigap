const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

console.log('=== TESTE DO USUÁRIO ADMIN ===');
console.log();

// Conectar à base de dados
const dbPath = path.join(__dirname, 'users.db');
console.log('Caminho da base de dados:', dbPath);

try {
    const db = new Database(dbPath);
    
    // Verificar se a tabela users existe
    const tabelas = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('Tabelas existentes:', tabelas.map(t => t.name));
    
    // Verificar estrutura da tabela users
    if (tabelas.some(t => t.name === 'users')) {
        const estrutura = db.prepare("PRAGMA table_info(users)").all();
        console.log();
        console.log('Estrutura da tabela users:');
        estrutura.forEach(col => {
            console.log(`- ${col.name} (${col.type})`);
        });
        
        // Verificar todos os usuários
        const usuarios = db.prepare('SELECT id, username, email, profile_type FROM users').all();
        console.log();
        console.log('Usuários na base de dados:');
        if (usuarios.length === 0) {
            console.log('❌ Nenhum usuário encontrado!');
        } else {
            usuarios.forEach(user => {
                console.log(`- ID: ${user.id}, Username: ${user.username}, Email: ${user.email}, Tipo: ${user.profile_type}`);
            });
        }
        
        // Testar senha do admin se existir
        const admin = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get('admin', 'admin@camigap.com');
        if (admin) {
            console.log();
            console.log('=== TESTE DE SENHA ===');
            console.log('Usuário admin encontrado:', admin.username);
            
            // Testar senha
            const senhaCorreta = bcrypt.compareSync('admin123', admin.password);
            console.log('Senha "admin123" está correta:', senhaCorreta ? '✅ SIM' : '❌ NÃO');
            
            if (!senhaCorreta) {
                console.log('Hash da senha no banco:', admin.password);
                // Tentar criar nova hash
                const novaHash = bcrypt.hashSync('admin123', 10);
                console.log('Nova hash gerada:', novaHash);
                
                // Atualizar senha no banco
                db.prepare('UPDATE users SET password = ? WHERE username = ?').run(novaHash, 'admin');
                console.log('✅ Senha do admin atualizada!');
            }
        } else {
            console.log('❌ Usuário admin não encontrado!');
            
            // Criar usuário admin
            console.log('Criando usuário admin...');
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
                .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
            console.log('✅ Usuário admin criado!');
        }
        
    } else {
        console.log('❌ Tabela users não existe!');
        
        // Criar tabela users
        console.log('Criando tabela users...');
        db.exec(`
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                profile_type TEXT NOT NULL CHECK(profile_type IN ('admin', 'secretario', 'profissional', 'parte')),
                email TEXT UNIQUE,
                nome_completo TEXT,
                processo_id INTEGER,
                two_factor_code TEXT,
                two_factor_expires TIMESTAMP
            )
        `);
        
        // Criar usuário admin
        const hashedPassword = bcrypt.hashSync('admin123', 10);
        db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
            .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
        console.log('✅ Tabela e usuário admin criados!');
    }
    
    db.close();
    
} catch (error) {
    console.error('❌ Erro:', error);
}

console.log();
console.log('=== CREDENCIAIS FINAIS ===');
console.log('Username: admin');
console.log('Email: admin@camigap.com');
console.log('Senha: admin123');
console.log();