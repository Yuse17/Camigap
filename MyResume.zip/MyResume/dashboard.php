<?php
session_start();

// Verificar se o admin está autenticado
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Admin</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background-color: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h2, h3 { color: #333; }
        .message { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        form { background-color: #f9f9f9; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #45a049; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
        tr:hover { background-color: #f5f5f5; }
        a { color: #2196F3; text-decoration: none; }
        a:hover { text-decoration: underline; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .logout { background-color: #f44336; color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; }
        .logout:hover { background-color: #d32f2f; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Bem-vindo, <?php echo htmlspecialchars($_SESSION['username']); ?></h2>
            <a href="logout.php" class="logout">Sair</a>
        </div>
        
        <?php if (isset($_SESSION['create_success'])): ?>
            <div class="message success"><?php echo $_SESSION['create_success']; unset($_SESSION['create_success']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['create_error'])): ?>
            <div class="message error"><?php echo $_SESSION['create_error']; unset($_SESSION['create_error']); ?></div>
        <?php endif; ?>
    
    <h3>Gerir Perfis</h3>
    <form action="users.php" method="post">
        <div style="margin-bottom: 15px;">
            <label for="user">Nome do Utilizador:</label>
            <input type="text" name="user" required>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label for="profile_type">Tipo de Perfil:</label>
            <select name="profile_type" required>
                <option value="arbitro">Árbitro</option>
                <option value="mediador">Mediador</option>
                <option value="secretario">Secretário</option>
                <option value="financeiro">Financeiro</option>
                <option value="consultor">Consultor</option>
                <option value="analista">Analista</option>
                <option value="auditor">Auditor</option>
                <option value="coordenador">Coordenador</option>
                <option value="assistente">Assistente</option>
                <option value="supervisor">Supervisor</option>
            </select>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label for="password">Senha:</label>
            <input type="password" name="password" placeholder="Deixe em branco para senha padrão">
        </div>
        
        <button type="submit">Criar Utilizador</button>
    </form>
    
    <h3>Lista de Perfis Existentes</h3>
    <?php
    require 'database.php';
    try {
        $stmt = $pdo->query("SELECT id, username, profile_type, created_at FROM users ORDER BY created_at DESC");
        if ($stmt->rowCount() > 0) {
            echo "<table style='width: 100%; border-collapse: collapse; margin-top: 20px;'>";
            echo "<tr style='background-color: #f2f2f2;'>";
            echo "<th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Utilizador</th>";
            echo "<th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Tipo de Perfil</th>";
            echo "<th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Data de Criação</th>";
            echo "<th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Ações</th>";
            echo "</tr>";
            
            while ($row = $stmt->fetch()) {
                echo "<tr>";
                echo "<td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['profile_type']) . "</td>";
                echo "<td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['created_at']) . "</td>";
                echo "<td style='padding: 10px; border: 1px solid #ddd;'>";
                if ($row['username'] !== 'admin') {
                    echo "<a href='users.php?action=reset_password&id=" . $row['id'] . "' style='margin-right: 10px;'>Redefinir Senha</a>";
                    echo "<a href='users.php?action=delete&id=" . $row['id'] . "' onclick='return confirm(\"Tem certeza que deseja excluir este usuário?\")'>Excluir</a>";
                } else {
                    echo "Admin (Protegido)";
                }
                echo "</td>";
                echo "</tr>";
            }
            
            echo "</table>";
        } else {
            echo "<p>Nenhum perfil encontrado.</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Erro ao carregar perfis: " . $e->getMessage() . "</p>";
    }
    ?>
    </div>
</body>
</html>