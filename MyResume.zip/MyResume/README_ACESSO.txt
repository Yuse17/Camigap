=====================================================
   INSTRUÇÕES PARA ACESSAR O SISTEMA CAMIGAP
=====================================================

MÉTODO RECOMENDADO (COM DOCKER):
------------------------------

1. Instale o Docker Desktop (https://www.docker.com/products/docker-desktop)
2. Execute o arquivo "CAMIGAP.bat"
3. Escolha a opção D1: "Iniciar com Docker (melhor para acesso remoto)"
4. Anote um dos endereços IP mostrados (ex: http://192.168.1.100:3000)
5. Em outro computador, abra um navegador e digite esse endereço

VANTAGENS DO MÉTODO COM DOCKER:
-----------------------------
- Funciona em qualquer rede
- Não precisa configurar firewall
- Mais estável e confiável
- Continua rodando em segundo plano

MÉTODO ALTERNATIVO (SEM DOCKER):
------------------------------

1. Execute o arquivo "CAMIGAP.bat"
2. Escolha a opção 5: "Iniciar servidor fácil (recomendado)"
3. Anote um dos endereços IP mostrados (ex: http://192.168.1.100:3000)
4. Em outro computador, abra um navegador e digite esse endereço

SOLUÇÃO DE PROBLEMAS:
--------------------

Se não conseguir acessar o sistema de outro computador:

1. VERIFIQUE O FIREWALL:
   - Execute "CAMIGAP.bat" e escolha a opção 6: "Configurar firewall"
   - Execute como administrador quando solicitado

2. VERIFIQUE SE OS COMPUTADORES ESTÃO NA MESMA REDE:
   - Certifique-se de que ambos os computadores estão conectados à mesma rede Wi-Fi ou LAN
   - Tente fazer ping do computador cliente para o servidor

3. TESTE COM NGROK (ACESSO PELA INTERNET):
   - Execute "CAMIGAP.bat" e escolha a opção 4: "Iniciar servidor com ngrok"
   - Use o endereço fornecido pelo ngrok (funciona de qualquer lugar)

PARA MAIS INFORMAÇÕES:
---------------------

Execute "CAMIGAP.bat" e escolha a opção 9: "Instruções de acesso remoto"

=====================================================