const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'users.db');

// Função para registrar logs do sistema
function logActivity(tipo, usuario, acao, detalhes = null, ip = null, userAgent = null) {
  try {
    const db = new Database(dbPath);
    
    // Criar tabela de logs se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS system_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT NOT NULL,
        usuario TEXT NOT NULL,
        acao TEXT NOT NULL,
        detalhes TEXT,
        ip TEXT,
        user_agent TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    const stmt = db.prepare(`
      INSERT INTO system_logs (tipo, usuario, acao, detalhes, ip, user_agent) 
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(tipo, usuario, acao, detalhes, ip, userAgent);
    db.close();
    
    console.log(`📝 LOG: [${tipo}] ${usuario} - ${acao} ${detalhes ? '- ' + detalhes : ''}`);
  } catch (error) {
    console.error('❌ Erro ao registrar log:', error);
  }
}

// Função para obter logs do sistema (para admin)
function getLogs(filtros = {}) {
  try {
    const db = new Database(dbPath);
    
    let whereClause = [];
    let params = [];
    
    if (filtros.tipo) {
      whereClause.push('tipo = ?');
      params.push(filtros.tipo);
    }
    
    if (filtros.usuario) {
      whereClause.push('usuario LIKE ?');
      params.push(`%${filtros.usuario}%`);
    }
    
    if (filtros.dataInicio) {
      whereClause.push('DATE(timestamp) >= ?');
      params.push(filtros.dataInicio);
    }
    
    if (filtros.dataFim) {
      whereClause.push('DATE(timestamp) <= ?');
      params.push(filtros.dataFim);
    }
    
    const whereSQL = whereClause.length > 0 ? 'WHERE ' + whereClause.join(' AND ') : '';
    
    const stmt = db.prepare(`
      SELECT * FROM system_logs 
      ${whereSQL} 
      ORDER BY timestamp DESC 
      LIMIT 100
    `);
    
    const logs = stmt.all(...params);
    db.close();
    
    return logs;
  } catch (error) {
    console.error('Erro ao obter logs:', error);
    return [];
  }
}

// Função para obter estatísticas de logs
function getLogStats() {
  try {
    const db = new Database(dbPath);
    
    // Total de logs
    const totalStmt = db.prepare('SELECT COUNT(*) as total FROM system_logs');
    const total = totalStmt.get().total;
    
    // Logs por tipo
    const tiposStmt = db.prepare(`
      SELECT tipo, COUNT(*) as quantidade 
      FROM system_logs 
      GROUP BY tipo 
      ORDER BY quantidade DESC
    `);
    const logsPorTipo = tiposStmt.all();
    
    // Logs por usuário (top 10)
    const usuariosStmt = db.prepare(`
      SELECT usuario, COUNT(*) as quantidade 
      FROM system_logs 
      GROUP BY usuario 
      ORDER BY quantidade DESC 
      LIMIT 10
    `);
    const logsPorUsuario = usuariosStmt.all();
    
    // Logs por data (últimos 7 dias)
    const datasStmt = db.prepare(`
      SELECT DATE(timestamp) as data, COUNT(*) as quantidade 
      FROM system_logs 
      WHERE timestamp >= datetime('now', '-7 days') 
      GROUP BY DATE(timestamp) 
      ORDER BY data DESC
    `);
    const logsPorData = datasStmt.all();
    
    // Últimas ações críticas
    const criticasStmt = db.prepare(`
      SELECT * FROM system_logs 
      WHERE tipo IN ('LOGIN_FAIL', 'UNAUTHORIZED_ACCESS', 'DELETE', 'PASSWORD_RESET') 
      ORDER BY timestamp DESC 
      LIMIT 20
    `);
    const acoesCriticas = criticasStmt.all();
    
    db.close();
    
    return {
      total,
      logsPorTipo,
      logsPorUsuario,
      logsPorData,
      acoesCriticas
    };
  } catch (error) {
    console.error('Erro ao obter estatísticas de logs:', error);
    return {
      total: 0,
      logsPorTipo: [],
      logsPorUsuario: [],
      logsPorData: [],
      acoesCriticas: []
    };
  }
}

// Função para obter logs com paginação avançada
function getLogsAdvanced(filtros = {}, pagina = 1, limite = 50) {
  try {
    const db = new Database(dbPath);
    
    let whereClause = [];
    let params = [];
    
    if (filtros.tipo) {
      whereClause.push('tipo = ?');
      params.push(filtros.tipo);
    }
    
    if (filtros.usuario) {
      whereClause.push('usuario LIKE ?');
      params.push(`%${filtros.usuario}%`);
    }
    
    if (filtros.acao) {
      whereClause.push('acao LIKE ?');
      params.push(`%${filtros.acao}%`);
    }
    
    if (filtros.ip) {
      whereClause.push('ip = ?');
      params.push(filtros.ip);
    }
    
    if (filtros.dataInicio) {
      whereClause.push('DATE(timestamp) >= ?');
      params.push(filtros.dataInicio);
    }
    
    if (filtros.dataFim) {
      whereClause.push('DATE(timestamp) <= ?');
      params.push(filtros.dataFim);
    }
    
    const whereSQL = whereClause.length > 0 ? 'WHERE ' + whereClause.join(' AND ') : '';
    
    // Contar total de registros
    const countStmt = db.prepare(`
      SELECT COUNT(*) as total FROM system_logs ${whereSQL}
    `);
    const total = countStmt.get(...params).total;
    
    // Obter logs com paginação
    const offset = (pagina - 1) * limite;
    const logsStmt = db.prepare(`
      SELECT * FROM system_logs 
      ${whereSQL} 
      ORDER BY timestamp DESC 
      LIMIT ? OFFSET ?
    `);
    
    const logs = logsStmt.all(...params, limite, offset);
    
    db.close();
    
    return {
      logs,
      total,
      pagina,
      limite,
      totalPaginas: Math.ceil(total / limite)
    };
  } catch (error) {
    console.error('Erro ao obter logs avançados:', error);
    return {
      logs: [],
      total: 0,
      pagina: 1,
      limite: 50,
      totalPaginas: 0
    };
  }
}

// Função para exportar logs (CSV)
function exportLogsCSV(filtros = {}) {
  try {
    const { logs } = getLogsAdvanced(filtros, 1, 10000); // Máximo 10k registros
    
    let csv = 'ID,Tipo,Usuario,Acao,Detalhes,IP,User-Agent,Timestamp\n';
    
    logs.forEach(log => {
      const linha = [
        log.id,
        `"${log.tipo}"`,
        `"${log.usuario}"`,
        `"${log.acao}"`,
        `"${log.detalhes || ''}"`,
        `"${log.ip || ''}"`,
        `"${log.user_agent || ''}"`,
        `"${log.timestamp}"`
      ].join(',');
      
      csv += linha + '\n';
    });
    
    return csv;
  } catch (error) {
    console.error('Erro ao exportar logs:', error);
    return '';
  }
}

// Função para limpar logs antigos (manter apenas últimos 30 dias)
function cleanOldLogs() {
  try {
    const db = new Database(dbPath);
    
    const stmt = db.prepare(`
      DELETE FROM system_logs 
      WHERE timestamp < datetime('now', '-30 days')
    `);
    
    const result = stmt.run();
    db.close();
    
    console.log(`🧹 Logs limpos: ${result.changes} registros removidos`);
    
    // Registrar a limpeza como um log
    logActivity('SYSTEM', 'SYSTEM', 'LOG_CLEANUP', `${result.changes} registros removidos`);
  } catch (error) {
    console.error('❌ Erro ao limpar logs:', error);
  }
}

module.exports = {
  logActivity,
  getLogs,
  getLogStats,
  getLogsAdvanced,
  exportLogsCSV,
  cleanOldLogs
};
