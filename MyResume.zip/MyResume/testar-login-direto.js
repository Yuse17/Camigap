const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

// Simular exatamente o que acontece no app.js
async function testarLoginCompleto() {
    console.log('=== TESTE COMPLETO DE LOGIN ===');
    console.log();
    
    const email = 'admin';
    const password = 'admin123';
    
    console.log('=== TENTATIVA DE LOGIN ===');
    console.log('Email/Username:', email);
    console.log('Senha:', password ? '*'.repeat(password.length) : 'vazia');
    
    try {
        // Usar o mesmo database.js que o app usa
        const dbModule = require('./database.js');
        const db = dbModule.createDatabase();
        
        // Buscar usuário pelo e-mail ou username (para admin)
        console.log();
        console.log('Executando query...');
        const [users] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, email]);
        const user = users[0];
        
        console.log('Usuário encontrado:', user ? `${user.username} (${user.profile_type})` : 'nenhum');
        
        if (user) {
            console.log();
            console.log('Testando senha...');
            const senhaCorreta = await db.comparePassword(password, user.password);
            console.log('Resultado da comparação:', senhaCorreta);
            
            if (senhaCorreta) {
                console.log('Senha validada com sucesso!');
                
                if (user.profile_type === 'admin') {
                    console.log('✅ LOGIN SERIA APROVADO!');
                    console.log('Dados da sessão que seriam criados:');
                    console.log('- userId:', user.id);
                    console.log('- username:', user.username);
                    console.log('- profileType:', user.profile_type);
                    console.log('- adminLoggedIn:', true);
                    console.log('- Redirecionaria para: /dashboard');
                } else {
                    console.log('❌ Usuário não é admin');
                }
            } else {
                console.log('❌ Senha incorreta');
            }
        } else {
            console.log('❌ Usuário não encontrado');
        }
        
        db.close();
        
    } catch (error) {
        console.error('❌ Erro:', error);
        console.error('Stack:', error.stack);
    }
}

testarLoginCompleto();