const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// Configuração do banco de dados SQLite
const dbPath = path.join(__dirname, 'database.sqlite');
let db;

// Inicializar o banco de dados
function initDatabase() {
  try {
    console.log('Inicializando banco de dados SQLite...');
    
    // Criar diretório para o banco de dados se não existir
    const dbDir = path.dirname(dbPath);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    
    // Conectar ao banco de dados SQLite
    db = new Database(dbPath);
    
    // Habilitar chaves estrangeiras
    db.pragma('foreign_keys = ON');
    
    // Criar tabela de usuários se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT UNIQUE,
        nome_completo TEXT,
        profile_type TEXT NOT NULL,
        processo_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        two_factor_code TEXT,
        two_factor_expires TIMESTAMP,
        FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE SET NULL
      )
    `);
    
    // Verificar se a coluna email já tem o constraint UNIQUE
    try {
      const emailIsUnique = db.prepare("PRAGMA index_list(users)").all()
        .some(idx => idx.name === 'sqlite_autoindex_users_2');
      
      if (!emailIsUnique) {
        // Adicionar constraint UNIQUE para email
        console.log("Adicionando constraint UNIQUE para o campo email na tabela users");
        // Não é possível adicionar constraint UNIQUE diretamente no SQLite, seria necessário recriar a tabela
      }
    } catch (error) {
      console.error("Erro ao verificar constraint UNIQUE para email:", error);
    }
    
    // Verificar se as colunas two_factor_code e two_factor_expires existem
    try {
      const columns = db.prepare("PRAGMA table_info(users)").all();
      const twoFactorCodeExists = columns.some(col => col.name === 'two_factor_code');
      const twoFactorExpiresExists = columns.some(col => col.name === 'two_factor_expires');
      
      if (!twoFactorCodeExists) {
        db.exec("ALTER TABLE users ADD COLUMN two_factor_code TEXT");
        console.log("Coluna 'two_factor_code' adicionada à tabela users");
      }
      
      if (!twoFactorExpiresExists) {
        db.exec("ALTER TABLE users ADD COLUMN two_factor_expires TIMESTAMP");
        console.log("Coluna 'two_factor_expires' adicionada à tabela users");
      }
    } catch (error) {
      console.error("Erro ao verificar/adicionar colunas para autenticação de dois fatores:", error);
    }
    
    // Verificar se as colunas novas existem e adicioná-las se necessário
    try {
      // Verificar se a coluna email existe
      const emailExists = db.prepare("PRAGMA table_info(users)").all().some(col => col.name === 'email');
      if (!emailExists) {
        db.exec("ALTER TABLE users ADD COLUMN email TEXT");
        console.log("Coluna 'email' adicionada à tabela users");
      }
      
      // Verificar se a coluna nome_completo existe
      const nomeCompletoExists = db.prepare("PRAGMA table_info(users)").all().some(col => col.name === 'nome_completo');
      if (!nomeCompletoExists) {
        db.exec("ALTER TABLE users ADD COLUMN nome_completo TEXT");
        console.log("Coluna 'nome_completo' adicionada à tabela users");
      }
      
      // Verificar se a coluna processo_id existe
      const processoIdExists = db.prepare("PRAGMA table_info(users)").all().some(col => col.name === 'processo_id');
      if (!processoIdExists) {
        db.exec("ALTER TABLE users ADD COLUMN processo_id INTEGER REFERENCES processos(id) ON DELETE SET NULL");
        console.log("Coluna 'processo_id' adicionada à tabela users");
      }
    } catch (error) {
      console.error("Erro ao adicionar colunas à tabela users:", error);
    }
    
    // Criar tabela de processos se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS processos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo_servico TEXT NOT NULL CHECK(tipo_servico IN ('arbitragem', 'mediacao', 'conciliacao')),
        natureza_litigio TEXT NOT NULL,
        valor_pretensao REAL,
        status TEXT NOT NULL DEFAULT 'pendente' CHECK(status IN ('pendente', 'em_andamento', 'encerrado')),
        pagamento_verificado BOOLEAN DEFAULT 0,
        data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        dados_formulario TEXT NOT NULL,
        arquivos TEXT,
        responsavel_id INTEGER,
        FOREIGN KEY (responsavel_id) REFERENCES users(id) ON DELETE SET NULL
      )
    `);
    
    // Verificar se a coluna responsavel_id existe na tabela processos
    try {
      const responsavelIdExists = db.prepare("PRAGMA table_info(processos)").all().some(col => col.name === 'responsavel_id');
      if (!responsavelIdExists) {
        db.exec("ALTER TABLE processos ADD COLUMN responsavel_id INTEGER REFERENCES users(id) ON DELETE SET NULL");
        console.log("Coluna 'responsavel_id' adicionada à tabela processos");
      }
      
      // Verificar se a coluna data_peticao_inicial existe na tabela processos
      const dataPeticaoInicialExists = db.prepare("PRAGMA table_info(processos)").all().some(col => col.name === 'data_peticao_inicial');
      if (!dataPeticaoInicialExists) {
        db.exec("ALTER TABLE processos ADD COLUMN data_peticao_inicial TIMESTAMP");
        console.log("Coluna 'data_peticao_inicial' adicionada à tabela processos");
      }
    } catch (error) {
      console.error("Erro ao adicionar colunas à tabela processos:", error);
    }
    
    // Criar tabela de documentos se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS documentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        processo_id INTEGER NOT NULL,
        tipo TEXT NOT NULL,
        descricao TEXT,
        caminho_arquivo TEXT NOT NULL,
        enviado_por TEXT NOT NULL,
        data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE CASCADE
      )
    `);
    
    // Criar tabela de profissionais (árbitros, mediadores, conciliadores)
    db.exec(`
      CREATE TABLE IF NOT EXISTS profissionais (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        tipo TEXT NOT NULL CHECK(tipo IN ('arbitro', 'mediador', 'conciliador')),
        especialidade TEXT,
        biografia TEXT,
        disponivel BOOLEAN DEFAULT 1,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);
    
    // Criar tabela de histórico do processo
    db.exec(`
      CREATE TABLE IF NOT EXISTS historico_processo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        processo_id INTEGER NOT NULL,
        tipo_evento TEXT NOT NULL,
        descricao TEXT NOT NULL,
        usuario TEXT NOT NULL,
        observacoes TEXT,
        data_evento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE CASCADE
      )
    `);
    
    // Criar tabela de vereditos pendentes se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS vereditos_pendentes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        processo_id INTEGER NOT NULL,
        profissional_id INTEGER NOT NULL,
        tipo_veredito TEXT NOT NULL,
        descricao TEXT,
        observacoes TEXT,
        documento_id INTEGER,
        status TEXT NOT NULL DEFAULT 'pendente' CHECK(status IN ('pendente', 'aprovado', 'rejeitado')),
        motivo_rejeicao TEXT,
        data_submissao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_validacao TIMESTAMP,
        validado_por INTEGER,
        FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE CASCADE,
        FOREIGN KEY (profissional_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (documento_id) REFERENCES documentos(id) ON DELETE SET NULL,
        FOREIGN KEY (validado_por) REFERENCES users(id) ON DELETE SET NULL
      )
    `);
    
    // Criar tabela de notificações se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS notificacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        titulo TEXT NOT NULL,
        mensagem TEXT NOT NULL,
        link TEXT,
        lida BOOLEAN DEFAULT 0,
        prioridade TEXT DEFAULT 'normal' CHECK(prioridade IN ('baixa', 'normal', 'alta')),
        data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_leitura TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);
    
    // Criar tabela de pedidos de documentos se não existir
    db.exec(`
      CREATE TABLE IF NOT EXISTS pedidos_documentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        processo_id INTEGER NOT NULL,
        solicitante TEXT NOT NULL,
        destinatario TEXT NOT NULL,
        tipo_documento TEXT NOT NULL,
        descricao TEXT,
        prazo_limite DATE,
        status TEXT NOT NULL DEFAULT 'pendente' CHECK(status IN ('pendente', 'atendido', 'recusado')),
        documento_id INTEGER,
        motivo_recusa TEXT,
        data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE CASCADE,
        FOREIGN KEY (documento_id) REFERENCES documentos(id) ON DELETE SET NULL
      )
    `);
    
    // Verificar se o admin já existe
    const adminExists = db.prepare('SELECT COUNT(*) as count FROM users WHERE username = ?').get('admin');
    
    // Inserir admin padrão se não existir
    if (adminExists.count === 0) {
      const hashedPassword = hashPasswordSync('admin123');
      db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
        .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
      console.log('Usuário admin criado com sucesso!');
    } else {
      // Verificar se o admin já tem email definido
      const admin = db.prepare('SELECT email FROM users WHERE username = ?').get('admin');
      if (!admin.email) {
        db.prepare('UPDATE users SET email = ? WHERE username = ?')
          .run('admin@camigap.com', 'admin');
        console.log('Email do admin atualizado com sucesso!');
      }
    }
    
    console.log('Banco de dados inicializado com sucesso!');
  } catch (error) {
    console.error('Erro ao inicializar o banco de dados:', error);
    process.exit(1);
  }
}

// Função para hash de senha (síncrona para inicialização)
function hashPasswordSync(password) {
  const salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(password, salt);
}

// Função para hash de senha (assíncrona para uso normal)
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
}

// Função para comparar senha
async function comparePassword(password, hashedPassword) {
  return await bcrypt.compare(password, hashedPassword);
}

// Função para executar consultas
async function query(sql, params = []) {
  try {
    if (!db) {
      throw new Error('Banco de dados não inicializado.');
    }
    
    console.log(`Executando query: ${sql}`);
    console.log(`Parâmetros: ${JSON.stringify(params)}`);
    
    // Determinar o tipo de consulta
    const firstWord = sql.trim().split(' ')[0].toUpperCase();
    
    if (firstWord === 'SELECT') {
      // Para consultas SELECT, retornar todas as linhas
      const stmt = db.prepare(sql);
      const rows = stmt.all(...params);
      console.log(`Resultado SELECT: ${rows.length} registros encontrados`);
      return [rows, null]; // Formato similar ao mysql2
    } else {
      // Para INSERT, UPDATE, DELETE
      const stmt = db.prepare(sql);
      const result = stmt.run(...params);
      console.log(`Resultado ${firstWord}: affectedRows=${result.changes}, insertId=${result.lastInsertRowid}`);
      return [{ affectedRows: result.changes, insertId: result.lastInsertRowid }, null];
    }
  } catch (error) {
    console.error('Erro na consulta SQL:', error);
    console.error(error.stack);
    throw error;
  }
}

// Inicializar o banco de dados ao carregar o módulo
initDatabase();

// Função para obter uma conexão para transações
async function getConnection() {
  if (!db) {
    throw new Error('Banco de dados não inicializado.');
  }
  
  // No SQLite, não há um pool de conexões como no MySQL
  // Retornamos um objeto que simula a interface de uma conexão MySQL
  return {
    query: async (sql, params = []) => {
      const stmt = db.prepare(sql);
      if (sql.trim().toUpperCase().startsWith('SELECT')) {
        const rows = stmt.all(...params);
        return [rows, null];
      } else {
        const result = stmt.run(...params);
        return [{ affectedRows: result.changes, insertId: result.lastInsertRowid }, null];
      }
    },
    beginTransaction: async () => {
      db.exec('BEGIN TRANSACTION');
    },
    commit: async () => {
      db.exec('COMMIT');
    },
    rollback: async () => {
      db.exec('ROLLBACK');
    },
    release: () => {
      // No SQLite não precisamos liberar conexões
    }
  };
}

module.exports = {
  query,
  hashPassword,
  comparePassword,
  getConnection
};