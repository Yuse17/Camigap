const http = require('http');
const querystring = require('querystring');

function testarArbitragemSimples() {
    console.log('=== TESTE SIMPLES DE ARBITRAGEM ===');
    
    // Dados mínimos necessários
    const dados = {
        naturezaLitigio: 'Comercial',
        valorPretensao: '25000.00',
        descricaoLitigio: 'Disputa sobre contrato de prestação de serviços entre duas empresas',
        
        // Dados básicos do requerente
        nomeRequerente: 'João Silva Teste',
        emailRequerente: 'joao@teste.com',
        telefoneRequerente: '912345678',
        moradaRequerente: 'Rua de Teste, 123, 1000-001 Lisboa',
        nifRequerente: '123456789',
        
        // Dados básicos do requerido  
        nomeRequerido: 'Maria Santos Teste',
        emailRequerido: 'maria@teste.com',
        telefoneRequerido: '987654321',
        moradaRequerido: 'Avenida de Teste, 456, 4000-001 Porto',
        nifRequerido: '987654321'
    };
    
    const postData = querystring.stringify(dados);
    
    console.log('📤 Dados a enviar:');
    console.log(JSON.stringify(dados, null, 2));
    console.log('\n📤 Tamanho dos dados:', postData.length, 'bytes');
    
    const options = {
        hostname: 'localhost',
        port: 3000,
        path: '/servico/arbitragem/enviar',
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(postData)
        }
    };
    
    return new Promise((resolve, reject) => {
        console.log('\n📤 Enviando requisição...');
        
        const req = http.request(options, (res) => {
            console.log(`\n📥 Resposta recebida:`);
            console.log(`Status: ${res.statusCode}`);
            console.log(`Headers:`, res.headers);
            
            let responseData = '';
            res.on('data', (chunk) => {
                responseData += chunk;
            });
            
            res.on('end', () => {
                console.log(`\n📋 Corpo da resposta:`, responseData);
                
                if (res.statusCode === 302) {
                    const location = res.headers.location;
                    if (location === '/servico/arbitragem') {
                        console.log('✅ SUCESSO! Processo criado e redirecionado para arbitragem');
                    } else {
                        console.log(`⚠️ Redirecionado para: ${location}`);
                    }
                } else {
                    console.log(`❌ Status inesperado: ${res.statusCode}`);
                }
                
                resolve({
                    status: res.statusCode,
                    headers: res.headers,
                    data: responseData
                });
            });
        });
        
        req.on('error', (error) => {
            console.error('\n❌ Erro na requisição:', error.message);
            reject(error);
        });
        
        req.write(postData);
        req.end();
        
        // Timeout
        setTimeout(() => {
            console.log('\n⏰ Timeout de 15 segundos atingido');
            req.destroy();
            reject(new Error('Timeout'));
        }, 15000);
    });
}

async function main() {
    try {
        await testarArbitragemSimples();
        
        // Aguardar um pouco e verificar se o processo foi criado
        console.log('\n⏳ Aguardando 2 segundos...');
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Verificar último processo criado
        console.log('\n=== VERIFICANDO PROCESSO CRIADO ===');
        const Database = require('better-sqlite3');
        const db = new Database('./users.db');
        
        const ultimoProcesso = db.prepare('SELECT * FROM processos ORDER BY id DESC LIMIT 1').get();
        
        if (ultimoProcesso) {
            console.log('✅ Último processo encontrado:');
            console.log(`   ID: ${ultimoProcesso.id}`);
            console.log(`   Tipo: ${ultimoProcesso.tipo_servico}`);
            console.log(`   Natureza: ${ultimoProcesso.natureza_litigio}`);
            console.log(`   Valor: ${ultimoProcesso.valor_pretensao}`);
            console.log(`   Data: ${ultimoProcesso.data_criacao}`);
            console.log(`   Status: ${ultimoProcesso.status}`);
            
            if (ultimoProcesso.dados_formulario) {
                try {
                    const dados = JSON.parse(ultimoProcesso.dados_formulario);
                    console.log(`   Campos no formulário: ${Object.keys(dados).length}`);
                    console.log(`   Requerente: ${dados.nomeRequerente || 'N/A'}`);
                    console.log(`   Requerido: ${dados.nomeRequerido || 'N/A'}`);
                } catch (e) {
                    console.log(`   ❌ Erro ao parsear dados do formulário: ${e.message}`);
                }
            }
        } else {
            console.log('❌ Nenhum processo encontrado na base de dados');
        }
        
        db.close();
        
    } catch (error) {
        console.error('\n💥 Erro no teste:', error.message);
    }
}

main();