const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

async function debugErro() {
    console.log('=== DEBUG DO ERRO DE LOGIN ===');
    console.log();
    
    try {
        // Teste 1: Importar o database.js
        console.log('1. Importando database.js...');
        const dbModule = require('./database.js');
        console.log('   ✅ Database.js importado com sucesso');
        
        // Teste 2: Criar conexão
        console.log('2. Criando conexão com a base de dados...');
        const db = dbModule.createDatabase();
        console.log('   ✅ Conexão criada com sucesso');
        
        // Teste 3: Query de usuário
        console.log('3. Testando query do usuário...');
        const [users] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', ['admin', 'admin']);
        console.log(`   ✅ Query executada: ${users.length} usuários encontrados`);
        
        const user = users[0];
        if (user) {
            console.log(`   Usuário: ${user.username}, Tipo: ${user.profile_type}`);
        }
        
        // Teste 4: Testar função comparePassword
        console.log('4. Testando função comparePassword...');
        if (user) {
            // Verificar se a função existe
            if (typeof db.comparePassword === 'function') {
                console.log('   ✅ Função comparePassword existe');
                
                // Testar com senha correta
                const resultado = await db.comparePassword('admin123', user.password);
                console.log(`   ✅ Comparação de senha: ${resultado}`);
            } else {
                console.log('   ❌ Função comparePassword não existe!');
                console.log('   Funções disponíveis em db:', Object.keys(db));
                
                // Testar diretamente com bcrypt
                console.log('   Testando diretamente com bcrypt...');
                const resultado = await bcrypt.compare('admin123', user.password);
                console.log(`   ✅ Comparação direta: ${resultado}`);
            }
        }
        
        // Teste 5: Simular o processo completo
        console.log('5. Simulando processo completo...');
        if (user) {
            const senhaCorreta = await bcrypt.compare('admin123', user.password);
            if (senhaCorreta && user.profile_type === 'admin') {
                console.log('   ✅ LOGIN DEVERIA SER APROVADO');
            } else {
                console.log('   ❌ LOGIN SERIA REJEITADO');
                console.log('   Senha correta:', senhaCorreta);
                console.log('   É admin:', user.profile_type === 'admin');
            }
        }
        
        console.log();
        console.log('=== TESTE CONCLUÍDO SEM ERROS ===');
        
    } catch (error) {
        console.log();
        console.log('❌ ERRO ENCONTRADO:');
        console.log('Tipo:', error.constructor.name);
        console.log('Mensagem:', error.message);
        console.log('Stack:');
        console.log(error.stack);
    }
}

debugErro();