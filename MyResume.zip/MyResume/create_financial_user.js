const { createDatabase } = require('./database');

async function createFinancialUser() {
  console.log('=== CRIANDO USUÁRIO FINANCEIRO ===');
  
  const db = createDatabase();
  
  try {
    // Verificar se já existe
    const [existingUsers] = await db.query('SELECT * FROM users WHERE username = ?', ['financeiro']);
    
    if (existingUsers.length > 0) {
      console.log('Usuário financeiro já existe!');
      console.log('Username: financeiro');
      console.log('Password: fin123');
      return;
    }
    
    // Criar usuário financeiro
    const hashedPassword = await db.hashPassword('fin123');
    await db.query(
      'INSERT INTO users (username, password, profile_type, email, nome_completo) VALUES (?, ?, ?, ?, ?)',
      ['financeiro', hashedPassword, 'financeiro', 'financeiro@camigap.com', 'Departamento Financeiro']
    );
    
    console.log('✅ Usuário financeiro criado com sucesso!');
    console.log('Username: financeiro');
    console.log('Password: fin123');
    console.log('Email: financeiro@camigap.com');
    
  } catch (error) {
    console.error('❌ Erro ao criar usuário financeiro:', error);
  } finally {
    db.close();
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  createFinancialUser();
}

module.exports = { createFinancialUser };
