const http = require('http');
const querystring = require('querystring');

function testarLoginHTTP(email, password) {
    return new Promise((resolve, reject) => {
        const postData = querystring.stringify({
            email: email,
            password: password
        });

        const options = {
            hostname: 'localhost',
            port: 3000,
            path: '/teste-auth', // Usando a rota de teste que funciona
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = http.request(options, (res) => {
            console.log(`Status: ${res.statusCode}`);
            console.log(`Headers: ${JSON.stringify(res.headers, null, 2)}`);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                console.log('Resposta:', data);
                resolve({
                    status: res.statusCode,
                    headers: res.headers,
                    body: data
                });
            });
        });

        req.on('error', (e) => {
            console.error(`Erro na requisição: ${e.message}`);
            reject(e);
        });

        req.write(postData);
        req.end();
    });
}

async function executarTeste() {
    console.log('=== TESTE DE LOGIN HTTP COM /teste-auth ===');
    console.log('Testando login como admin com a rota de teste...');
    console.log();

    try {
        const resultado = await testarLoginHTTP('admin', 'admin123');
        console.log('\n=== RESULTADO ===');
        console.log(`Status: ${resultado.status}`);
        if (resultado.status === 302) {
            console.log(`Redirecionamento para: ${resultado.headers.location}`);
            if (resultado.headers.location === '/dashboard') {
                console.log('✅ LOGIN BEM-SUCEDIDO! Redirecionado para dashboard.');
            } else {
                console.log('❌ Login falhou, redirecionado para:', resultado.headers.location);
            }
        }
    } catch (error) {
        console.error('Erro:', error.message);
    }
}

executarTeste();