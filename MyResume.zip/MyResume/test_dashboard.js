const http = require('http');

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/dashboard',
  method: 'GET'
};

const req = http.request(options, (res) => {
  console.log(`Status: ${res.statusCode}`);
  console.log(`Headers: ${JSON.stringify(res.headers)}`);
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log(`Content Length: ${data.length}`);
    console.log('First 500 characters:');
    console.log(data.substring(0, 500));
  });
});

req.on('error', (e) => {
  console.error(`Erro na requisição: ${e.message}`);
});

req.end();
