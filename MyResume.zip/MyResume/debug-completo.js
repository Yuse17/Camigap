const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

console.log('=== DEBUG COMPLETO DO SISTEMA ===');
console.log();

// Teste 1: Verificar se a base de dados existe
const dbPath = path.join(__dirname, 'users.db');
console.log('1. Verificando base de dados...');
console.log(`   Caminho: ${dbPath}`);

try {
    const fs = require('fs');
    const dbExists = fs.existsSync(dbPath);
    console.log(`   Arquivo existe: ${dbExists ? '✅' : '❌'}`);
    
    if (dbExists) {
        const stats = fs.statSync(dbPath);
        console.log(`   Tamanho: ${stats.size} bytes`);
    }
} catch (error) {
    console.log(`   Erro: ${error.message}`);
}

console.log();

// Teste 2: Conectar e verificar usuários
console.log('2. Conectando à base de dados...');
try {
    const db = new Database(dbPath);
    
    // Verificar tabelas
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log(`   Tabelas encontradas: ${tables.map(t => t.name).join(', ')}`);
    
    // Verificar usuários
    if (tables.some(t => t.name === 'users')) {
        const users = db.prepare('SELECT id, username, email, profile_type FROM users').all();
        console.log(`   Total de usuários: ${users.length}`);
        
        users.forEach(user => {
            console.log(`   - ID: ${user.id}, Username: ${user.username}, Email: ${user.email}, Tipo: ${user.profile_type}`);
        });
        
        // Teste específico do admin
        const admin = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get('admin', 'admin@camigap.com');
        console.log();
        console.log('3. Verificando usuário admin...');
        if (admin) {
            console.log('   ✅ Admin encontrado!');
            console.log(`   ID: ${admin.id}`);
            console.log(`   Username: ${admin.username}`);
            console.log(`   Email: ${admin.email}`);
            console.log(`   Tipo: ${admin.profile_type}`);
            
            // Testar senha
            console.log();
            console.log('4. Testando senha do admin...');
            const senhaCorreta = bcrypt.compareSync('admin123', admin.password);
            console.log(`   Senha 'admin123': ${senhaCorreta ? '✅ CORRETA' : '❌ INCORRETA'}`);
            
            if (!senhaCorreta) {
                console.log(`   Hash atual: ${admin.password}`);
                const novaHash = bcrypt.hashSync('admin123', 10);
                console.log(`   Nova hash: ${novaHash}`);
                
                // Corrigir senha
                db.prepare('UPDATE users SET password = ? WHERE id = ?').run(novaHash, admin.id);
                console.log('   ✅ Senha corrigida!');
            }
        } else {
            console.log('   ❌ Admin não encontrado!');
            console.log('   Criando admin...');
            
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            const result = db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
                .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
            console.log(`   ✅ Admin criado com ID: ${result.lastInsertRowid}`);
        }
    } else {
        console.log('   ❌ Tabela users não encontrada!');
    }
    
    db.close();
    
} catch (error) {
    console.log(`   ❌ Erro: ${error.message}`);
}

console.log();

// Teste 3: Verificar se o servidor está rodando
console.log('5. Testando se o servidor está rodando...');
const http = require('http');
const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/login',
    method: 'GET',
    timeout: 5000
};

const req = http.request(options, (res) => {
    console.log(`   Status: ${res.statusCode} ${res.statusMessage}`);
    console.log(`   ✅ Servidor está respondendo!`);
});

req.on('error', (error) => {
    console.log(`   ❌ Servidor não responde: ${error.message}`);
});

req.on('timeout', () => {
    console.log(`   ❌ Timeout - servidor não responde`);
});

req.end();

console.log();
console.log('=== CREDENCIAIS PARA TESTE ===');
console.log('Username: admin');
console.log('Senha: admin123');
console.log('Email: admin@camigap.com');
console.log();
console.log('=== ENDEREÇOS PARA TESTE ===');
console.log('http://localhost:3000');
console.log('http://192.168.56.1:3000');
console.log('http://192.168.1.70:3000');
console.log();