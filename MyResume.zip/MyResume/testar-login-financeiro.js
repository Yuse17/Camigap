const http = require('http');
const querystring = require('querystring');

async function testarLoginFinanceiro() {
    console.log('=== TESTE LOGIN FINANCEIRO ===');
    
    const credenciais = [
        { username: 'financeiro', password: 'financeiro123', tipo: 'Financeiro' },
        { username: 'secretario', password: 'secretario123', tipo: 'Secretário' },
        { username: 'auditor', password: 'auditor123', tipo: 'Auditor' },
        { username: 'coordenador', password: 'coordenador123', tipo: 'Coordenador' }
    ];
    
    for (const cred of credenciais) {
        console.log(`\n🧪 Testando login: ${cred.tipo}`);
        console.log(`Username: ${cred.username}`);
        console.log(`Senha: ${cred.password}`);
        
        const postData = querystring.stringify({
            email: cred.username,
            password: cred.password
        });
        
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: '/auth',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        
        try {
            const resultado = await new Promise((resolve, reject) => {
                const req = http.request(options, (res) => {
                    let data = '';
                    res.on('data', (chunk) => data += chunk);
                    res.on('end', () => {
                        resolve({
                            status: res.statusCode,
                            location: res.headers.location,
                            data: data
                        });
                    });
                });
                
                req.on('error', reject);
                req.write(postData);
                req.end();
            });
            
            if (resultado.status === 302) {
                if (resultado.location === '/dashboard') {
                    console.log(`✅ SUCESSO! ${cred.tipo} logado e redirecionado para dashboard`);
                } else if (resultado.location === '/pagamentos') {
                    console.log(`✅ SUCESSO! ${cred.tipo} logado e redirecionado para pagamentos`);
                } else {
                    console.log(`⚠️ Redirecionado para: ${resultado.location}`);
                }
            } else {
                console.log(`❌ Falha no login: Status ${resultado.status}`);
            }
            
        } catch (error) {
            console.log(`❌ Erro: ${error.message}`);
        }
        
        // Aguardar um pouco entre testes
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

testarLoginFinanceiro();