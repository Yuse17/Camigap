// Script para atualizar e-mails de usuários existentes
const db = require('./database');

async function updateEmails() {
  try {
    console.log('Iniciando atualização de e-mails...');
    
    // Obter todos os usuários sem e-mail
    const [users] = await db.query("SELECT id, username FROM users WHERE email IS NULL OR email = ''");
    
    console.log(`Encontrados ${users.length} usuários sem e-mail.`);
    
    // Atualizar cada usuário com um e-mail baseado no nome de usuário
    for (const user of users) {
      const email = `${user.username}@camigap.com`;
      
      await db.query('UPDATE users SET email = ? WHERE id = ?', [email, user.id]);
      console.log(`Usuário ${user.username} (ID: ${user.id}) atualizado com e-mail: ${email}`);
    }
    
    console.log('Atualização de e-mails concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao atualizar e-mails:', error);
  } finally {
    process.exit();
  }
}

updateEmails();