const Database = require('better-sqlite3');

try {
    const db = new Database('./users.db');
    
    console.log('=== ESTRUTURA DA TABELA PROCESSOS ===');
    const estrutura = db.prepare('PRAGMA table_info(processos)').all();
    
    estrutura.forEach(col => {
        console.log(`- ${col.name} (${col.type})`);
        console.log(`  Nullable: ${col.notnull ? 'NO' : 'YES'}`);
        console.log(`  Default: ${col.dflt_value || 'NULL'}`);
        console.log('');
    });
    
    console.log('=== TESTE DE INSERT ===');
    
    // Tentar fazer um insert manual para ver se há erro
    const dadosTest = {
        tipo_servico: 'arbitragem',
        natureza_litigio: 'Teste',
        valor_pretensao: 1000,
        dados_formulario: '{"teste": "valor"}',
        arquivos: '{}'
    };
    
    try {
        const stmt = db.prepare(`
            INSERT INTO processos (tipo_servico, natureza_litigio, valor_pretensao, dados_formulario, arquivos) 
            VALUES (?, ?, ?, ?, ?)
        `);
        
        const result = stmt.run(
            dadosTest.tipo_servico,
            dadosTest.natureza_litigio, 
            dadosTest.valor_pretensao,
            dadosTest.dados_formulario,
            dadosTest.arquivos
        );
        
        console.log('✅ INSERT manual bem-sucedido!');
        console.log('ID inserido:', result.lastInsertRowid);
        
        // Remover o registro de teste
        db.prepare('DELETE FROM processos WHERE id = ?').run(result.lastInsertRowid);
        console.log('✅ Registro de teste removido');
        
    } catch (insertError) {
        console.error('❌ Erro no INSERT manual:', insertError.message);
    }
    
    db.close();
    
} catch (error) {
    console.error('❌ Erro geral:', error.message);
}