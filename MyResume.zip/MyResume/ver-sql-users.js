const Database = require('better-sqlite3');

try {
    const db = new Database('./users.db');
    
    const sql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'").get();
    console.log('SQL da tabela users:');
    console.log(sql.sql);
    
    db.close();
    
} catch (error) {
    console.error('Erro:', error.message);
}