const http = require('http');
const FormData = require('form-data');
const fs = require('fs');

async function testarArbitragemCompleta() {
    console.log('=== TESTE COMPLETO DE ARBITRAGEM ===');
    
    // Criar um arquivo de teste para upload
    const testFilePath = './teste.pdf';
    const testContent = 'Arquivo de teste para arbitragem';
    
    if (!fs.existsSync(testFilePath)) {
        fs.writeFileSync(testFilePath, testContent);
        console.log('✅ Arquivo de teste criado');
    }
    
    const form = new FormData();
    
    // Adicionar todos os campos necessários
    form.append('naturezaLitigio', 'Comercial');
    form.append('valorPretensao', '50000.00');
    form.append('descricaoLitigio', 'Disputa sobre contrato de prestação de serviços');
    
    // Dados do requerente
    form.append('nomeRequerente', 'João Silva');
    form.append('emailRequerente', 'joao@exemplo.com');
    form.append('telefoneRequerente', '912345678');
    form.append('moradaRequerente', 'Rua Exemplo, 123, Lisboa');
    form.append('nifRequerente', '123456789');
    
    // Dados do requerido
    form.append('nomeRequerido', 'Maria Santos');
    form.append('emailRequerido', 'maria@exemplo.com');
    form.append('telefoneRequerido', '987654321');
    form.append('moradaRequerido', 'Avenida Exemplo, 456, Porto');
    form.append('nifRequerido', '987654321');
    
    // Tentar adicionar um arquivo (opcional)
    try {
        form.append('comprovativoPagamento', fs.createReadStream(testFilePath));
        console.log('✅ Arquivo adicionado ao formulário');
    } catch (error) {
        console.log('⚠️ Sem arquivo de teste, continuando sem upload');
    }
    
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: '/servico/arbitragem/enviar',
            method: 'POST',
            headers: form.getHeaders()
        };
        
        console.log('📤 Enviando requisição...');
        console.log('Headers:', options.headers);
        
        const req = http.request(options, (res) => {
            console.log(`📥 Status: ${res.statusCode}`);
            console.log('📋 Headers de resposta:', res.headers);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                if (res.statusCode === 302) {
                    if (res.headers.location === '/servico/arbitragem') {
                        console.log('✅ SUCESSO! Redirecionado para página de arbitragem');
                    } else {
                        console.log(`⚠️ Redirecionado para: ${res.headers.location}`);
                    }
                } else {
                    console.log('❌ Erro HTTP:', res.statusCode);
                    console.log('Resposta:', data);
                }
                resolve({ status: res.statusCode, location: res.headers.location, data });
            });
        });
        
        req.on('error', (e) => {
            console.error('❌ Erro de rede:', e.message);
            reject(e);
        });
        
        // Enviar o formulário
        form.pipe(req);
        
        // Timeout de 30 segundos
        setTimeout(() => {
            req.destroy();
            reject(new Error('Timeout de 30 segundos'));
        }, 30000);
    });
}

async function verificarLogsServidor() {
    console.log('\n=== VERIFICANDO ÚLTIMO PROCESSO ===');
    
    const Database = require('better-sqlite3');
    const db = new Database('./users.db');
    
    try {
        const ultimosProcessos = db.prepare('SELECT * FROM processos ORDER BY id DESC LIMIT 3').all();
        
        if (ultimosProcessos.length > 0) {
            ultimosProcessos.forEach((processo, index) => {
                console.log(`\nProcesso ${index + 1}:`);
                console.log(`  ID: ${processo.id}`);
                console.log(`  Tipo: ${processo.tipo_servico}`);
                console.log(`  Natureza: ${processo.natureza_litigio}`);
                console.log(`  Valor: ${processo.valor_pretensao}`);
                console.log(`  Data: ${processo.data_criacao}`);
                console.log(`  Status: ${processo.status}`);
                
                if (processo.dados_formulario) {
                    try {
                        const dados = JSON.parse(processo.dados_formulario);
                        console.log(`  Dados: ${Object.keys(dados).length} campos`);
                    } catch (e) {
                        console.log(`  Dados: erro ao parsear JSON`);
                    }
                }
            });
        } else {
            console.log('❌ Nenhum processo encontrado');
        }
    } catch (error) {
        console.error('❌ Erro ao verificar processos:', error.message);
    } finally {
        db.close();
    }
}

async function executarTeste() {
    try {
        const resultado = await testarArbitragemCompleta();
        await verificarLogsServidor();
        
        // Limpar arquivo de teste
        try {
            fs.unlinkSync('./teste.pdf');
            console.log('\n🧹 Arquivo de teste removido');
        } catch (e) {
            // Ignorar erro se arquivo não existir
        }
        
    } catch (error) {
        console.error('\n❌ Erro no teste:', error.message);
    }
}

// Verificar se o módulo form-data está disponível
try {
    require('form-data');
    executarTeste();
} catch (e) {
    console.log('❌ Módulo form-data não encontrado');
    console.log('💡 Tentando teste simplificado...');
    
    // Teste simplificado sem upload de arquivo
    const querystring = require('querystring');
    
    const dadosSimples = querystring.stringify({
        naturezaLitigio: 'Comercial',
        valorPretensao: '10000',
        nomeRequerente: 'João Teste',
        emailRequerente: 'joao@teste.com',
        descricaoLitigio: 'Teste de disputa'
    });
    
    const options = {
        hostname: 'localhost',
        port: 3000,
        path: '/servico/arbitragem/enviar',
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(dadosSimples)
        }
    };
    
    const req = http.request(options, (res) => {
        console.log(`Status: ${res.statusCode}`);
        console.log(`Location: ${res.headers.location}`);
        
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
            console.log('Resposta:', data);
            verificarLogsServidor();
        });
    });
    
    req.on('error', (e) => console.error('Erro:', e.message));
    req.write(dadosSimples);
    req.end();
}