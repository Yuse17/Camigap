const Database = require('better-sqlite3');

console.log('=== VERIFICAÇÃO DE TABELAS DE PERFIS ===');

try {
    const db = new Database('./users.db');
    
    // Listar todas as tabelas
    const tabelas = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('Tabelas existentes:', tabelas.map(t => t.name));
    
    // Verificar estrutura da tabela users para ver perfis suportados
    console.log('\n=== ESTRUTURA DA TABELA USERS ===');
    const estruturaUsers = db.prepare("PRAGMA table_info(users)").all();
    estruturaUsers.forEach(col => {
        console.log(`- ${col.name} (${col.type})`);
    });
    
    // Verificar usuários existentes e seus perfis
    console.log('\n=== USUÁRIOS EXISTENTES ===');
    const usuarios = db.prepare('SELECT id, username, email, profile_type FROM users').all();
    usuarios.forEach(user => {
        console.log(`- ID: ${user.id}, Username: ${user.username}, Email: ${user.email}, Perfil: ${user.profile_type}`);
    });
    
    // Verificar se tabelas específicas de perfis existem
    const tabelasPerfis = ['secretarios', 'financeiros', 'auditores', 'coordenadores', 'assistentes', 'supervisores'];
    
    console.log('\n=== VERIFICANDO TABELAS DE PERFIS ===');
    tabelasPerfis.forEach(nomeTabela => {
        const existe = tabelas.find(t => t.name === nomeTabela);
        if (existe) {
            console.log(`✅ Tabela "${nomeTabela}" existe`);
            
            // Mostrar estrutura da tabela
            const estrutura = db.prepare(`PRAGMA table_info(${nomeTabela})`).all();
            console.log(`   Colunas: ${estrutura.map(col => `${col.name}(${col.type})`).join(', ')}`);
        } else {
            console.log(`❌ Tabela "${nomeTabela}" não existe`);
        }
    });
    
    db.close();
    
} catch (error) {
    console.error('❌ Erro:', error.message);
}