const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

// Função para hash da senha
function hashPasswordSync(password) {
  return bcrypt.hashSync(password, 10);
}

function limparDatabase() {
  console.log('Iniciando limpeza completa da base de dados...');
  
  // Conectar à base de dados
  const dbPath = path.join(__dirname, 'users.db');
  const db = new Database(dbPath);
  
  try {
    // Começar uma transação
    db.exec('BEGIN TRANSACTION');
    
    // Apagar todas as tabelas se existirem
    console.log('Apagando todas as tabelas...');
    
    const tabelas = [
      'solicitacoes_documentos',
      'vereditos', 
      'documentos',
      'processos',
      'users'
    ];
    
    tabelas.forEach(tabela => {
      try {
        db.exec(`DROP TABLE IF EXISTS ${tabela}`);
        console.log(`Tabela ${tabela} apagada.`);
      } catch (error) {
        console.log(`Tabela ${tabela} não existia ou erro ao apagar:`, error.message);
      }
    });
    
    // Recriar apenas a tabela users
    console.log('Recriando tabela users...');
    db.exec(`
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        profile_type TEXT NOT NULL CHECK(profile_type IN ('admin', 'secretario', 'profissional', 'parte')),
        email TEXT UNIQUE,
        nome_completo TEXT,
        processo_id INTEGER,
        two_factor_code TEXT,
        two_factor_expires TIMESTAMP
      )
    `);
    
    // Criar apenas o usuário admin
    console.log('Criando usuário admin...');
    const hashedPassword = hashPasswordSync('admin123');
    db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
      .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
    
    // Confirmar transação
    db.exec('COMMIT');
    
    console.log('✅ Base de dados limpa com sucesso!');
    console.log('✅ Usuário admin criado:');
    console.log('   - Username: admin');
    console.log('   - Email: admin@camigap.com'); 
    console.log('   - Senha: admin123');
    
  } catch (error) {
    // Reverter em caso de erro
    db.exec('ROLLBACK');
    console.error('❌ Erro ao limpar base de dados:', error);
    throw error;
  } finally {
    db.close();
  }
}

// Executar se for chamado diretamente
if (require.main === module) {
  limparDatabase();
}

module.exports = { limparDatabase };