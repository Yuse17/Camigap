const http = require('http');
const querystring = require('querystring');

function testarCriarProcesso() {
    return new Promise((resolve, reject) => {
        console.log('=== TESTE CRIAR PROCESSO ===');
        
        // Dados de teste para arbitragem
        const dadosProcesso = {
            // Dados básicos
            naturezaLitigio: 'Comercial',
            valorPretensao: '10000.50',
            
            // Dados do requerente
            nomeRequerente: 'João Silva',
            emailRequerente: 'joao@teste.com',
            telefoneRequerente: '912345678',
            moradaRequerente: 'Rua Teste 123, Lisboa',
            
            // Dados do requerido
            nomeRequerido: 'Maria Santos',
            emailRequerido: 'maria@teste.com',
            telefoneRequerido: '987654321',
            moradaRequerido: 'Avenida Teste 456, Porto',
            
            // Descrição do litígio
            descricaoLitigio: 'Disputa contratual sobre prestação de serviços'
        };
        
        const postData = querystring.stringify(dadosProcesso);
        
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: '/servico/arbitragem/enviar',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        
        const req = http.request(options, (res) => {
            console.log(`Status: ${res.statusCode}`);
            console.log(`Headers: ${JSON.stringify(res.headers, null, 2)}`);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                if (res.statusCode === 302 && res.headers.location === '/servico/arbitragem') {
                    console.log('✅ SUCESSO! Processo criado e redirecionado');
                } else {
                    console.log(`Status: ${res.statusCode}, Location: ${res.headers.location}`);
                    console.log('Resposta:', data);
                }
                resolve(res);
            });
        });
        
        req.on('error', (e) => {
            console.error(`❌ ERRO: ${e.message}`);
            reject(e);
        });
        
        req.write(postData);
        req.end();
    });
}

async function verificarProcessoCriado() {
    const Database = require('better-sqlite3');
    const db = new Database('./users.db');
    
    const processos = db.prepare('SELECT * FROM processos ORDER BY id DESC LIMIT 1').all();
    
    if (processos.length > 0) {
        console.log('\n=== ÚLTIMO PROCESSO CRIADO ===');
        const processo = processos[0];
        console.log(`ID: ${processo.id}`);
        console.log(`Tipo: ${processo.tipo_servico}`);
        console.log(`Natureza: ${processo.natureza_litigio}`);
        console.log(`Valor: ${processo.valor_pretensao}`);
        console.log(`Status: ${processo.status}`);
        console.log(`Data: ${processo.data_criacao}`);
    } else {
        console.log('\n❌ Nenhum processo encontrado');
    }
    
    db.close();
}

async function executarTeste() {
    try {
        await testarCriarProcesso();
        await new Promise(resolve => setTimeout(resolve, 1000)); // Aguardar 1 segundo
        await verificarProcessoCriado();
    } catch (error) {
        console.error('Erro no teste:', error);
    }
}

executarTeste();