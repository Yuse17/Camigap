# Sistema de Gerenciamento de Usuários

Este é um sistema de gerenciamento de usuários desenvolvido com Node.js, Express e SQLite.

## Requisitos

- Node.js (versão 14 ou superior)

## Instalação

1. Clone o repositório ou baixe os arquivos
2. Instale as dependências:

```bash
npm install
```

## Execução

Para iniciar o servidor:

```bash
npm start
```

Para iniciar o servidor em modo de desenvolvimento (com reinicialização automática):

```bash
npm run dev
```

O servidor será iniciado na porta 3000 por padrão. Acesse http://localhost:3000 no seu navegador.

## Banco de Dados

O sistema utiliza SQLite como banco de dados, o que significa que não é necessário instalar nenhum servidor de banco de dados separado. O arquivo do banco de dados será criado automaticamente na primeira execução.

## Credenciais padrão

- Usuário: admin
- Senha: admin123

## Funcionalidades

- Login e autenticação
- Gerenciamento de usuários (criar, excluir, redefinir senha)
- Diferentes tipos de perfis de usuário:
  - Árbitro
  - Mediador
  - Secretário
  - Financeiro
  - Consultor
  - Analista
  - Auditor
  - Coordenador
  - Assistente
  - Supervisor