<?php
session_start();
require 'database.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['profile_type'] = $user['profile_type'];
            $_SESSION['admin_logged_in'] = ($user['profile_type'] === 'admin');

            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['login_error'] = "Credenciais inválidas!";
            header("Location: login.html");
            exit();
        }
    } catch (PDOException $e) {
        die('Error: ' . $e->getMessage());
    }
}
?>