const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

// Configurar o caminho da base de dados
const dbPath = path.join(__dirname, 'users.db');
let db;

// Função para hash da senha
function hashPasswordSync(password) {
  return bcrypt.hashSync(password, 10);
}

// Função para comparar senhas
async function comparePassword(inputPassword, hashedPassword) {
  return bcrypt.compare(inputPassword, hashedPassword);
}

// Função para inicializar a base de dados (versão completa)
function initializeDatabase() {
  try {
    console.log('Inicializando banco de dados SQLite...');
    
    // Criar conexão com a base de dados
    db = new Database(dbPath);
    
    // Verificar se a tabela users existe, se não, criar apenas ela
    const usersTableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();
    
    if (!usersTableExists) {
      console.log('Criando tabela users...');
      db.exec(`
        CREATE TABLE users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          profile_type TEXT NOT NULL CHECK(profile_type IN (
            'admin', 'arbitro', 'mediador', 'secretario', 'financeiro', 
            'consultor', 'analista', 'auditor', 'coordenador', 'assistente', 
            'supervisor', 'secretario_geral', 'secretario_processo'
          )),
          email TEXT UNIQUE,
          nome_completo TEXT,
          processo_id INTEGER,
          two_factor_code TEXT,
          two_factor_expires TIMESTAMP,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
    }
    
    // Verificar se a tabela processos existe
    const processosTableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='processos'").get();
    
    if (!processosTableExists) {
      console.log('Criando tabela processos...');
      db.exec(`
        CREATE TABLE processos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tipo_servico TEXT NOT NULL CHECK(tipo_servico IN ('arbitragem', 'mediacao', 'conciliacao')),
          natureza_litigio TEXT,
          valor_pretensao DECIMAL(10,2) DEFAULT 0,
          dados_formulario TEXT,
          arquivos TEXT,
          status TEXT DEFAULT 'pendente' CHECK(status IN ('pendente', 'em_andamento', 'encerrado', 'veredito_pendente')),
          pagamento_verificado INTEGER DEFAULT 0,
          responsavel_id INTEGER,
          data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          data_peticao_inicial TIMESTAMP,
          FOREIGN KEY (responsavel_id) REFERENCES users(id)
        )
      `);
    }
    
    // Verificar se a tabela profissionais existe
    const profissionaisTableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='profissionais'").get();
    
    if (!profissionaisTableExists) {
      console.log('Criando tabela profissionais...');
      db.exec(`
        CREATE TABLE profissionais (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER UNIQUE NOT NULL,
          tipo TEXT NOT NULL CHECK(tipo IN ('arbitro', 'mediador', 'conciliador')),
          especialidade TEXT,
          biografia TEXT,
          disponivel INTEGER DEFAULT 1,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id)
        )
      `);
    }
    
    // Verificar se a tabela documentos existe
    const documentosTableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='documentos'").get();
    
    if (!documentosTableExists) {
      console.log('Criando tabela documentos...');
      db.exec(`
        CREATE TABLE documentos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          processo_id INTEGER NOT NULL,
          tipo TEXT NOT NULL,
          descricao TEXT,
          caminho_arquivo TEXT NOT NULL,
          enviado_por TEXT NOT NULL,
          data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (processo_id) REFERENCES processos(id)
        )
      `);
    }
    
    // Verificar se a tabela pedidos_documentos existe
    const pedidosTableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='pedidos_documentos'").get();
    
    if (!pedidosTableExists) {
      console.log('Criando tabela pedidos_documentos...');
      db.exec(`
        CREATE TABLE pedidos_documentos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          processo_id INTEGER NOT NULL,
          solicitante TEXT NOT NULL,
          destinatario TEXT NOT NULL,
          tipo_documento TEXT NOT NULL,
          descricao TEXT,
          prazo_limite DATE,
          status TEXT DEFAULT 'pendente' CHECK(status IN ('pendente', 'atendido', 'recusado')),
          documento_id INTEGER,
          motivo_recusa TEXT,
          data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (processo_id) REFERENCES processos(id),
          FOREIGN KEY (documento_id) REFERENCES documentos(id)
        )
      `);
    }
    
    // Verificar se a tabela vereditos_pendentes existe
    const vereditosTableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='vereditos_pendentes'").get();
    
    if (!vereditosTableExists) {
      console.log('Criando tabela vereditos_pendentes...');
      db.exec(`
        CREATE TABLE vereditos_pendentes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          processo_id INTEGER NOT NULL,
          profissional_id INTEGER NOT NULL,
          tipo_veredito TEXT NOT NULL,
          descricao TEXT NOT NULL,
          observacoes TEXT,
          documento_id INTEGER,
          status TEXT DEFAULT 'pendente' CHECK(status IN ('pendente', 'aprovado', 'rejeitado')),
          motivo_rejeicao TEXT,
          data_submissao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          data_decisao TIMESTAMP,
          FOREIGN KEY (processo_id) REFERENCES processos(id),
          FOREIGN KEY (profissional_id) REFERENCES users(id),
          FOREIGN KEY (documento_id) REFERENCES documentos(id)
        )
      `);
    }
    
    // Verificar se o admin existe
    const adminExists = db.prepare('SELECT COUNT(*) as count FROM users WHERE username = ?').get('admin');
    
    if (adminExists.count === 0) {
      console.log('Criando usuário admin...');
      const hashedPassword = hashPasswordSync('admin123');
      db.prepare('INSERT INTO users (username, password, profile_type, email) VALUES (?, ?, ?, ?)')
        .run('admin', hashedPassword, 'admin', 'admin@camigap.com');
      console.log('Usuário admin criado com sucesso!');
    }
    
    console.log('Banco de dados inicializado com sucesso!');
  } catch (error) {
    console.error('Erro ao inicializar o banco de dados:', error);
    process.exit(1);
  }
}

// Função para criar a base de dados MySQL (adaptada para retornar o wrapper do SQLite)
function createDatabase() {
  if (!db) {
    initializeDatabase();
  }
  
  return {
    // Wrapper para simular o comportamento do MySQL
    query: async (sql, params = []) => {
      try {
        if (sql.trim().toUpperCase().startsWith('SELECT')) {
          const stmt = db.prepare(sql);
          const results = stmt.all(...params);
          console.log(`Query: ${sql} | Params: ${JSON.stringify(params)} | Results: ${results.length} rows`);
          return [results]; // MySQL retorna array de arrays
        } else {
          const stmt = db.prepare(sql);
          const result = stmt.run(...params);
          console.log(`Query: ${sql} | Params: ${JSON.stringify(params)} | Result: affected rows ${result.changes}`);
          return [result];
        }
      } catch (error) {
        console.error('Erro na query:', error);
        throw error;
      }
    },
    
    // Funções auxiliares
    comparePassword: comparePassword,
    hashPassword: async (password) => {
      return bcrypt.hash(password, 10);
    },
    
    // Fechar conexão
    close: () => {
      if (db) {
        db.close();
      }
    }
  };
}

module.exports = {
  createDatabase,
  initializeDatabase,
  comparePassword
};