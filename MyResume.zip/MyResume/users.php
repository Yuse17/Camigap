<?php
session_start();
require 'database.php';

// Verificar se é admin
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

// Criar novo usuário
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user'])) {
    $username = $_POST['user'];
    
    // Definir os 10 tipos de perfis
    $profileType = $_POST['profile_type'];
    
    // Verificar se o tipo de perfil é válido
    $validProfileTypes = ['arbitro', 'mediador', 'secretario', 'financeiro', 'consultor', 'analista', 'auditor', 'coordenador', 'assistente', 'supervisor'];
    if (!in_array($profileType, $validProfileTypes)) {
        $_SESSION['create_error'] = "Tipo de perfil inválido!";
        header("Location: dashboard.php");
        exit();
    }
    
    // Senha para novos usuários
    if (!empty($_POST['password'])) {
        $password = $_POST['password'];
    } else {
        $password = 'user123'; // Senha padrão se nenhuma for fornecida
    }
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, profile_type) VALUES (?, ?, ?)");
        $stmt->execute([$username, $hashedPassword, $profileType]);
        
        $_SESSION['create_success'] = "Perfil criado com sucesso! Tipo: " . $profileType;
    } catch (PDOException $e) {
        $_SESSION['create_error'] = "Erro ao criar perfil: " . $e->getMessage();
    }
    
    header("Location: dashboard.php");
    exit();
}

// Redefinir senha
if (isset($_GET['action']) && $_GET['action'] == 'reset_password' && isset($_GET['id'])) {
    $userId = $_GET['id'];
    
    // Verificar se não é o admin
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if ($user && $user['username'] !== 'admin') {
        // Redefinir para a senha padrão
        $defaultPassword = 'user123';
        $hashedPassword = password_hash($defaultPassword, PASSWORD_DEFAULT);
        
        try {
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);
            
            $_SESSION['create_success'] = "Senha redefinida com sucesso para o usuário: " . $user['username'];
        } catch (PDOException $e) {
            $_SESSION['create_error'] = "Erro ao redefinir senha: " . $e->getMessage();
        }
    } else {
        $_SESSION['create_error'] = "Usuário não encontrado ou não pode ser modificado.";
    }
    
    header("Location: dashboard.php");
    exit();
}

// Excluir usuário
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $userId = $_GET['id'];
    
    // Verificar se não é o admin
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if ($user && $user['username'] !== 'admin') {
        try {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            
            $_SESSION['create_success'] = "Usuário excluído com sucesso: " . $user['username'];
        } catch (PDOException $e) {
            $_SESSION['create_error'] = "Erro ao excluir usuário: " . $e->getMessage();
        }
    } else {
        $_SESSION['create_error'] = "Usuário não encontrado ou não pode ser excluído.";
    }
    
    header("Location: dashboard.php");
    exit();
}
?>