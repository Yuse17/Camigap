# Instruções para Acesso Remoto ao CAMIGAP

Este documento explica como acessar o sistema CAMIGAP a partir de outros computadores na mesma rede ou pela internet.

## Opção 1 (RECOMENDADA): Acesso com Docker

O Docker é a maneira mais confiável e segura de disponibilizar o sistema CAMIGAP para acesso remoto.

### Passo 1: Instalar o Docker Desktop

1. Baixe e instale o Docker Desktop em [https://www.docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop)
2. Inicie o Docker Desktop e aguarde até que esteja em execução (ícone verde na barra de tarefas)

### Passo 2: Iniciar o Servidor com Docker

1. Execute o arquivo `CAMIGAP.bat`
2. Escolha a opção D1: "Iniciar com Docker (melhor para acesso remoto)"
3. Aguarde até que o contêiner seja construído e iniciado
4. Anote um dos endereços IP mostrados (algo como `http://192.168.1.100:3000`)

### Passo 3: Acessar a partir de Outros Computadores

1. Em qualquer computador conectado à mesma rede Wi-Fi ou LAN, abra um navegador web
2. Digite o endereço IP anotado no passo anterior
3. O sistema CAMIGAP será carregado e você poderá fazer login normalmente

### Vantagens do Docker

- **Isolamento**: O aplicativo roda em um ambiente isolado e consistente
- **Portabilidade**: Funciona da mesma forma em qualquer sistema operacional
- **Segurança**: Melhor isolamento do sistema operacional host
- **Persistência**: Continua rodando em segundo plano mesmo após fechar o terminal
- **Reinício automático**: Reinicia automaticamente em caso de falhas

### Gerenciando o Servidor Docker

- **Ver status**: Execute `CAMIGAP.bat` e escolha a opção D4
- **Ver logs**: Execute `CAMIGAP.bat` e escolha a opção D3
- **Parar servidor**: Execute `CAMIGAP.bat` e escolha a opção D2

## Opção 2: Acesso na Rede Local (Sem Docker)

Se não puder usar o Docker, esta é uma alternativa mais simples.

### Passo 1: Configurar o Firewall

1. Execute o arquivo `configurar-firewall-admin.bat` como administrador
2. Este script adiciona uma regra no Firewall do Windows para permitir conexões na porta 3000

### Passo 2: Iniciar o Servidor para Acesso em Rede

1. Execute o arquivo `iniciar-servidor-facil.bat`
2. O script irá:
   - Configurar o firewall automaticamente
   - Mostrar o endereço IP do seu computador
   - Iniciar o servidor CAMIGAP

3. Anote o endereço IP mostrado (algo como `http://192.168.1.100:3000`)

### Passo 3: Acessar a partir de Outros Computadores

1. Em qualquer computador conectado à mesma rede Wi-Fi ou LAN, abra um navegador web
2. Digite o endereço IP anotado no passo anterior
3. O sistema CAMIGAP será carregado e você poderá fazer login normalmente

## Opção 3: Acesso pela Internet (Requer ngrok)

Se você precisa acessar o sistema de fora da sua rede local (de qualquer lugar na internet):

### Passo 1: Instalar o ngrok

1. Baixe o ngrok em [https://ngrok.com/download](https://ngrok.com/download)
2. Extraia o arquivo baixado
3. Crie uma conta gratuita em [https://ngrok.com](https://ngrok.com)
4. Autentique o ngrok com o comando `ngrok authtoken SEU_TOKEN`

### Passo 2: Iniciar o Servidor com ngrok

1. Execute o arquivo `iniciar-com-ngrok.bat`
2. O script irá:
   - Iniciar o servidor CAMIGAP
   - Conectar o ngrok para expor o servidor na internet
   - Mostrar um URL público (algo como `https://1a2b3c4d.ngrok.io`)

### Passo 3: Acessar de Qualquer Lugar

1. Em qualquer dispositivo com acesso à internet, abra um navegador web
2. Digite o URL fornecido pelo ngrok
3. O sistema CAMIGAP será carregado e você poderá fazer login normalmente

## Solução de Problemas

Se estiver tendo problemas para acessar o sistema, execute o script `testar-conectividade.bat` para diagnosticar problemas comuns.

### Problemas Comuns:

1. **Docker não instalado**: Baixe e instale o Docker Desktop em [https://www.docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop)

2. **Docker não está em execução**: Inicie o Docker Desktop e aguarde até que esteja em execução

3. **Firewall Bloqueando**: Execute `configurar-firewall-admin.bat` como administrador

4. **Endereço IP Incorreto**: Verifique se está usando o endereço IP correto. Execute `testar-conectividade.bat` para ver todos os endereços IP disponíveis

5. **Porta em Uso**: Se a porta 3000 já estiver em uso, use `start-server-custom-port.bat` para escolher outra porta

6. **Computadores em Redes Diferentes**: Certifique-se de que ambos os computadores estão conectados à mesma rede Wi-Fi ou LAN

7. **Antivírus Bloqueando**: Alguns programas antivírus podem bloquear conexões de rede. Adicione uma exceção para o Docker ou Node.js

## Métodos Alternativos

### Usando o Servidor Embutido do Windows (Mais Avançado)

Se você tiver o IIS (Internet Information Services) instalado no Windows:

1. Configure o IIS para fazer proxy das requisições para o servidor Node.js
2. Isso permite usar o endereço IP do seu computador sem especificar a porta

### Usando um Serviço de Hospedagem

Para uma solução permanente, considere hospedar o sistema em um serviço como:
- Heroku
- Vercel
- Netlify
- DigitalOcean

## Observações Importantes

- O acesso remoto funciona apenas quando o servidor está em execução no computador host
- O endereço IP local pode mudar se o computador se reconectar à rede
- O URL do ngrok muda cada vez que você inicia o serviço (a menos que tenha uma conta paga)
- Por segurança, não deixe o servidor rodando sem supervisão em redes públicas