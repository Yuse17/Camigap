const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

async function testarLogin(email, password) {
    console.log(`=== TESTANDO LOGIN ===`);
    console.log(`Email/Username: ${email}`);
    console.log(`Senha: ${password}`);
    console.log();
    
    try {
        const dbPath = path.join(__dirname, 'users.db');
        const database = new Database(dbPath);
        
        // Simular a query como no app.js
        const sql = 'SELECT * FROM users WHERE email = ? OR username = ?';
        const stmt = database.prepare(sql);
        const users = stmt.all(email, email);
        
        console.log(`Usuários encontrados: ${users.length}`);
        
        if (users.length > 0) {
            const user = users[0];
            console.log(`Usuário: ${user.username}, Email: ${user.email}, Tipo: ${user.profile_type}`);
            
            // Testar senha
            const senhaCorreta = await bcrypt.compare(password, user.password);
            console.log(`Senha correta: ${senhaCorreta ? '✅ SIM' : '❌ NÃO'}`);
            
            if (senhaCorreta && user.profile_type === 'admin') {
                console.log('✅ LOGIN DE ADMIN SERIA BEM-SUCEDIDO!');
                return true;
            } else {
                console.log('❌ Login falharia');
                return false;
            }
        } else {
            console.log('❌ Nenhum usuário encontrado');
            return false;
        }
        
        database.close();
        
    } catch (error) {
        console.error('❌ Erro no teste:', error);
        return false;
    }
}

// Testar com diferentes combinações
async function executarTestes() {
    console.log('INICIANDO TESTES DE LOGIN...');
    console.log();
    
    await testarLogin('admin', 'admin123');
    console.log();
    await testarLogin('admin@camigap.com', 'admin123');
    console.log();
    await testarLogin('admin', 'senha_errada');
    console.log();
    
    console.log('TESTES CONCLUÍDOS!');
}

executarTestes();