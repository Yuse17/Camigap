-- Criar o banco de dados se não existir
CREATE DATABASE IF NOT EXISTS camigap;

-- Usar o banco de dados
USE camigap;

-- Criar tabela de usuários
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  profile_type ENUM('admin', 'arbitro', 'mediador', 'secretario', 'financeiro', 'consultor', 'analista', 'auditor', 'coordenador', 'assistente', 'supervisor') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir usuário admin padrão (senha: admin123)
-- A senha real será hasheada pelo aplicativo na primeira execução
INSERT INTO users (username, password, profile_type)
SELECT 'admin', 'temporarypassword', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');