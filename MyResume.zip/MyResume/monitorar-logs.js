console.log('=== MONITORAMENTO DE LOGS ===');
console.log('Este script vai mostrar todos os logs do servidor em tempo real.');
console.log('Agora você pode ir no navegador e submeter o formulário de arbitragem.');
console.log('Pressione Ctrl+C para parar o monitoramento.');
console.log('');

// Simplesmente manter o processo vivo para ver os logs do background
const Database = require('better-sqlite3');

function verificarProcessosATivos() {
    try {
        const db = new Database('./users.db');
        const count = db.prepare('SELECT COUNT(*) as total FROM processos').get();
        console.log(`📊 Total de processos na base: ${count.total}`);
        db.close();
    } catch (error) {
        console.error('Erro ao verificar processos:', error.message);
    }
}

// Verificar a cada 5 segundos
setInterval(() => {
    console.log(`⏰ ${new Date().toLocaleTimeString()} - Aguardando requisições...`);
    verificarProcessosATivos();
}, 5000);

console.log('🔍 Monitoramento iniciado...');
console.log('');

// Manter o processo vivo
process.stdin.resume();