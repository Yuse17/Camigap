const Database = require('better-sqlite3');
const path = require('path');

console.log('=== VERIFICAÇÃO DE TABELAS ===');

try {
    const dbPath = path.join(__dirname, 'users.db');
    const db = new Database(dbPath);
    
    // Listar todas as tabelas
    const tabelas = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
    console.log('Tabelas existentes:', tabelas.map(t => t.name));
    
    // Verificar se a tabela processos existe
    const processoExists = tabelas.find(t => t.name === 'processos');
    
    if (!processoExists) {
        console.log('\n❌ Tabela "processos" não existe!');
        console.log('Criando tabela processos...');
        
        // Criar tabela processos
        db.exec(`
            CREATE TABLE processos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo_servico TEXT NOT NULL,
                natureza_litigio TEXT,
                valor_pretensao DECIMAL(10,2),
                dados_formulario TEXT,
                arquivos TEXT,
                status TEXT DEFAULT 'pendente',
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        console.log('✅ Tabela "processos" criada com sucesso!');
    } else {
        console.log('✅ Tabela "processos" já existe');
        
        // Verificar estrutura da tabela
        const estrutura = db.prepare("PRAGMA table_info(processos)").all();
        console.log('\nEstrutura da tabela processos:');
        estrutura.forEach(col => {
            console.log(`- ${col.name} (${col.type})`);
        });
    }
    
    // Verificar outras tabelas importantes
    const tabelasImportantes = ['profissionais', 'pagamentos', 'documentos'];
    
    console.log('\n=== VERIFICANDO OUTRAS TABELAS ===');
    tabelasImportantes.forEach(nomeTabela => {
        const existe = tabelas.find(t => t.name === nomeTabela);
        if (existe) {
            console.log(`✅ Tabela "${nomeTabela}" existe`);
        } else {
            console.log(`❌ Tabela "${nomeTabela}" não existe`);
        }
    });
    
    db.close();
    
} catch (error) {
    console.error('❌ Erro:', error.message);
}